var e = require("@babel/runtime/helpers/wrapRegExp.js"),
  r = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  n = getApp();
module.exports = {
  judgeHead: function (e) {
    120 === e.head.width &&
      120 === e.head.height &&
      (e.openid !== e.selfid ||
        t ||
        ((t = !0),
        wx.showModal({
          content: "您的微信头像授权已过期，请重新授权",
          cancelText: "暂不",
          confirmText: "去授权",
          success: function (e) {
            e.cancel
              ? (t = !1)
              : ((t = !1), o({ url: "/packageA/pages/mine/setting/setting" }));
          },
        })));
  },
  navTo: o,
  getNavInfo: function () {
    var e = wx.getSystemInfoSync(),
      r = wx.getMenuButtonBoundingClientRect(),
      n = {};
    return (
      (n.margin = r.top - e.statusBarHeight),
      (n.height = e.statusBarHeight + 44),
      (n.capsule = r),
      (n.sys = e),
      n
    );
  },
  getQueryFromUrl: function (e, r) {
    for (var n = e.split("&"), t = 0; t < n.length; t++) {
      var a = n[t].split("=");
      if (a[0] == r) return a[1];
    }
    return !1;
  },
  dealBack: function () {
    getCurrentPages().length > 1
      ? wx.navigateBack({ delta: 1 })
      : wx.reLaunch({ url: "/pages/index/index" });
  },
  matchWith: i,
  multyShareName: function (e, r) {
    if (!e || !r) return;
    if (e._infos.title) return e._infos.title;
    var n = e._status,
      t = e._infos.mode,
      a = e._infos.type,
      o = e._infos.groups,
      u = e._infos.groupsValid;
    ("racing" !== n && "end" !== n) || (o = u);
    var l = "";
    switch (t) {
      case "loop":
      case "doubleLoop":
        (l += s(a) ? o : 2 * o),
          (l += "人"),
          (l += i(r.types.values, a, r.types.names_2)),
          (l += "，"),
          (l += i(r.modes.values, t, r.modes.names));
        break;
      case "arena":
        (l += i(r.types.values, a, r.types.names_2)),
          (l += i(r.modes.values, t, r.modes.names));
        break;
      case "promote":
        s(a) ? (l += o + "人单打晋级赛") : (l += 2 * o + "人双打晋级赛");
        break;
      case "eight":
        (l += o + "人转"),
          "womanDoubles" === a
            ? (l += "（女）")
            : "manDoubles" === a && (l += "（男）");
        break;
      case "mixRound":
        l += o + "男" + o + "女混双转";
        break;
      case "weakStrong":
        l += 2 * o + "人前后转";
        break;
      case "fixedRound":
        l += 2 * o + "人固搭转";
        break;
      case "singlesRound":
        l += o + "人单打转";
        break;
      case "freeRound":
        l += o + "人自由转";
        break;
      case "teamRound":
        l += o + "v" + o + "小队转";
        break;
      case "wheelMatch":
        l += o + "v" + o + "轮比转";
        break;
      case "singlesMatch":
        l += o + "v" + o + "单打对抗赛";
        break;
      case "fixedMatch":
        l += 2 * o + "v" + 2 * o + "固搭对抗赛";
        break;
      case "freeMatch":
      case "relayMatch":
        var c = e._infos;
        switch (n) {
          case "entering":
          case "cancel":
            l += o + "v" + o;
            break;
          case "racing":
          case "end":
            l += c.groupsValid_A + "v" + c.groupsValid_B;
        }
        switch (t) {
          case "freeMatch":
            l += "自由对抗赛";
            break;
          case "relayMatch":
            l += "接力赛";
        }
    }
    return l;
  },
  networkFail: function (e, r, t) {
    wx.hideLoading(),
      e &&
        !a &&
        ((a = !0),
        wx.getNetworkType({
          success: function (e) {
            "none" != e.networkType
              ? wx.showModal({
                  content: "腾讯系统繁忙，请过会再试",
                  showCancel: !1,
                  confirmText: "好的",
                  success: function (e) {
                    e.confirm && (a = !1);
                  },
                })
              : wx.showModal({
                  content: "请保持网络畅通，并重新操作",
                  showCancel: !1,
                  confirmText: "好的",
                  success: function (e) {
                    e.confirm && (a = !1);
                  },
                });
          },
        }));
    wx.cloud.callFunction({
      name: "comm",
      data: {
        fun: "error",
        err: r,
        from: t,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      },
    });
  },
  cloudLog: function (e) {
    wx.cloud.callFunction({
      name: "comm",
      data: {
        fun: "cloudLog",
        paras: e,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      },
    });
  },
  multiRacePlayer: function (e, r) {
    if (!r) return;
    if (e && e._infos && e._infos.clubid && "alone" != e._infos.clubid) {
      var t = e.club._name,
        a = e.club._nameSimple,
        i = e.club._logoUrl;
      (n.globalData.clubInfo.crtMeout = {
        clubName: "string" == typeof t ? t : t[0],
        clubNameSimple: a ? ("string" == typeof a ? a : a[0]) : "",
        logoUrl: i ? ("string" == typeof i ? i : i[0]) : "",
      }),
        r._memRoleIdx.length <= 0
          ? e.me &&
            e.me.status &&
            e.me.status.length > 0 &&
            "normal" === e.me.status[0]
            ? o({
                url:
                  "/pages/mine/othermine/othermine?userid=" +
                  r._playerid +
                  "&from=asclub&clubid=" +
                  e._infos.clubid +
                  "&merole=" +
                  e.me.role[0],
              })
            : o({
                url:
                  "/pages/mine/othermine/othermine?userid=" +
                  r._playerid +
                  "&from=asclub&clubid=" +
                  e._infos.clubid,
              })
          : r._memRoleIdx[0] > 0
          ? o({
              url:
                "/packageD/pages/club/me/meout/meout?userid=" +
                r._playerid +
                "&clubid=" +
                e._infos.clubid,
            })
          : (e.me &&
              e.me.role &&
              e.me.role.length > 0 &&
              "president" === e.me.role[0]) ||
            n.globalData.selfid === e._creatorid
          ? o({
              url:
                "/packageD/pages/club/me/meout/meout?isOrganizer=true&userid=" +
                r._playerid +
                "&clubid=" +
                e._infos.clubid,
            })
          : o({
              url:
                "/pages/mine/othermine/othermine?userid=" +
                r._playerid +
                "&clubid=" +
                e._infos.clubid,
            });
    } else o({ url: "/pages/mine/othermine/othermine?userid=" + r._playerid });
  },
  divideTwo: function (e) {
    var r = 0;
    for (; e > 1; ) (e = Math.ceil(e / 2)), r++;
    return r;
  },
  calPhases: function (e) {
    var r = 0;
    for (; e > 1; ) (r += parseInt(e / 2)), (e = Math.ceil(e / 2));
    return r;
  },
  getWeek: function (e) {
    switch (e) {
      case 0:
        return "星期日";
      case 1:
        return "星期一";
      case 2:
        return "星期二";
      case 3:
        return "星期三";
      case 4:
        return "星期四";
      case 5:
        return "星期五";
      case 6:
        return "星期六";
    }
  },
  makeUniPlayers: function (e) {
    for (var r = 0; r < e.length; r++) {
      for (
        var n = [], t = e[r]._infos.figures, a = e[r].players, o = 1;
        o <= t && o < a.length;
        o++
      ) {
        for (var i = 0; i < n.length && n[i]._playerid !== a[o]._playerid; i++);
        i >= n.length
          ? n.push({
              _playerid: a[o]._playerid,
              _total: 1,
              _anonymous: a[o]._anonymous,
            })
          : n[i]._total++;
      }
      e[r].uniPlayers = n;
    }
    return e;
  },
  cutString: function (e, n, t) {
    if (!e) return "";
    var a = (function (e) {
      if (!e) return "";
      for (var n, t = 0, a = 0; a < e.length; a++)
        (n = e.charCodeAt(a)),
          (t += u(n)),
          (0, r.mylog)(e.charAt(a), " len: ", n);
      return t;
    })(e);
    if (a <= n) return e;
    a = 0;
    for (var o = 0, i = "", l = 0; l < e.length; l++) {
      if (((o = u(e.charCodeAt(l))), !(a + o <= n))) {
        t || (i += "…");
        break;
      }
      (a += o), (i += e.charAt(l));
    }
    return i;
  },
  makeRandom: function (e, r) {
    if (e > r) {
      var n = e;
      (e = r), (r = n);
    }
    var t = r - e;
    return parseInt(Math.random() * t + e);
  },
  showFixed: function (e) {
    if (!e) return 0;
    return (
      (e = parseFloat(e)),
      (10 * (e = parseFloat(e.toFixed(3)))) % 10 == 0
        ? e.toFixed(0)
        : (100 * e) % 10 == 0
        ? e.toFixed(1)
        : e.toFixed(2)
    );
  },
  toFloat: function (e) {
    if (!e || isNaN(parseFloat(e))) return 0;
    return parseFloat(e);
  },
  showLevel: function (e, r) {
    return 0 === e
      ? "萌新"
      : !e || e <= -1
      ? "未自评"
      : e > 9
      ? "专业级"
      : e <= 1 || e >= 8
      ? e + "级"
      : r <= 1
      ? e + "级-"
      : 2 === r
      ? e + "级"
      : e + "级+";
  },
  calcLevel: function (e, r) {
    if (null == e || "" === e) return -1;
    (null != r && "" !== r) || (r = 2);
    return 0 === e
      ? 0
      : !e || e <= -1
      ? -1
      : e > 9
      ? 10
      : e <= 1 || e >= 8
      ? e
      : r <= 1
      ? 2 === e
        ? 1.5
        : e - 0.3
      : 2 === r
      ? e
      : 7 === e
      ? 7.5
      : e + 0.3;
  },
  strLevel: l,
  viceLevel: function (e) {
    if (75 === Math.round(10 * e)) return { level: 7, vice: 3 };
    var r = Math.round(e),
      n = 2;
    e < r ? (n = 1) : e > r && (n = 3);
    return { level: r, vice: n };
  },
  getLevelText: function (e, r) {
    return e < 0 && r > 10
      ? "不限"
      : e === r
      ? l(e)
      : e >= 0 && r >= 10
      ? l(e) + "以上"
      : e <= 0 && r <= 10
      ? l(r) + "以下"
      : l(e) + "至" + l(r);
  },
  judgeLevelsOK: function (e) {
    (0, r.mylog)("judgeLevelsOK players: ");
    for (var n = 1; n < e.length; n++) {
      var t = e[n];
      if (
        !(
          t._memInfo &&
          t._memInfo.level.length > 0 &&
          t._memInfo.level[0] > -1
        ) &&
        !(t._infos && t._infos.length > 0 && t._infos[0].level > -1)
      )
        return !1;
    }
    return !0;
  },
  judgeGenderOK: function (e) {
    (0, r.mylog)("judgeGenderOK, players: ", e);
    for (var n = 1; n < e.length; n++) if (!e[n]._gender[0]) return !1;
    return !0;
  },
  dealReg: function (e) {
    return (e = (e = (e = (e = (e = e.replace(
      RegExp("\\[|\\]", "g"),
      ""
    )).replace(RegExp("\\(|\\)", "g"), "")).replace(
      RegExp("\\{|\\}", "g"),
      ""
    )).replace(RegExp("（|）", "g"), "")).replace(RegExp("【|】", "g"), ""));
  },
  addressAnalysis: function (n) {
    var t,
      a,
      o,
      i = e(
        /^([^省]+\u7701|[^自治区]+\u81EA\u6CBB\u533A|[^市]+\u5E02|[^县]+\u53BF)/,
        { province: 1 }
      ),
      u = e(
        /([^市]+\u5E02|[^县]+\u53BF|[^区]+\u533A|[^autonomous]+autonomous[^region]+region)/,
        { city: 1 }
      ),
      l = e(/([^区]+\u533A|[^县]+\u53BF)/, { district: 1 }),
      s = n.match(i);
    s &&
      s.groups.province &&
      ((t = s.groups.province), (n = n.substring(t.length)));
    var c = n.match(u);
    c && c.groups.city && ((a = c.groups.city), (n = n.substring(a.length)));
    var f = n.match(l);
    f && f.groups.district && (o = f.groups.district);
    return (
      (0, r.mylog)(s, c, f),
      (0, r.mylog)(t, a, o),
      { province: t, city: a, district: o }
    );
  },
  copyArr: function (e) {
    if (!e) return [];
    for (var r = [], n = 0; n < e.length; n++) {
      var t = JSON.parse(JSON.stringify(e[n]));
      r.push(t);
    }
    return r;
  },
  dealLocalPlayers: function (e) {
    for (var r = [], n = 0; n < e.length; n++) {
      var t = e[n];
      r.push({
        _id: t._id,
        _no: t._no,
        _playerid: t._playerid,
        _raceid: t._raceid,
      });
    }
    return r;
  },
  clubRole: function (e) {
    return e && e.self ? e.self.memRole : null;
  },
  getTimezoneOff: function () {
    return new Date().getTimezoneOffset();
  },
};
var t = !1,
  a = !1;
function o(e) {
  wx.navigateTo({
    url: e.url,
    fail: function (e) {
      wx.showToast({
        title: "打开页面太多了哦，请返回上一个页面",
        duration: 3e3,
        icon: "none",
      });
    },
  });
}
function i(e, r, n) {
  for (var t = -1, a = 0; a < e.length; a++)
    if (r === e[a]) {
      t = a;
      break;
    }
  return -1 === t ? null : n[t];
}
function u(e) {
  return (e >= 4352 && e <= 4607) ||
    (e >= 9728 && e <= 10175) ||
    (e >= 10240 && e <= 10495) ||
    (e >= 11904 && e <= 12255) ||
    (e >= 12272 && e <= 12687) ||
    (e >= 12704 && e <= 42191) ||
    (e >= 44032 && e <= 55215) ||
    (e >= 63744 && e <= 64045) ||
    (e >= 64048 && e <= 64106) ||
    (e >= 64112 && e <= 64217) ||
    (e >= 65280 && e <= 65519) ||
    (e >= 119552 && e <= 119647) ||
    (e >= 131072 && e <= 173782) ||
    (e >= 194560 && e <= 195101)
    ? 2
    : 1;
}
function l(e) {
  if (75 === Math.round(10 * e)) return "7级+";
  var r = Math.round(e);
  if (r <= 0) return "萌新";
  if (r >= 10) return "专业级";
  var n = r + "级";
  return e < r ? (n += "-") : e > r && (n += "+"), n;
}
function s(e) {
  return !!e && -1 != e.indexOf("Singles");
}
