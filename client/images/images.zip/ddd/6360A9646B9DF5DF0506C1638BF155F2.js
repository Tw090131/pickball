var i = require("981C1DB26B9DF5DFFE7A75B5964555F2.js");
module.exports = Behavior({
  methods: {
    _countDown: function () {
      var i = this,
        t = this.data.sift._infos.sift.range.endMil - new Date().getTime();
      this.setData({ remainMil: t });
      var o = setInterval(function () {
        (t -= 1e3), i.setData({ remainMil: t }), t <= 0 && clearInterval(o);
      }, 1e3);
    },
    onSift: function () {
      (0, i.mylog)("onSift");
      var t = this.data.sift._infos.sift.type;
      "sift" === t || "multy" === t ? this._toJdCoupon() : this._toJdDetail();
    },
    _toJdCoupon: function () {
      var t = this,
        o = this.data.sift._infos.urls.siftUrl;
      (0, i.mylog)("onJdCoupon, siftUrl: ", o),
        wx.openEmbeddedMiniProgram({
          appId: "wx91d27dbf599dff74",
          path: "/pages/union/proxy/proxy?spreadUrl=" + o,
          success: function (n) {
            (0, i.mylog)("_toJdCoupon, success"),
              t._addClick({ kind: "coupon", url: o, action: "confirm" });
          },
          fail: function (n) {
            (0, i.mylog)("_toJdCoupon, fail"),
              t._addClick({ kind: "coupon", url: o, action: "cancel" });
          },
        });
    },
    _toJdDetail: function () {
      var t = this,
        o = this.data.sift._infos.urls.rebateUrl;
      (0, i.mylog)("onJdDetail, rebateUrl: ", o),
        wx.openEmbeddedMiniProgram({
          appId: "wx91d27dbf599dff74",
          path: "/pages/union/proxy/proxy?spreadUrl=" + o,
          success: function (n) {
            (0, i.mylog)("_toJdDetail, success"),
              t._addClick({ kind: "detail", url: o, action: "confirm" });
          },
          fail: function (n) {
            (0, i.mylog)("_toJdDetail, fail"),
              t._addClick({ kind: "detail", url: o, action: "cancel" });
          },
        });
    },
  },
});
