var e = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  s = getApp();
module.exports = Behavior({
  data: {
    crtTypeIdx: 0,
    crtType: "signed",
    switchList: [
      { type: "signed", text: "报名" },
      { type: "alternates", text: "候补" },
      { type: "retreats", text: "退坑" },
    ],
    activityid: "",
    activity: "",
    selfid: "",
    retreatPlayer: "",
    crtOrder: "smart",
    showPublic: !0,
  },
  methods: {
    _dealOptions: function (e) {
      e.from &&
        s.globalData.activityInfo.crtActivity &&
        (this.setData({
          activityid: s.globalData.activityInfo.crtActivity._id,
          activity: s.globalData.activityInfo.crtActivity,
          selfid: s.globalData.selfid,
          selfInfo: s.globalData.selfInfo,
          players: s.globalData.activityInfo.crtPlayers,
        }),
        this.setData({ roles: this._dealRoles(this.data.players) }));
    },
    onRefresh: function () {
      this._dealRefresh();
    },
    onRefreshByRetreat: function () {
      this._dealRefresh();
    },
    _dealRefresh: function () {
      this._getActivity(), this._getActivityPlayers();
    },
    onPlayer: function (e) {
      switch (this.data.pageType) {
        case "players":
        case "retreat":
          this._dealBySelf(e);
          break;
        case "manager":
          this._dealByManager(e);
      }
    },
    _dealBySelf: function (t) {
      var s = this.data.activity,
        o = t.currentTarget.dataset.player,
        n = o._nickName[0];
      s._infos.isRealname && o._realName && o._realName.length > 0
        ? (n = o._realName[0])
        : o._anonymous &&
          o._anonymous.isAnonymous &&
          o._anonymous.nickName &&
          this.data.showPublic &&
          (n = o._anonymous.nickName),
        "retreat" === o._status
          ? "other" === o._signType
            ? o._playerid === this.data.selfid
              ? wx.showModal({
                  content:
                    "我的朋友" +
                    (0, e.cutString)(o._otherInfos.nickName, 8, !0),
                  showCancel: !1,
                  confirmText: "好的",
                })
              : wx.showModal({
                  content:
                    n +
                    "的朋友" +
                    (0, e.cutString)(o._otherInfos.nickName, 8, !0),
                  showCancel: !1,
                  confirmText: "好的",
                })
            : o._anonymous && o._anonymous.isAnonymous
            ? o._playerid === this.data.selfid
              ? wx.showModal({
                  content: "您已匿名，您自己可以查看自己的个人页",
                  cancelText: "暂不",
                  confirmText: "打开",
                  success: function (t) {
                    t.cancel || (0, e.multiRacePlayer)(s, o);
                  },
                })
              : this.data.selfid === this.data.activity._creatorid
              ? wx.showModal({
                  content: n + "已匿名，作为组织者，您可以查看ta的个人页",
                  cancelText: "暂不",
                  confirmText: "打开",
                  success: function (t) {
                    t.cancel || (0, e.multiRacePlayer)(s, o);
                  },
                })
              : wx.showModal({
                  content: n + "已匿名，活动期间不能查看ta的个人页哦",
                  showCancel: !1,
                  confirmText: "好的",
                })
            : (0, e.multiRacePlayer)(s, o)
          : this._dealNormalBySelf(t);
    },
    _dealNormalBySelf: function (t) {
      var s = this,
        o = this.data.activity,
        n = t.currentTarget.dataset.player,
        a = n._nickName[0];
      o._infos.isRealname && n._realName && n._realName.length > 0
        ? (a = n._realName[0])
        : n._anonymous &&
          n._anonymous.isAnonymous &&
          n._anonymous.nickName &&
          this.data.showPublic &&
          (a = n._anonymous.nickName);
      var i = new Date().getTime();
      if ("other" === n._signType)
        n._playerid === this.data.selfid
          ? i > o._startTimeMil - 60 * o._infos.retreatTime * 60 * 1e3 &&
            !n._isAlternate
            ? wx.showActionSheet({
                alertText:
                  "我的朋友" + (0, e.cutString)(n._otherInfos.nickName, 8, !0),
                itemList: [
                  "修改带人",
                  n._setOtherHead && n._setOtherHead.isSetted
                    ? "移除头像"
                    : "设置头像",
                  "备注",
                ],
                success: function (e) {
                  switch (e.tapIndex) {
                    case 0:
                      s
                        .selectComponent("#signOther")
                        .set({
                          gender: n._otherInfos.gender,
                          nickname: n._otherInfos.nickName,
                          level: n._otherInfos.level,
                          levelvice: n._otherInfos.levelvice,
                          activityPlayerid: n._id,
                        }),
                        s.selectComponent("#signOther").showPop();
                      break;
                    case 1:
                      n._setOtherHead && n._setOtherHead.isSetted
                        ? s._deleteOtherHead(n._id)
                        : s._showOtherHeadPop(n);
                      break;
                    case 2:
                      s
                        .selectComponent("#postscript")
                        .setActivityPlayerid(n._id),
                        s
                          .selectComponent("#postscript")
                          .setPostscript(n._postscript),
                        s.selectComponent("#postscript").setKind(n._signType),
                        s
                          .selectComponent("#postscript")
                          .setPlayerGender(n._otherInfos.gender),
                        s
                          .selectComponent("#postscript")
                          .setOtherHeadInfo(n._setOtherHead),
                        s.selectComponent("#postscript").showPop();
                  }
                },
              })
            : wx.showActionSheet({
                alertText:
                  "我的朋友" + (0, e.cutString)(n._otherInfos.nickName, 8, !0),
                itemList: [
                  "修改带人",
                  n._setOtherHead && n._setOtherHead.isSetted
                    ? "移除头像"
                    : "设置头像",
                  "备注",
                  "退坑",
                ],
                success: function (e) {
                  switch (e.tapIndex) {
                    case 0:
                      s
                        .selectComponent("#signOther")
                        .set({
                          gender: n._otherInfos.gender,
                          nickname: n._otherInfos.nickName,
                          level: n._otherInfos.level,
                          levelvice: n._otherInfos.levelvice,
                          activityPlayerid: n._id,
                        }),
                        s.selectComponent("#signOther").showPop();
                      break;
                    case 1:
                      n._setOtherHead && n._setOtherHead.isSetted
                        ? s._deleteOtherHead(n._id)
                        : s._showOtherHeadPop(n);
                      break;
                    case 2:
                      s
                        .selectComponent("#postscript")
                        .setActivityPlayerid(n._id),
                        s
                          .selectComponent("#postscript")
                          .setPostscript(n._postscript),
                        s.selectComponent("#postscript").setKind(n._signType),
                        s
                          .selectComponent("#postscript")
                          .setPlayerGender(n._otherInfos.gender),
                        s
                          .selectComponent("#postscript")
                          .setOtherHeadInfo(n._setOtherHead),
                        s.selectComponent("#postscript").showPop();
                      break;
                    case 3:
                      s.setData({ retreatPlayer: n }),
                        s.selectComponent("#retreat").setActPlayer(n),
                        s.selectComponent("#retreat").showPop();
                  }
                },
              })
          : wx.showModal({
              content:
                a + "的朋友" + (0, e.cutString)(n._otherInfos.nickName, 8, !0),
              showCancel: !1,
              confirmText: "好的",
            });
      else if (n._playerid === this.data.selfid) {
        var r = a + "（我自己）";
        i > o._startTimeMil - 60 * o._infos.retreatTime * 60 * 1e3 &&
        !n._isAlternate
          ? wx.showActionSheet({
              alertText: r,
              itemList: [
                "备注",
                "主页",
                n._anonymous && n._anonymous.isAnonymous ? "移除匿名" : "匿名",
              ],
              success: function (t) {
                switch (t.tapIndex) {
                  case 0:
                    s.selectComponent("#postscript").setActivityPlayerid(n._id),
                      s
                        .selectComponent("#postscript")
                        .setPostscript(n._postscript),
                      s.selectComponent("#postscript").setKind(n._signType),
                      s
                        .selectComponent("#postscript")
                        .setPlayerGender(n._gender[0]),
                      s
                        .selectComponent("#postscript")
                        .setSelfAnonymous(n._anonymous),
                      s.selectComponent("#postscript").showPop();
                    break;
                  case 1:
                    (0, e.multiRacePlayer)(o, n);
                    break;
                  case 2:
                    n._anonymous && n._anonymous.isAnonymous
                      ? s._deleteAnonymous(n)
                      : s._showAnonymousPop(n);
                }
              },
            })
          : wx.showActionSheet({
              alertText: r,
              itemList: [
                "备注",
                "退坑",
                "主页",
                n._anonymous && n._anonymous.isAnonymous ? "移除匿名" : "匿名",
              ],
              success: function (t) {
                switch (t.tapIndex) {
                  case 0:
                    s.selectComponent("#postscript").setActivityPlayerid(n._id),
                      s
                        .selectComponent("#postscript")
                        .setPostscript(n._postscript),
                      s.selectComponent("#postscript").setKind(n._signType),
                      s
                        .selectComponent("#postscript")
                        .setPlayerGender(n._gender[0]),
                      s
                        .selectComponent("#postscript")
                        .setSelfAnonymous(n._anonymous),
                      s.selectComponent("#postscript").showPop();
                    break;
                  case 1:
                    s.setData({ retreatPlayer: n }),
                      s.selectComponent("#retreat").setActPlayer(n),
                      s.selectComponent("#retreat").showPop();
                    break;
                  case 2:
                    (0, e.multiRacePlayer)(o, n);
                    break;
                  case 3:
                    n._anonymous && n._anonymous.isAnonymous
                      ? s._deleteAnonymous(n)
                      : s._showAnonymousPop(n);
                }
              },
            });
      } else
        n._anonymous && n._anonymous.isAnonymous
          ? this.data.selfid === this.data.activity._creatorid
            ? wx.showModal({
                content: a + "已匿名，作为组织者，您可以查看ta的个人页",
                cancelText: "暂不",
                confirmText: "打开",
                success: function (t) {
                  t.cancel || (0, e.multiRacePlayer)(o, n);
                },
              })
            : wx.showModal({
                content: a + "已匿名，活动期间不能查看ta的个人页哦",
                showCancel: !1,
                confirmText: "好的",
              })
          : (0, e.multiRacePlayer)(o, n);
    },
    _deleteOtherHead: function (o) {
      var n = this;
      wx.showModal({
        content: "是否确定移除已设置的头像？",
        confirmText: "移除",
        complete: function (a) {
          a.cancel ||
            (a.confirm &&
              (wx.showLoading({ title: "移除中" }),
              wx.cloud.callFunction({
                name: "tradeAnonymous",
                data: {
                  fun: "deleteOtherHead",
                  actPlayerid: o,
                  isDebug: s.globalData.isDebug,
                  version: s.globalData.frontVersion,
                },
                success: function (e) {
                  (0, t.mylog)("_deleteOtherHead, res: ", e),
                    "fail" === e.result.type
                      ? (wx.hideLoading(),
                        wx.showModal({
                          content: e.result.msg,
                          showCancel: !1,
                          confirmText: "好的",
                        }))
                      : (n._dealRefresh(), wx.showToast({ title: "移除成功" }));
                },
                fail: function (s) {
                  wx.hideLoading(),
                    (0, t.mylog)("_deleteOtherHead, err: ", s),
                    (0, e.networkFail)(!1, s, "tradeAnonymous.deleteOtherHead");
                },
              })));
        },
      });
    },
    _showOtherHeadPop: function (e) {
      this.selectComponent("#signOtherHead").setActPlayerid(e._id),
        this.selectComponent("#signOtherHead").setGender(e._otherInfos.gender),
        this.selectComponent("#signOtherHead").showPop();
    },
    _deleteAnonymous: function (o) {
      var n = this;
      wx.showModal({
        content: "是否确定移除已设置的匿名？",
        confirmText: "移除",
        complete: function (a) {
          a.cancel ||
            (a.confirm &&
              (wx.showLoading({ title: "移除中" }),
              wx.cloud.callFunction({
                name: "tradeAnonymous",
                data: {
                  fun: "deleteAnonymous",
                  activityid: o._activityid,
                  playerid: o._playerid,
                  isDebug: s.globalData.isDebug,
                  version: s.globalData.frontVersion,
                },
                success: function (e) {
                  (0, t.mylog)("_deleteAnonymous, res: ", e),
                    "fail" === e.result.type
                      ? (wx.hideLoading(),
                        wx.showModal({
                          content: e.result.msg,
                          showCancel: !1,
                          confirmText: "好的",
                        }))
                      : (n._dealRefresh(), wx.showToast({ title: "移除成功" }));
                },
                fail: function (s) {
                  wx.hideLoading(),
                    (0, t.mylog)("_deleteAnonymous, err: ", s),
                    (0, e.networkFail)(!1, s, "tradeAnonymous.deleteAnonymous");
                },
              })));
        },
      });
    },
    _showAnonymousPop: function (e) {
      this.selectComponent("#anonymousSelf").setActPlayerid(e._id),
        this.selectComponent("#anonymousSelf").setGender(e._gender[0]),
        this.selectComponent("#anonymousSelf").showPop();
    },
    _dealByManager: function (t) {
      var s = this.data.activity,
        o = t.currentTarget.dataset.player,
        n = o._nickName[0];
      s._infos.isRealname && o._realName && o._realName.length > 0
        ? (n = o._realName[0])
        : o._anonymous &&
          o._anonymous.isAnonymous &&
          o._anonymous.nickName &&
          this.data.showPublic &&
          (n = o._anonymous.nickName),
        "retreat" === o._status
          ? "other" === o._signType
            ? o._playerid === this.data.selfid
              ? wx.showModal({
                  content:
                    "我的朋友" +
                    (0, e.cutString)(o._otherInfos.nickName, 8, !0),
                  showCancel: !1,
                  confirmText: "好的",
                })
              : wx.showModal({
                  content:
                    n +
                    "的朋友" +
                    (0, e.cutString)(o._otherInfos.nickName, 8, !0),
                  showCancel: !1,
                  confirmText: "好的",
                })
            : (0, e.multiRacePlayer)(s, o)
          : this._dealNormalByManager(t);
    },
    _dealNormalByManager: function (t) {
      var s = this,
        o = this.data.activity,
        n = t.currentTarget.dataset.player,
        a = n._nickName[0];
      if (
        (o._infos.isRealname && n._realName && n._realName.length > 0
          ? (a = n._realName[0])
          : n._anonymous &&
            n._anonymous.isAnonymous &&
            n._anonymous.nickName &&
            this.data.showPublic &&
            (a = n._anonymous.nickName),
        "other" === n._signType)
      ) {
        var i = a + "的朋友" + (0, e.cutString)(n._otherInfos.nickName, 8, !0);
        if (n._playerid === this.data.selfid)
          i = "我的朋友" + (0, e.cutString)(n._otherInfos.nickName, 8, !0);
        wx.showActionSheet({
          alertText: i,
          itemList: [
            n._isArrived ? "取消签到" : "签到",
            "修改带人",
            n._setOtherHead && n._setOtherHead.isSetted
              ? "移除头像"
              : "设置头像",
            "备注",
            "退坑",
          ],
          success: function (e) {
            switch (e.tapIndex) {
              case 0:
                n._isArrived ? s._dealArrived(n, !1) : s._dealArrived(n, !0);
                break;
              case 1:
                s
                  .selectComponent("#signOther")
                  .set({
                    gender: n._otherInfos.gender,
                    nickname: n._otherInfos.nickName,
                    level: n._otherInfos.level,
                    levelvice: n._otherInfos.levelvice,
                    activityPlayerid: n._id,
                  }),
                  s.selectComponent("#signOther").showPop();
                break;
              case 2:
                n._setOtherHead && n._setOtherHead.isSetted
                  ? s._deleteOtherHead(n._id)
                  : s._showOtherHeadPop(n);
                break;
              case 3:
                s.selectComponent("#postscript").setActivityPlayerid(n._id),
                  s.selectComponent("#postscript").setPostscript(n._postscript),
                  s.selectComponent("#postscript").setKind(n._signType),
                  s
                    .selectComponent("#postscript")
                    .setPlayerGender(n._otherInfos.gender),
                  s
                    .selectComponent("#postscript")
                    .setOtherHeadInfo(n._setOtherHead),
                  s.selectComponent("#postscript").showPop();
                break;
              case 4:
                s.setData({ retreatPlayer: n }),
                  s.selectComponent("#retreat").setActPlayer(n),
                  s.selectComponent("#retreat").showPop();
            }
          },
        });
      } else {
        i = a;
        n._playerid === this.data.selfid && (i += "（我自己）"),
          wx.showActionSheet({
            alertText: i,
            itemList: [
              n._isArrived ? "取消签到" : "签到",
              "备注",
              "退坑",
              "主页",
              n._anonymous && n._anonymous.isAnonymous ? "移除匿名" : "匿名",
            ],
            success: function (t) {
              switch (t.tapIndex) {
                case 0:
                  n._isArrived ? s._dealArrived(n, !1) : s._dealArrived(n, !0);
                  break;
                case 1:
                  s.selectComponent("#postscript").setActivityPlayerid(n._id),
                    s
                      .selectComponent("#postscript")
                      .setPostscript(n._postscript),
                    s.selectComponent("#postscript").setKind(n._signType),
                    s
                      .selectComponent("#postscript")
                      .setPlayerGender(n._gender[0]),
                    s
                      .selectComponent("#postscript")
                      .setSelfAnonymous(n._anonymous),
                    s.selectComponent("#postscript").showPop();
                  break;
                case 2:
                  s.setData({ retreatPlayer: n }),
                    s.selectComponent("#retreat").setActPlayer(n),
                    s.selectComponent("#retreat").showPop();
                  break;
                case 3:
                  (0, e.multiRacePlayer)(o, n);
                  break;
                case 4:
                  n._anonymous && n._anonymous.isAnonymous
                    ? s._deleteAnonymous(n)
                    : s._showAnonymousPop(n);
              }
            },
          });
      }
    },
    onRefreshByModify: function () {
      this._dealRefresh();
    },
    onChangeListType: function () {
      this.data.showPublic
        ? this.setData({ showPublic: !1 })
        : this.setData({ showPublic: !0 });
    },
  },
});
