module.exports = {
  getDefaultGroups: function () {
    return JSON.parse(JSON.stringify(n));
  },
};
var n = [
  { no: 1, name: "", limitMax: "", crtPerson: 0 },
  { no: 2, name: "", limitMax: "", crtPerson: 0 },
  { no: 3, name: "", limitMax: "", crtPerson: 0 },
  { no: 4, name: "", limitMax: "", crtPerson: 0 },
  { no: 5, name: "", limitMax: "", crtPerson: 0 },
];
