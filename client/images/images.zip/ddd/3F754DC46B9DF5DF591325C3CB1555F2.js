var a = require("BC366FB06B9DF5DFDA5007B7852555F2.js");
module.exports = Behavior({
  methods: {
    onSampleLoopSingles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b00064a7608e71531395cf5d4714e98d",
      });
    },
    onSampleLoopDoubles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=17453ede608b7a2305761bda3cd2ca91",
      });
    },
    onSampleDoubleLoopSingles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b00064a760c18f7d1f1112c717205fa6",
      });
    },
    onSampleDoubleLoopDoubles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=cbddf0af60c1bea80f6236595a98a741",
      });
    },
    onSampleEight_4: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b00064a760cd64ee2122c30a01acd7be",
      });
    },
    onSampleEight_5: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=28ee4e3e60cd631b237ac2894cb17095",
      });
    },
    onSampleEight_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=28ee4e3e60cd812c238276550def8d58",
      });
    },
    onSampleEight_9: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b00064a760cd815321294386593fc4ad",
      });
    },
    onSampleEight_10: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=5b049cc861f3c8ae098e742c7484da91",
      });
    },
    onSampleEight_12: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=17e3426e61dc65ec04908c7b49bd0a0c",
      });
    },
    onSampleEight_16: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=a72823ff6569f3ed01dbe5272527df49",
      });
    },
    onSampleEight_21: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=7027b6546569f52201c3e95f3248b924",
      });
    },
    onSampleMixRound_3_3: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=5026485b61a651a500f10de951bf7651",
      });
    },
    onSampleMixRound_4_4: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=908462d561a79b72013f45e43e746b4a",
      });
    },
    onSampleMixRound_5_5: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=5026485b61a7b5c90126504e3dd50594",
      });
    },
    onSampleMixRound_6_6: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=8937eaa961553f7a0ee4cb0774e932ee",
      });
    },
    onWeakStrong_6: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=f6e08a6462f2379a1298b21722d68fb2",
      });
    },
    onWeakStrong_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=8f75309d62f237bc140ce6287e56aaa1",
      });
    },
    onWeakStrong_10: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=8f75309d62f2381d140cecda2e026f78",
      });
    },
    onWeakStrong_12: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=058dfefe62f2382c147e65f75c7fe178",
      });
    },
    onSampleArenaDoubles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=93e4b6a0641745d1053825357e45d3dd",
      });
    },
    onSampleArenaSingles: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=0122a587640f51b3044ffa2d6732bf6e",
      });
    },
    onSampleTeamRound_55: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=09e787686586572c0482e8c9167e6779",
      });
    },
    onSampleTeamRound_66: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=0b153f9a6586574604751a16732050ec",
      });
    },
    onSampleTeamRound_88: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b751f28065865759047e46b54bf4a0e3",
      });
    },
    onSampleWheelMatch_5_5: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=25e993b76716161c106d765f244d4780",
      });
    },
    onSampleWheelMatch_552: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=9c1e6a31671618431069ea15149733ec",
      });
    },
    onSampleWheelMatch_8_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=9c1e6a3167161667106994206f220ddf",
      });
    },
    onSampleFreeMatch_5_5: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=a40fc074675d132b02c6d86519e33f18",
      });
    },
    onSampleFreeMatch_8_9: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b01b8517675d137702cceb6364950b01",
      });
    },
    onSampleFreeMatch_3_10: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=50de7f5d675d13c802c8a4d173f7c039",
      });
    },
    onSampleRelayMatch_6_6: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=50de7f5d675d140302c8aa7653733172",
      });
    },
    onSampleRelayMatch_7_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=cc3a4179675d141e02ce65bb58eed0de",
      });
    },
    onSampleFixedMatch_6_6: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=7456afe067cac12e0093514a5849affc",
      });
    },
    onSampleFixedMatch_8_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=faabc62d67cac1800092ca8470a25d0e",
      });
    },
    onSampleSinglesMatch_3_3: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=494059f767dfd7b800681b13195bd320",
      });
    },
    onSampleSinglesMatch_5_5: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=f5d5a75067dfd7d40067e8d47ed8be67",
      });
    },
    onSampleFixedRound_12: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=2da1518365f3df7d02679197546c73c9",
      });
    },
    onSampleSinglesRound_6: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=2da1518365f3dfe40267a2c74ddd4360",
      });
    },
    onSampleFreeRound_12: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=c45ba8cc6643363c00d0e0bd03511dd8",
      });
    },
    onSamplePromoteDoubles_16: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=8c9e276668a53a7102a17e391d6da5b8",
      });
    },
    onSamplePromoteDoubles_32: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=8041881a68a53aaf029d47e771e613c6",
      });
    },
    onSamplePromoteSingles_8: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=61d6cad968a53b3c0299539f7f1bd4e4",
      });
    },
    onSamplePromoteSingles_16: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=b9fa7faa68a53af802a2b0e07b8ebf9a",
      });
    },
    onSamplePromoteSingles_32: function () {
      (0, a.navTo)({
        url: "/packageC/pages/multiRace/multiRace?raceid=61d6cad968a53ad502994ead3857fd31",
      });
    },
    onContest: function (e) {
      var c = e.currentTarget.dataset.mode,
        n = e.currentTarget.dataset.type;
      c && n
        ? (0, a.navTo)({
            url:
              "/packageA/pages/mine/contest/contest?mode=" +
              c +
              "&raceType=" +
              n,
          })
        : (0, a.navTo)({ url: "/packageA/pages/mine/contest/contest" });
    },
    onGuider: function (e) {
      var c = e.currentTarget.dataset.type;
      (0, a.navTo)({ url: "/packageE/pages/guider/guider?type=" + c });
    },
    onLevels: function (e) {
      (0, a.navTo)({ url: "/packageE/pages/levels/levels" });
    },
    onSampleActivity: function () {
      (0, a.navTo)({
        url: "/pages/activity/activity?activityid=17453ede608aee090561323f45ba3ea5",
      });
    },
    onSampleClubActivity: function () {
      (0, a.navTo)({
        url: "/pages/activity/activity?activityid=cbddf0af6097ce1b076474197180ab26",
      });
    },
    onSampleClub: function () {
      (0, a.navTo)({
        url: "/packageD/pages/club/club?clubid=cbddf0af606bf36d00abcedb2e9e85f4",
      });
    },
    onSampleClubJustMember: function () {
      (0, a.navTo)({
        url: "/packageD/pages/club/club?clubid=14139e1261553fce105c49af4d4e580a",
      });
    },
    onVipFun: function (e) {
      var c = e.currentTarget.dataset.type;
      (0, a.navTo)({
        url: "/packageA/pages/vipfun/vipfun?action=open&type=" + c,
      });
    },
  },
});
