var o = require("BC366FB06B9DF5DFDA5007B7852555F2.js").dealBack;
module.exports = Behavior({
  data: { isShowPop: !1, zIndex: 0, popOpacity: 0 },
  methods: {
    showPop: function () {
      this.triggerEvent("showPop", {}, {}), this.showAnimate(), this.show();
    },
    show: function () {},
    showAnimate: function () {
      this.setData({ isShowPop: !0, zIndex: 9999 }),
        this.animate(
          "#popup",
          [{ opacity: 0 }, { opacity: 1 }],
          100,
          function () {}
        );
    },
    onClosePop: function () {
      this.closePop();
    },
    closePop: function () {
      this.triggerEvent("closePop", {}, {}), this.closeAnimate(), this.close();
    },
    close: function () {},
    closeAnimate: function () {
      var o = this;
      this.animate(
        "#popup",
        [{ opacity: 1 }, { opacity: 0 }],
        100,
        function () {
          o.setData({ isShowPop: !1, zIndex: 0 });
        }
      );
    },
    isShowingPop: function () {
      return this.data.isShowPop;
    },
    onDoNothing: function () {},
    onBack: function () {
      o();
    },
    setShow: function () {
      this.setData({ isShowPop: !0, zIndex: 9999, opacity: 1 });
    },
    setClose: function () {
      this.setData({ isShowPop: !1, zIndex: 0, opacity: 0 });
    },
  },
});
