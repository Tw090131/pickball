var e = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("981C1DB26B9DF5DFFE7A75B5964555F2.js");
module.exports = Behavior({
  data: {
    avatarUrl: "/images/userDefault.png",
    defaultUrl: "/images/userDefault.png",
    isLoaded: !1,
  },
  methods: {
    onChooseAvatar: function (e) {
      (0, a.mylog)("onChooseAvatar, e: ", e);
      var o = e.detail.avatarUrl;
      this._dealAvatar(o);
    },
    onShowLoading: function () {
      if (((0, a.mylog)("onShowLoading"), !this.data.isLoaded)) {
        wx.showLoading({ title: "加载中" }), this.setData({ isLoaded: !0 });
        var e = setTimeout(function () {
          wx.hideLoading({ success: function (e) {} }), clearTimeout(e);
        }, 1e3);
      }
    },
    _dealAvatar: function (o) {
      var t = this;
      wx.getImageInfo({
        src: o,
        success: function (e) {
          (0, a.mylog)("getImageInfo, res: ", e),
            e.width < 100 || e.height < 100
              ? wx.showToast({ title: "头像宽高至少100像素哦", icon: "none" })
              : e.height === e.width
              ? e.width <= 132
                ? (t.setData({ avatarUrl: o }), t._choosedAvatar())
                : t._compress(o)
              : t._dealNotEqual(o);
        },
        fail: function (o) {
          (0, a.mylog)("getImageInfo, err: ", o),
            (0, e.cloudLog)({ funName: "getImageInfo", type: "fail", err: o });
        },
      });
    },
    _dealNotEqual: function (o) {
      var t = this;
      wx.cropImage({
        src: o,
        cropScale: "1:1",
        success: function (o) {
          (0, a.mylog)("cropImage, res: ", o),
            -1 != o.tempFilePath.indexOf("wxfile://")
              ? t._compress(o.tempFilePath)
              : (wx.showModal({
                  content:
                    "此微信版本裁剪头像有bug，请升级至最新微信，或重新选择微信头像",
                  cancelText: "重选头像",
                  confirmText: "去升级",
                  success: function (e) {
                    e.cancel || (e.confirm && wx.updateWeChatApp());
                  },
                }),
                (0, e.cloudLog)({
                  funName: "cropImage",
                  type: "异常路径",
                  err: o,
                }));
        },
        fail: function (o) {
          (0, a.mylog)("cropImage, err: ", o),
            (0, e.cloudLog)({ funName: "cropImage", type: "fail", err: o });
        },
      });
    },
    _compress: function (o) {
      var t = this;
      (0, a.mylog)("_compress, srcUrl: ", o),
        wx.compressImage({
          src: o,
          compressedWidth: 132,
          quality: 60,
          success: function (e) {
            (0, a.mylog)("compressImage, res: ", e),
              t.setData({ avatarUrl: e.tempFilePath }),
              t._choosedAvatar();
          },
          fail: function (o) {
            (0, a.mylog)("compressImage, err: ", o),
              (0, e.cloudLog)({
                funName: "compressImage",
                type: "fail",
                err: o,
              });
          },
        });
    },
    _choosedAvatar: function () {},
  },
});
