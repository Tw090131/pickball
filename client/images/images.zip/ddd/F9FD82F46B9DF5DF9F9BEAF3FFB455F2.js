require("981C1DB26B9DF5DFFE7A75B5964555F2.js"), getApp();
module.exports = Behavior({
  data: { isBatchRetreating: !1, chooseList: [] },
  methods: {
    onRetreatBatch: function () {
      this.data.showAlternates.length <= 0
        ? wx.showToast({ title: "候补至少1人哦", icon: "none" })
        : this._initBatchRetreat(!0);
    },
    onCancelBatchRetreating: function () {
      this._initBatchRetreat(!1);
    },
    _initBatchRetreat: function (t) {
      for (var e = this.data.showAlternates, a = 0; a < e.length; a++)
        e[a].retreatChoosed = !1;
      this.setData({ isBatchRetreating: t, chooseList: [], showAlternates: e });
    },
    onChooseRetreat: function (t) {
      var e = this.data.chooseList,
        a = this.data.showAlternates,
        s = a[t.currentTarget.dataset.index];
      if (s.retreatChoosed) {
        s.retreatChoosed = !1;
        for (var o = 0; o < e.length; o++) {
          if (e[o]._id === s._id) {
            e.splice(o, 1);
            break;
          }
        }
      } else (s.retreatChoosed = !0), e.push(s);
      this.setData({ showAlternates: a, chooseList: e });
    },
    onBatchRetreatAll: function () {
      var t = this.data.chooseList,
        e = this.data.showAlternates;
      if (t.length === e.length) {
        for (var a = 0; a < e.length; a++) {
          e[a].retreatChoosed = !1;
        }
        t = [];
      } else {
        t = [];
        for (var s = 0; s < e.length; s++) {
          var o = e[s];
          (o.retreatChoosed = !0), t.push(o);
        }
      }
      this.setData({ showAlternates: e, chooseList: t });
    },
    onBatchReatreatConfirm: function () {
      if (this.data.chooseList.length <= 0)
        wx.showToast({ title: "请选择报名哦", icon: "none" });
      else {
        var t = this.selectComponent("#batchRetreat");
        t && (t.setRetreatList({ list: this.data.chooseList }), t.showPop());
      }
    },
    onBatchRetreatEnd: function () {
      this._initBatchRetreat(!1), this._dealRefresh();
    },
  },
});
