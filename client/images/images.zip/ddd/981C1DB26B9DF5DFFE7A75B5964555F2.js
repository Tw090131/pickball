var e = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null,
  a = getApp();
module.exports = {
  debug: function () {
    e && !a.globalData.isDebug && e.debug.apply(e, arguments);
  },
  info: function () {
    e && !a.globalData.isDebug && e.info.apply(e, arguments);
  },
  warn: function () {
    e && !a.globalData.isDebug && e.warn.apply(e, arguments);
  },
  error: function () {
    e && !a.globalData.isDebug && e.error.apply(e, arguments);
  },
  setFilterMsg: function (a) {
    e && e.setFilterMsg && "string" == typeof a && e.setFilterMsg(a);
  },
  mylog: function () {
    var e;
    (a || (a = getApp()), a.globalData.isConsoleLog) &&
      (e = console).log.apply(
        e,
        [new Date().getTime()].concat(Array.prototype.slice.call(arguments))
      );
  },
  myerr: function () {
    var e;
    (a || (a = getApp()), a.globalData.isConsoleLog) &&
      (e = console).error.apply(
        e,
        [new Date().getTime()].concat(Array.prototype.slice.call(arguments))
      );
  },
};
