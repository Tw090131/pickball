var e = require("@babel/runtime/helpers/objectSpread2.js"),
  a = require("AEF83EF16B9DF5DFC89E56F6DB3555F2.js"),
  t = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  s = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = require("88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  n = getApp();
module.exports = Behavior({
  data: {
    headsConfig: (0, a.getHeadsConfig)(),
    type: "activity",
    actPlayerid: "",
    gender: 1,
    crtItemIdx: 0,
    nickName: "",
    isInputed: !1,
    secretLevel: !1,
    onlyOtherNick: !1,
    avatarUrl: "",
    isAgree: !0,
  },
  methods: {
    setActPlayerid: function (e) {
      this.setData({ type: "activity", actPlayerid: e });
    },
    setGender: function (e) {
      this.setData({ gender: e }), this._dealCrtItemIdx(), this._dealNickName();
    },
    onGenderHead: function () {
      this.setData({ headsType: "genderHead" }),
        this._dealCrtItemIdx(),
        this._dealNickName();
    },
    onRoleHead: function () {
      this.setData({ headsType: "roleHead" }),
        this._dealCrtItemIdx(),
        this._dealNickName();
    },
    onSecretHead: function () {
      this.setData({ headsType: "secretHead" }),
        this._dealCrtItemIdx(),
        this._dealNickName();
    },
    _dealCrtItemIdx: function () {
      var e = this.data.headsConfig.genderHeads;
      switch (this.data.headsType) {
        case "genderHead":
          e = this.data.headsConfig.genderHeads;
          break;
        case "roleHead":
          e = this.data.headsConfig.roleHeads;
          break;
        case "secretHead":
          e = this.data.headsConfig.secretHeads;
          break;
        case "customHead":
          return;
      }
      this.data.gender >= 2
        ? this.data.crtItemIdx > e.woman.length - 1 &&
          this.setData({ crtItemIdx: e.woman.length - 1 })
        : this.data.crtItemIdx > e.man.length - 1 &&
          this.setData({ crtItemIdx: e.man.length - 1 });
    },
    onSelectHead: function (e) {
      this.setData({ crtItemIdx: e.currentTarget.dataset.index }),
        this._dealNickName();
    },
    _dealNickName: function () {
      if (
        ((0, s.mylog)("nickName: ", this.data.nickName), !this.data.isInputed)
      ) {
        var e = this.data.headsConfig;
        switch (this.data.headsType) {
          case "genderHead":
            var a = e.genderHeads.man;
            this.data.gender >= 2 && (a = e.genderHeads.woman),
              this.setData({ nickName: a[this.data.crtItemIdx].name });
            break;
          case "roleHead":
            a = e.roleHeads.man;
            this.data.gender >= 2 && (a = e.roleHeads.woman),
              this.setData({ nickName: a[this.data.crtItemIdx].name });
            break;
          case "secretHead":
            a = e.secretHeads.man;
            this.data.gender >= 2 && (a = e.secretHeads.woman),
              this.setData({ nickName: a[this.data.crtItemIdx].name });
            break;
          case "customHead":
            this.setData({ nickName: "" });
        }
      }
    },
    onCustomHead: function () {
      this.setData({ headsType: "customHead" }), this._dealNickName();
    },
    onChooseImage: function () {
      var e = this;
      wx.chooseMedia({
        count: 1,
        mediaType: ["image"],
        success: function (a) {
          (0, s.mylog)("onChooseImage, res: ", a),
            e._dealAvatar(a.tempFiles[0].tempFilePath);
        },
        fail: function (e) {
          (0, s.mylog)("onChooseImage, err: ", e),
            (0, t.cloudLog)({ funName: "chooseMedia", type: "fail", err: e });
        },
      });
    },
    _dealAvatar: function (e) {
      var a = this;
      wx.getImageInfo({
        src: e,
        success: function (t) {
          (0, s.mylog)("getImageInfo, res: ", t),
            t.width < 100 || t.height < 100
              ? wx.showToast({ title: "头像宽高至少100像素哦", icon: "none" })
              : t.height === t.width
              ? t.width <= 132
                ? a.setData({ avatarUrl: e })
                : a._compress(e)
              : a._dealNotEqual(e);
        },
        fail: function (e) {
          (0, s.mylog)("getImageInfo, err: ", e),
            (0, t.cloudLog)({ funName: "getImageInfo", type: "fail", err: e });
        },
      });
    },
    _dealNotEqual: function (e) {
      var a = this;
      wx.cropImage({
        src: e,
        cropScale: "1:1",
        success: function (e) {
          (0, s.mylog)("cropImage, res: ", e),
            -1 != e.tempFilePath.indexOf("wxfile://")
              ? a._compress(e.tempFilePath)
              : (wx.showModal({
                  content: "此微信版本裁剪头像有bug，请升级至最新微信",
                  cancelText: "暂不",
                  confirmText: "去升级",
                  success: function (e) {
                    e.cancel || (e.confirm && wx.updateWeChatApp());
                  },
                }),
                (0, t.cloudLog)({
                  funName: "cropImage",
                  type: "异常路径",
                  err: e,
                }));
        },
        fail: function (e) {
          (0, s.mylog)("cropImage, err: ", e),
            (0, t.cloudLog)({ funName: "cropImage", type: "fail", err: e });
        },
      });
    },
    _compress: function (e) {
      var a = this;
      (0, s.mylog)("_compress, srcUrl: ", e),
        wx.compressImage({
          src: e,
          compressedWidth: 132,
          quality: 60,
          success: function (e) {
            (0, s.mylog)("compressImage, res: ", e),
              a.setData({ avatarUrl: e.tempFilePath });
          },
          fail: function (e) {
            (0, s.mylog)("compressImage, err: ", e),
              (0, t.cloudLog)({
                funName: "compressImage",
                type: "fail",
                err: e,
              });
          },
        });
    },
    onDelCustomHead: function () {
      this.setData({ avatarUrl: "" });
    },
    onNickInput: function (e) {
      this.setData({ nickName: e.detail.value, isInputed: !!e.detail.value });
    },
    onSecretLevel: function () {
      this.data.secretLevel
        ? this.setData({ secretLevel: !1 })
        : this.setData({ secretLevel: !0 });
    },
    onOnlyOtherNick: function () {
      (0, s.mylog)("onOnlyOtherNick"),
        this.data.onlyOtherNick
          ? this.setData({ onlyOtherNick: !1 })
          : this.setData({ onlyOtherNick: !0 }),
        (0, s.mylog)("onlyOtherNick: ", this.data.onlyOtherNick);
    },
    onAgree: function () {
      this.data.isAgree
        ? this.setData({ isAgree: !1 })
        : this.setData({ isAgree: !0 });
    },
    onPayConfirm: function () {
      if (this.data.isAgree)
        if (
          (this.data.activity &&
            this.data.activity._infos &&
            this.data.activity._infos.isRealname &&
            (this.data.nickName = ""),
          !this.data.nickName || this.data.nickName.trim())
        ) {
          var e = this.data.headsConfig.genderHeads;
          switch (this.data.headsType) {
            case "genderHead":
              e = this.data.headsConfig.genderHeads;
              break;
            case "roleHead":
              e = this.data.headsConfig.roleHeads;
              break;
            case "secretHead":
              e = this.data.headsConfig.secretHeads;
          }
          switch (
            ((e = 1 === this.data.gender ? e.man : e.woman),
            this.data.headsType)
          ) {
            case "genderHead":
            case "roleHead":
            case "secretHead":
              "self" === this.data.kind
                ? this._dealPaySelfAnonymous(e)
                : this._dealPaySetOther(e);
              break;
            case "customHead":
              this._upLoadFile();
          }
        } else
          wx.showToast({
            title: "请输入有效昵称",
            icon: "none",
            duration: 2500,
          });
      else wx.showToast({ title: "请同意协议哦", icon: "none" });
    },
    _dealPaySelfAnonymous: function (e) {
      var a = this;
      wx.showLoading({ title: "支付中", mask: !0 });
      var t = this.data.headsConfig;
      wx.cloud.callFunction({
        name: "tradeAnonymous",
        data: {
          fun: "selfAnonymous",
          actPlayerid: this.data.actPlayerid,
          anonymous: {
            headType: this.data.headsType,
            headid: e[this.data.crtItemIdx].id,
            headurl: t.path + e[this.data.crtItemIdx].file,
            nickName: this.data.nickName.trim(),
            secretLevel: this.data.secretLevel,
          },
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          if (
            ((0, s.mylog)("selfAnonymous, res: ", e), "fail" === e.result.type)
          )
            a.triggerEvent("refresh", {}, {}),
              wx.hideLoading(),
              wx.showModal({
                content: e.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
          else {
            var t = e.result.payment.payment;
            a._wxPay(t, e.result.detail._id, null);
          }
        },
        fail: function (e) {
          (0, s.mylog)("selfAnonymous, err: ", e);
        },
      });
    },
    _dealPaySetOther: function (e) {
      var a = this;
      wx.showLoading({ title: "支付中", mask: !0 });
      var t = this.data.headsConfig;
      wx.cloud.callFunction({
        name: "tradeAnonymous",
        data: {
          fun: "setOtherHead",
          actPlayerid: this.data.actPlayerid,
          setOtherHead: {
            headType: this.data.headsType,
            headid: e[this.data.crtItemIdx].id,
            headurl: t.path + e[this.data.crtItemIdx].file,
            onlyOtherNick: this.data.onlyOtherNick,
          },
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          if (
            ((0, s.mylog)("setOtherHead, res: ", e), "fail" === e.result.type)
          )
            a.triggerEvent("refresh", {}, {}),
              wx.hideLoading(),
              wx.showModal({
                content: e.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
          else {
            var t = e.result.payment.payment;
            a._wxPay(t, e.result.detail._id, null);
          }
        },
        fail: function (e) {
          (0, s.mylog)("setOtherHead, err: ", e);
        },
      });
    },
    _wxPay: function (a, t, i) {
      var n = this;
      wx.requestPayment(
        e(
          e({}, a),
          {},
          {
            success: function (e) {
              (0, s.mylog)("_wxPay success", e),
                n.triggerEvent("refresh", {}, {}),
                n.triggerEvent("anonySuccess", {}, {}),
                "self" === n.data.kind
                  ? wx.showToast({ title: "匿名成功" })
                  : wx.showToast({ title: "头像设置成功" }),
                n.closeAnimate();
            },
            fail: function (e) {
              (0, s.mylog)("_wxPay fail", e),
                wx.hideLoading(),
                n._dealCancelPay(t, i);
            },
          }
        )
      );
    },
    _dealCancelPay: function (e, a) {
      wx.cloud.callFunction({
        name: "tradeAnonymous",
        data: {
          fun: "cancelPay",
          tradeDetailid: e,
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          (0, s.mylog)("_dealCancelPay, res:", e);
        },
        fail: function (e) {
          (0, s.mylog)("_dealCancelPay, err: ", e);
        },
      }),
        a &&
          wx.cloud.deleteFile({
            fileList: [a],
            success: function (e) {
              (0, s.mylog)("deleteFile: ", e.fileList);
            },
            fail: function (e) {
              (0, s.mylog)("deleteFile, err: ", a, e);
            },
          });
    },
    _upLoadFile: function () {
      var e = this;
      this.data.avatarUrl
        ? (wx.showLoading({ title: "支付中", mask: !0 }),
          wx.cloud.uploadFile({
            cloudPath: (0, i.makeAvatarPath)(this.data.avatarUrl),
            filePath: this.data.avatarUrl,
            success: function (a) {
              (0, s.mylog)("uploadFile, res: ", a), e._getUrl(a.fileID);
            },
            fail: function (e) {
              (0, s.mylog)("uploadFile, err: ", e),
                wx.showToast({ title: "系统繁忙，请重试", icon: "none" });
            },
          }))
        : wx.showToast({ title: "请先上传头像", icon: "none" });
    },
    _getUrl: function (e) {
      var a = this;
      wx.cloud.getTempFileURL({
        fileList: [e],
        success: function (t) {
          (0, s.mylog)("getUrl, res: ", t),
            t.fileList.length <= 0
              ? wx.showToast({ title: "系统繁忙，请重试", icon: "none" })
              : "self" === a.data.kind
              ? a._dealPaySelfAnonymousCustom(t.fileList[0].tempFileURL, e)
              : a._dealPaySetOtherCustom(t.fileList[0].tempFileURL, e);
        },
        fail: function (e) {
          (0, s.mylog)("getUrl, err: ", e),
            wx.showToast({ title: "系统繁忙，请重试", icon: "none" });
        },
      });
    },
    _dealPaySelfAnonymousCustom: function (e, a) {
      var t = this;
      wx.cloud.callFunction({
        name: "tradeAnonymous",
        data: {
          fun: "selfAnonymous",
          actPlayerid: this.data.actPlayerid,
          anonymous: {
            headType: "customHead",
            headurl: e,
            fileID: a,
            nickName: this.data.nickName.trim(),
            secretLevel: this.data.secretLevel,
          },
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          if (
            ((0, s.mylog)("selfAnonymous, res: ", e), "fail" === e.result.type)
          )
            t.triggerEvent("refresh", {}, {}),
              wx.hideLoading(),
              wx.showModal({
                content: e.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
          else {
            var i = e.result.payment.payment;
            t._wxPay(i, e.result.detail._id, a);
          }
        },
        fail: function (e) {
          (0, s.mylog)("selfAnonymous, err: ", e);
        },
      });
    },
    _dealPaySetOtherCustom: function (e, a) {
      var t = this;
      wx.cloud.callFunction({
        name: "tradeAnonymous",
        data: {
          fun: "setOtherHead",
          actPlayerid: this.data.actPlayerid,
          setOtherHead: {
            headType: "customHead",
            headurl: e,
            fileID: a,
            onlyOtherNick: this.data.onlyOtherNick,
          },
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          if (
            ((0, s.mylog)("setOtherHead, res: ", e), "fail" === e.result.type)
          )
            t.triggerEvent("refresh", {}, {}),
              wx.hideLoading(),
              wx.showModal({
                content: e.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
          else {
            var i = e.result.payment.payment;
            t._wxPay(i, e.result.detail._id, a);
          }
        },
        fail: function (e) {
          (0, s.mylog)("setOtherHead, err: ", e);
        },
      });
    },
  },
});
