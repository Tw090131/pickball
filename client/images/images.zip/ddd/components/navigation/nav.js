Component({
  properties: {
    switchList: {
      type: Array,
      value: [
        { type: "singles", text: "单打场" },
        { type: "doubles", text: "双打场" },
      ],
    },
    crtType: { type: String, value: "singles" },
    mode: { type: String, value: "top" },
    range: { type: String, value: "" },
    vertical: { type: Boolean, value: !1 },
    height: { type: String, value: "100vh" },
    width: { type: String, value: "15vw" },
  },
  data: {},
  methods: {
    onSwitchType: function (t) {
      var e = t.currentTarget.dataset.type;
      e != this.data.crtType &&
        (this.setData({ crtType: e }),
        this.triggerEvent("navchange", { type: e }, {}));
    },
  },
});
