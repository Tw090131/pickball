var e = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js");
Component({
  properties: {
    title: { type: String, value: "羽毛球助手" },
    url: { type: String, value: "" },
    titleSize: { type: Number, value: 32 },
    loading: { type: Boolean, value: !1 },
    showInterAd: { type: Boolean, value: !1 },
    picUrl: { type: String, value: "" },
  },
  data: {
    index: "/pages/index/index",
    tabPages: ["/pages/index/index", "/pages/mine/mine"],
    showMenu: !0,
    leftMenu: "",
    navInfo: (0, e.getNavInfo)(),
    isTabPage: !0,
    pagesLength: 1,
  },
  lifetimes: {
    attached: function () {
      this.setData({
        isTabPage: -1 != this.data.tabPages.indexOf(this.data.url),
        pagesLength: getCurrentPages().length,
      });
    },
  },
  pageLifetimes: { show: function () {} },
  methods: {
    setTitle: function (e) {
      this.setData({ title: e });
    },
    setLeftMenu: function (e) {
      this.setData({ leftMenu: e });
    },
    showMenu: function () {
      this.setData({ showMenu: !0 });
    },
    hideMenu: function () {
      this.setData({ showMenu: !1 });
    },
    onIndex: function () {
      wx.switchTab({ url: this.data.index });
    },
    onBack: function () {
      this.data.showInterAd
        ? this.triggerEvent("navBack", {}, {})
        : (0, e.dealBack)();
    },
    onTitle: function () {
      this.triggerEvent("clickTitle", {}, {});
    },
  },
});
