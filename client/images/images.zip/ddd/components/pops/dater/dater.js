var e = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [e],
  properties: {},
  data: {
    weeks: {
      abbr: ["日", "一", "二", "三", "四", "五", "六"],
      full: [
        "星期日",
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六",
      ],
    },
    selDay: "",
    showDays: "",
    today: "",
  },
  lifetimes: {
    attached: function () {
      this.init(null);
    },
  },
  methods: {
    init: function (e) {
      for (var t = new Date(), a = [], n = t.getDay(), r = 0; r < n; r++)
        a.push(null);
      for (var i = t.getTime(), s = 0; s < 70; s++) {
        var o = new Date(i + 864e5 * s);
        a.push({
          year: o.getFullYear(),
          month: o.getMonth() + 1,
          day: o.getDate(),
          weekDay: o.getDay(),
        });
      }
      for (var h = 7 * Math.ceil((r + 70) / 7), l = r + 70; l < h; l++)
        a.push(null);
      var u = new Date(i + 0),
        y = {
          year: u.getFullYear(),
          month: u.getMonth() + 1,
          day: u.getDate(),
          weekDay: u.getDay(),
        },
        D = {
          year: t.getFullYear(),
          month: t.getMonth() + 1,
          day: t.getDate(),
          weekDay: t.getDay(),
        };
      null != e && (this._getMil(e) < this._getMil(D) || (y = e)),
        this.setData({
          selDay: y,
          today: D,
          showDays: this._apart(a),
          initSelDay: JSON.parse(JSON.stringify(y)),
        });
    },
    _getMil: function (e) {
      var t = e.year + "/" + e.month + "/" + e.day;
      return new Date(t).getTime();
    },
    _apart: function (e) {
      for (var t = [], a = [], n = 0; n < e.length; n++)
        (n + 1) % 7 == 0 ? (a.push(e[n]), t.push(a), (a = [])) : a.push(e[n]);
      return t;
    },
    onChangeDate: function (e) {
      var t = e.currentTarget.dataset.date;
      null != t && this.setData({ selDay: t });
    },
    onConfirm: function (e) {
      this.triggerEvent("selectDate", { date: this.data.selDay }, {}),
        this.closeAnimate();
    },
  },
});
