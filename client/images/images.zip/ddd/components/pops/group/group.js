var a = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  n = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  t = require("../../../F3C93A716B9DF5DF95AF527671F155F2.js");
Component({
  behaviors: [n, t],
  properties: { infos: { type: Object, value: "" } },
  data: { status: "mainFuns", groups: [] },
  methods: {
    show: function () {
      var n = this.data.infos,
        t = !1;
      n.groupCanPlayer && (t = n.groupCanPlayer);
      var r = !1;
      n.groupOnlyManager && (r = n.groupOnlyManager);
      var o = n.groups;
      (o = o ? (0, a.copyArr)(o) : null),
        this.setData({
          status: "mainFuns",
          changed: !1,
          groups: o,
          groupCanPlayer: t,
          groupOnlyManager: r,
        });
    },
    onGroupCanotPlayer: function () {
      this.setData({ groupCanPlayer: !1, changed: !0 });
    },
    onGroupCanPlayer: function () {
      this.setData({ groupCanPlayer: !0, groupOnlyManager: !1, changed: !0 }),
        this.data.groups ||
          this.setData({ groups: this._initGroups(this.data.infos.figures) });
    },
    onGroupsInit: function () {
      var a = this,
        n = this.data.infos;
      wx.showModal({
        content: "将清空已有分组，是否继续？",
        cancelText: "点错了",
        confirmText: "初始化",
        complete: function (t) {
          t.cancel ||
            (t.confirm && a.setData({ groups: a._initGroups(n.figures) }));
        },
      });
    },
    onFunsIntro: function () {
      this.setData({ status: "funsIntro" });
    },
    onMainFuns: function () {
      this.setData({ status: "mainFuns" });
    },
    onConfirm: function () {
      var a = this.data.infos;
      (a.groupCanPlayer = this.data.groupCanPlayer),
        (a.groupOnlyManager = this.data.groupOnlyManager);
      var n = this.data.groups;
      if (n)
        for (var t = 0; t < n.length; t++)
          (n[t].no = t + 1), (n[t].name = n[t].name.trim());
      (a.groups = n),
        this.closeAnimate(),
        this.triggerEvent("groupEdited", { infos: a }, {});
    },
  },
});
