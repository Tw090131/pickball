var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  s = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  a = getApp();
Component({
  behaviors: [s],
  properties: {
    clubid: { type: String, value: "" },
    byManager: { type: Boolean, value: !1 },
    assessOther: { type: Boolean, value: !1 },
    isSetRange: { type: Boolean, value: !1 },
    rangeKind: { type: String, value: "min" },
    memid: { type: String, value: "" },
    memLevel: { type: Number, value: -1 },
    memVice: { type: Number, value: 2 },
    isCertified: { type: Boolean, value: !1 },
  },
  data: { crtLevel: -1, crtVice: 2 },
  observers: {
    memLevel: function () {
      this.data.isShowPop ||
        this.setData({
          crtLevel: this.data.memLevel,
          crtVice: this.data.memVice,
        });
    },
  },
  lifetimes: {
    attached: function () {
      this.setData({
        crtLevel: this.data.memLevel,
        crtVice: this.data.memVice,
      });
    },
  },
  methods: {
    show: function () {
      this.setData({
        crtLevel: this.data.memLevel,
        crtVice: this.data.memVice,
      });
    },
    setInfos: function (e) {
      (0, t.mylog)("setInfos infos: ", e),
        this.setData({
          memid: e.memid,
          memLevel: e.memLevel,
          memVice: e.memVice,
          crtLevel: e.memLevel,
          crtVice: e.memVice,
        });
    },
    onSelectLevel: function (e) {
      this.setData({ crtLevel: e.currentTarget.dataset.level, crtVice: 2 });
    },
    onSelectVice: function (e) {
      this.setData({ crtVice: e.currentTarget.dataset.vice });
    },
    onConfirm: function () {
      this.data.assessOther || this.data.isSetRange
        ? (this.closeAnimate(),
          this.triggerEvent(
            "assessed",
            { level: this.data.crtLevel, vice: this.data.crtVice },
            {}
          ))
        : this.data.byManager
        ? this._dealClubAssess()
        : this._dealSelfAssess();
    },
    _dealClubAssess: function () {
      var e = this;
      wx.showLoading({ title: "设置中", mask: !0 }),
        wx.cloud.callFunction({
          name: "club",
          data: {
            fun: "setMemLevel",
            clubid: this.data.clubid,
            memid: this.data.memid,
            level: this.data.crtLevel,
            levelvice: this.data.crtVice,
            lvCertified: !0,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (s) {
            (0, t.mylog)("_dealClubAssess, res: ", s),
              e.triggerEvent("setlevel", {}, {}),
              e.closeAnimate();
          },
          fail: function (e) {
            (0, t.mylog)("_dealClubAssess, err: ", e);
          },
        });
    },
    _dealSelfAssess: function () {
      var e = this;
      wx.showLoading({ title: "自评中", mask: !0 }),
        wx.cloud.callFunction({
          name: "user",
          data: {
            fun: "setLevel",
            level: this.data.crtLevel,
            levelvice: this.data.crtVice,
            lvCertified: !1,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (s) {
            (0, t.mylog)("_dealSelfAssess, res: ", s),
              e.triggerEvent("setlevel", {}, {}),
              e.closeAnimate();
          },
          fail: function (e) {
            (0, t.mylog)("_dealSelfAssess, err: ", e);
          },
        });
    },
    onLevels: function () {
      (0, e.navTo)({ url: "/packageE/pages/levels/levels?type=level" });
    },
    onDetail: function () {
      (0, e.navTo)({
        url: "/packageE/pages/levels/levels?level=" + this.data.crtLevel,
      });
    },
  },
});
