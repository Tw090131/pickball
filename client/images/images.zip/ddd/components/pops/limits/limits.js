var e = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../4528E4C36B9DF5DF234E8CC44FF455F2.js"),
  a = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  i = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [i],
  properties: {
    infos: { type: Object, value: "" },
    kind: { type: String, value: "race" },
  },
  data: {
    configs: (0, t.getMultiConfig)(),
    crtManLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
    crtWomanLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
    crtRetreatTime: 0,
    crtRangeType: "open",
    crtRealname: !1,
    crtNeedPhone: !1,
    crtBanShare: !1,
  },
  observers: {
    infos: function () {
      (0, e.mylog)("observers, infos"), this._init();
    },
  },
  methods: {
    show: function () {
      (0, e.mylog)("limit show"), this._init();
    },
    _init: function () {
      var e = this.data.infos,
        t = { islimit: !1, min: 0, max: 10 },
        a = { islimit: !1, min: 0, max: 10 };
      e.manLevel &&
        "womanSingles" != e.type &&
        "womanDoubles" != e.type &&
        (t = e.manLevel),
        e.womanLevel &&
          "manSingles" != e.type &&
          "manDoubles" != e.type &&
          (a = e.womanLevel);
      var i = e.isRealname;
      i || (i = !1);
      var n = e.needPhone;
      n || (n = !1);
      var o = e.banShare;
      o || (o = !1),
        this.setData({
          crtManLevel: JSON.parse(JSON.stringify(t)),
          crtWomanLevel: JSON.parse(JSON.stringify(a)),
          crtRetreatTime: e.retreatTime,
          crtRangeType: e.rangeType,
          crtRealname: i,
          crtNeedPhone: n,
          crtBanShare: o,
        });
    },
    onManNolimit: function () {
      this.setData({ "crtManLevel.islimit": !1 });
    },
    onManLimit: function (e) {
      var t = this.selectComponent("#levelRangeMan");
      t &&
        (t.setLevelInfo({
          gender: 1,
          crtLevel: this.data.crtManLevel,
          clubid: this.data.infos.clubid,
        }),
        t.showPop());
    },
    onSetLevelMan: function (e) {
      var t = e.detail.level;
      this.setData({
        crtManLevel: {
          islimit: !0,
          min: t.min,
          max: t.max,
          justCertified: t.justCertified,
        },
      });
    },
    onWomanNolimit: function () {
      this.setData({ "crtWomanLevel.islimit": !1 });
    },
    onWomanLimit: function (e) {
      var t = this.selectComponent("#levelRangeWoman");
      t &&
        (t.setLevelInfo({
          gender: 2,
          crtLevel: this.data.crtWomanLevel,
          clubid: this.data.infos.clubid,
        }),
        t.showPop());
    },
    onSetLevelWoman: function (e) {
      var t = e.detail.level;
      this.setData({
        crtWomanLevel: {
          islimit: !0,
          min: t.min,
          max: t.max,
          justCertified: t.justCertified,
        },
      });
    },
    onRetreatNolimit: function () {
      this.setData({ crtRetreatTime: 0 });
    },
    onRetreatTime: function (t) {
      (0, e.mylog)("onRetreatTime, e: ", t),
        this.setData({ crtRetreatTime: parseInt(t.detail.value) + 1 });
    },
    onRetreatCancel: function (t) {
      (0, e.mylog)("onRetreatCancel, e: ", t),
        this.setData({ crtRetreatTime: this.data.crtRetreatTime });
    },
    onClubNolimit: function () {
      this.setData({ crtRangeType: "open" });
    },
    onClubMember: function () {
      this.setData({ crtRangeType: "clubMember" });
    },
    onRealnameNolimit: function () {
      this.setData({ crtRealname: !1 });
    },
    onRealname: function () {
      this.setData({ crtRealname: !0 });
    },
    onNeedPhoneNolimit: function () {
      this.setData({ crtNeedPhone: !1 });
    },
    onNeedPhone: function () {
      this.setData({ crtNeedPhone: !0 });
    },
    onBanShareNolimit: function () {
      this.setData({ crtBanShare: !1 });
    },
    onBanShare: function () {
      this.setData({ crtBanShare: !0 });
    },
    onConfirm: function () {
      var e = this.data.infos;
      (e.manLevel = this.data.crtManLevel),
        (e.womanLevel = this.data.crtWomanLevel),
        (e.retreatTime = this.data.crtRetreatTime),
        (e.rangeType = this.data.crtRangeType),
        (e.isRealname = this.data.crtRealname),
        (e.needPhone = this.data.crtNeedPhone),
        (e.banShare = this.data.crtBanShare),
        this.triggerEvent("setlimits", { infos: e }, {}),
        this.closePop();
    },
    onLevels: function () {
      (0, a.navTo)({ url: "/packageE/pages/levels/levels" });
    },
  },
});
