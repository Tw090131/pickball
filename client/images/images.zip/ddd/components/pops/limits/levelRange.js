var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [t],
  properties: {},
  data: {
    gender: 1,
    crtLevel: { min: 0, max: 10, justCertified: !1 },
    levelViceMin: { level: 0, vice: 2 },
    levelViceMax: { level: 10, vice: 2 },
    clubid: "",
  },
  methods: {
    setLevelInfo: function (t) {
      var i = {
        min: t.crtLevel.min,
        max: t.crtLevel.max,
        justCertified: t.crtLevel.justCertified,
      };
      t.crtLevel.islimit || (i = { min: 0, max: 10 }),
        this.setData({
          gender: t.gender,
          crtLevel: i,
          levelViceMin: (0, e.viceLevel)(i.min),
          levelViceMax: (0, e.viceLevel)(i.max),
          clubid: t.clubid,
        });
    },
    onLevelMin: function () {
      var e = this.selectComponent("#levelMin");
      e && e.showPop();
    },
    onSetLevelMin: function (t) {
      var i = t.detail.level,
        l = t.detail.vice;
      this.setData({
        levelViceMin: { level: i, vice: l },
        "crtLevel.min": (0, e.calcLevel)(i, l),
      });
    },
    onLevelMax: function () {
      var e = this.selectComponent("#levelMax");
      e && e.showPop();
    },
    onSetLevelMax: function (t) {
      var i = t.detail.level,
        l = t.detail.vice;
      this.setData({
        levelViceMax: { level: i, vice: l },
        "crtLevel.max": (0, e.calcLevel)(i, l),
      });
    },
    onNeedLevelCertify: function () {
      this.data.crtLevel.justCertified
        ? this.setData({ "crtLevel.justCertified": !1 })
        : this.setData({ "crtLevel.justCertified": !0 });
    },
    onConfirm: function () {
      this.data.crtLevel.min > this.data.crtLevel.max
        ? wx.showToast({ title: "最低不能大于最高哦", icon: "none" })
        : (this.triggerEvent("setLevel", { level: this.data.crtLevel }, {}),
          this.closeAnimate());
    },
    onLevelUseful: function () {
      wx.showModal({
        content:
          "勾选【仅限认证等级】后，只有在当前俱乐部内有认证等级，且符合条件的会员才能报名",
        cancelText: "用法",
        confirmText: "好的",
        complete: function (t) {
          t.cancel &&
            (0, e.navTo)({ url: "/packageE/pages/levels/levels?type=simple" });
        },
      });
    },
  },
});
