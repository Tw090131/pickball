var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  r = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  o = require("../../../AA67DAD16B9DF5DFCC01B2D660E155F2.js");
Component({
  behaviors: [r, o],
  properties: {},
  data: { kind: "other", headsType: "genderHead" },
  methods: {
    onAgreement: function () {
      (0, e.navTo)({ url: "/packageA/pages/mine/agreement/paySetOther" });
    },
  },
});
