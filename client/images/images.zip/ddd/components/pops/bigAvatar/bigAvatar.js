var o = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [o],
  properties: {},
  data: { user: "", baseWidth: 264, zoom: 0 },
  methods: {
    init: function (o) {
      this.setData({ user: o.user, zoom: 0 });
    },
    onNarrow: function () {
      var o = this.data.zoom - 1;
      o < -7
        ? wx.showToast({ title: "已经最小了哦", icon: "none", duration: 1200 })
        : this.setData({ zoom: o });
    },
    onEnlarge: function () {
      var o = this.data.zoom + 1;
      o > 7
        ? wx.showToast({ title: "已经最大了哦", icon: "none", duration: 1200 })
        : this.setData({ zoom: o });
    },
  },
});
