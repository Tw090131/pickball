var e = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  a = getApp();
Component({
  behaviors: [t],
  properties: {
    activity: { type: Object, value: "" },
    playerInfo: { type: Object, value: "" },
    raceInfo: { type: Object, value: "" },
    isManage: { type: Boolean, value: !1 },
    classify: { type: String, value: "activity" },
    showPublic: { type: Boolean, value: !0 },
  },
  data: {
    reason: "",
    multyPlayerid: "",
    isPayed: !1,
    tradeDetailid: "",
    clubFeeDetailid: "",
    canRetreat: !0,
    isAlternater: !1,
  },
  methods: {
    show: function () {
      this.data.playerInfo && this.data.activity
        ? ((0, e.mylog)("show playerInfo: ", this.data.playerInfo),
          this.setData({ canRetreat: this._judgeOK() }))
        : this.setData({ canRetreat: !0 });
    },
    setActPlayer: function (e) {
      this.setData({
        actPlayerid: e._id,
        isPayed: e._isPayed,
        tradeDetailid: e._tradeDetailid,
        clubFeeDetailid: e._clubFeeDetailid,
      });
    },
    setMultyPlayerid: function (e) {
      this.setData({
        multyPlayerid: e.multyPlayerid,
        isPayed: e.isPayed,
        tradeDetailid: e.tradeDetailid,
        clubFeeDetailid: e.clubFeeDetailid,
        isAlternater: e.isAlternater,
      });
    },
    onReasonInput: function (e) {
      this.setData({ reason: e.detail.value });
    },
    onWork: function () {
      this.setData({ reason: "加班搬砖..." });
    },
    onBusy: function () {
      this.setData({ reason: "抱歉，临时有事" });
    },
    onParty: function () {
      this.setData({ reason: "另外有约会了~" });
    },
    onWounds: function () {
      this.setData({ reason: "要养伤，浑身疼" });
    },
    onMiss: function () {
      this.setData({ reason: "赶不过来了" });
    },
    onChange: function () {
      this.setData({ reason: "更换号位" });
    },
    onRetreat: function () {
      "activity" === this.data.classify
        ? this._dealActivityRetreat()
        : this._dealMultiRaceRetreat();
    },
    _dealActivityRetreat: function () {
      (0, e.mylog)("restreat playerInfo: ", this.data.playerInfo),
        this.data.isManage
          ? this._dealRetreatNO(this.data.playerInfo._id)
          : this._judgeOK()
          ? "self" === this.data.playerInfo._signType
            ? this._dealRetreatSelf()
            : this._dealRetreatNO(this.data.playerInfo._id)
          : wx.showModal({
              content:
                "已超过约定退坑期限了哦，若有特殊情况，您可以跟组织者协商退坑",
              showCancel: !1,
              confirmText: "好的",
            });
    },
    _judgeOK: function () {
      return (
        !!this.data.playerInfo._isAlternate ||
        new Date().getTime() <=
          this.data.activity._startTimeMil -
            60 * this.data.activity._infos.retreatTime * 60 * 1e3
      );
    },
    _dealRetreatSelf: function () {
      var t = this;
      wx.showLoading({ title: "退坑中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "retreatSelf",
            activityid: this.data.activity._id,
            reason: this.data.reason,
            isAlternate: this.data.playerInfo._isAlternate,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            (0, e.mylog)("retreatSelf: ", a),
              t.triggerEvent("refresh", {}, {}),
              t.closeAnimate(),
              "success" != a.result.type
                ? wx.showModal({
                    content: a.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  })
                : t._dealRetreatAct();
          },
          fail: function (t) {
            (0, e.mylog)("retreatSelf err: ", t);
          },
        });
    },
    _dealRetreatAct: function () {
      var e = this;
      if (
        this.data.isPayed &&
        (this.data.tradeDetailid || this.data.clubFeeDetailid)
      )
        this.data.isManage
          ? (wx.hideLoading({ success: function (e) {} }),
            this.data.tradeDetailid
              ? wx.showModal({
                  content:
                    "退坑成功，是否继续退款？（若不退款，再次退款请线下转账）",
                  cancelText: "不退款",
                  confirmText: "退款",
                  success: function (t) {
                    t.cancel || (t.confirm && e._dealRefund("tradeActivity"));
                  },
                })
              : wx.showModal({
                  content:
                    "退坑成功，是否继续退会费？（若不退会费，再次退会费请手动操作）",
                  cancelText: "不退会费",
                  confirmText: "退会费",
                  success: function (t) {
                    t.cancel || (t.confirm && e._dealRefund("tradeActivity"));
                  },
                }))
          : this._dealRefund("tradeActivity");
      else {
        wx.showToast({ title: "退坑成功", duration: 800 });
        var t = setTimeout(function () {
          e.triggerEvent("retreatOK", {}, {}), clearTimeout(t);
        }, 1e3);
      }
    },
    _dealRetreatNO: function (t) {
      var i = this;
      wx.showLoading({ title: "退坑中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "retreatNO",
            activityid: this.data.activity._id,
            activityPlayerid: t,
            reason: this.data.reason,
            isAlternate: this.data.playerInfo._isAlternate,
            isManage: this.data.isManage,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (t) {
            (0, e.mylog)("retreatNO: ", t),
              i.triggerEvent("refresh", {}, {}),
              i.closeAnimate(),
              "success" != t.result.type
                ? wx.showModal({
                    content: t.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  })
                : i._dealRetreatAct();
          },
          fail: function (t) {
            (0, e.mylog)("retreatNO err: ", t);
          },
        });
    },
    _dealMultiRaceRetreat: function () {
      var e = this,
        t = this.data.raceInfo._infos.mode;
      if ("freeRound" === t || "freeMatch" === t || "relayMatch" === t) {
        var a = this.data.raceInfo;
        this.data.isManage
          ? this.data.isAlternater ||
            (a.singleRaceCount && 0 === a.singleRaceCount.all)
            ? this._deleteSingleRacesByPlayer(!0)
            : this._retreatByManageWithSingleCount()
          : a.singleRaceCount && a.singleRaceCount.self
          ? "relayMatch" === t
            ? wx.showModal({
                content:
                  "您已参与对阵，接力赛连续追分，不能随意退出，请联系组织者删除对阵后再退赛",
                showCancel: !1,
                confirmText: "好的",
              })
            : wx.showModal({
                content:
                  "您退赛的话，本次比赛已参与对阵都将被移除，是否确定退赛？",
                cancelText: "暂不",
                confirmText: "退赛",
                complete: function (t) {
                  t.cancel || (t.confirm && e._deleteSingleRacesByPlayer());
                },
              })
          : this._deleteSingleRacesByPlayer(!0);
      } else this._todoMultiRaceRetreat();
    },
    _retreatByManageWithSingleCount: function () {
      var t = this;
      wx.showLoading({ title: "准备中", mask: !0 }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "getSingleCountByPlayer",
            raceid: this.data.raceInfo._id,
            multyPlayerid: this.data.multyPlayerid,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            ((0, e.mylog)("getSingleCountByPlayer: res", a),
            "fail" === a.result.type)
              ? (wx.hideLoading(),
                wx.showModal({
                  content: a.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                }))
              : a.result.singleCount
              ? (wx.hideLoading(),
                "relayMatch" === t.data.raceInfo._infos.mode
                  ? wx.showModal({
                      content:
                        "该选手已参与对阵，接力赛连续追分，请删除相关对阵后再将其退赛",
                      showCancel: !1,
                      confirmText: "好的",
                    })
                  : wx.showModal({
                      content:
                        "若该选手退赛，其本次比赛已参与对阵都将被移除，是否确定将其退赛？",
                      cancelText: "暂不",
                      confirmText: "退赛",
                      complete: function (e) {
                        e.cancel ||
                          (e.confirm && t._deleteSingleRacesByPlayer());
                      },
                    }))
              : t._deleteSingleRacesByPlayer(!0);
          },
          fail: function (t) {
            (0, e.mylog)("getSingleCountByPlayer, err: ", t);
          },
        });
    },
    _deleteSingleRacesByPlayer: function (t) {
      var i = this;
      t
        ? wx.showLoading({ title: "退赛中", mask: !0 })
        : wx.showLoading({ title: "移除对阵中", mask: !0 }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "deleteSingleRacesByPlayer",
            raceid: this.data.raceInfo._id,
            operator: this.data.isManage ? "manager" : "self",
            multyPlayerid: this.data.multyPlayerid,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (t) {
            (0, e.mylog)("deleteSingleRacesByPlayer res: ", t),
              "fail" === t.result.type
                ? (wx.hideLoading(),
                  wx.showModal({
                    content: t.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }))
                : i._todoMultiRaceRetreat();
          },
          fail: function (t) {
            (0, e.mylog)("deleteSingleRacesByPlayer err: ", t);
          },
        });
    },
    _todoMultiRaceRetreat: function () {
      var t = this;
      wx.showLoading({ title: "退赛中" }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "retreatPlayer",
            raceid: this.data.raceInfo._id,
            operator: this.data.isManage ? "manager" : "self",
            multyPlayerid: this.data.multyPlayerid,
            reason: this.data.reason,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            if (
              ((0, e.mylog)("retreatPlayer res: ", a),
              t.triggerEvent("refresh", {}, {}),
              t.closeAnimate(),
              "fail" === a.result.type)
            )
              wx.showModal({
                content: a.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
            else if (
              t.data.isPayed &&
              (t.data.tradeDetailid || t.data.clubFeeDetailid)
            )
              t.data.isManage
                ? (wx.hideLoading({ success: function (e) {} }),
                  t.data.tradeDetailid
                    ? wx.showModal({
                        content:
                          "退赛成功，是否继续退款？（若不退款，再次退款请线下转账）",
                        cancelText: "不退款",
                        confirmText: "退款",
                        success: function (e) {
                          e.cancel || (e.confirm && t._dealRefund("tradeRace"));
                        },
                      })
                    : wx.showModal({
                        content:
                          "退赛成功，是否继续退会费？（若不退会费，再次退会费请手动操作）",
                        cancelText: "不退会费",
                        confirmText: "退会费",
                        success: function (e) {
                          e.cancel || (e.confirm && t._dealRefund("tradeRace"));
                        },
                      }))
                : t._dealRefund("tradeRace");
            else {
              wx.showToast({ title: "退赛成功", duration: 800 });
              var i = setTimeout(function () {
                t.triggerEvent("retreatOK", {}, {}), clearTimeout(i);
              }, 1e3);
            }
          },
          fail: function (t) {
            (0, e.mylog)("retreatPlayer err: ", t);
          },
        });
    },
    _dealRefund: function (t) {
      var i = this,
        n = "退款";
      this.data.clubFeeDetailid && (n = "退会费"),
        wx.showLoading({ title: n + "中", mask: !0 }),
        wx.cloud.callFunction({
          name: t,
          data: {
            fun: "refund",
            tradeDetailid: this.data.tradeDetailid,
            clubFeeDetailid: this.data.clubFeeDetailid,
            isManage: this.data.isManage,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            (0, e.mylog)(t + "._dealRefund, res: ", a),
              "fail" === a.result.type
                ? wx.showModal({
                    content: a.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  })
                : (wx.showToast({ title: n + "成功", duration: 1e3 }),
                  i.triggerEvent("retreatOK", {}, {}));
          },
          fail: function (a) {
            (0, e.mylog)(t + "._dealRefund, err: ", a);
          },
          complete: function (e) {
            var t = setTimeout(function () {
              wx.hideLoading({ success: function (e) {} }), clearTimeout(t);
            }, 1100);
          },
        });
    },
  },
});
