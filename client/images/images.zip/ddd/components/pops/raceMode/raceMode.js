var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  o = require("../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js"),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [t, o],
  properties: {},
  data: {
    crtType: "doubles",
    crtTypeIdx: 0,
    switchList: [
      { type: "doubles", text: "双打" },
      { type: "singles", text: "单打" },
      { type: "match", text: "对抗" },
    ],
    doubles: [
      { mode: "eight", name: "八人转 / 超八转", intro: "4 - 50人，轮换搭档" },
      {
        mode: "mixRound",
        name: "混双转",
        intro: "4 - 36人，每男跟每女各搭档1次",
      },
      {
        mode: "fixedRound",
        name: "固搭转",
        intro: "4 - 40人，每对组合比赛N次",
      },
      {
        mode: "freeRound",
        name: "自由转",
        intro: "4 - 50人，自由安排选手对阵",
      },
      {
        mode: "loop",
        name: "单循环积分赛",
        intro: "每对选手跟其他选手各对阵1次",
      },
      {
        mode: "weakStrong",
        name: "前后转",
        intro: "4 - 36人，前半和后半各对阵1次",
      },
      {
        mode: "doubleLoop",
        name: "双循环积分赛",
        intro: "每对选手跟其他选手各对阵2次",
      },
      { mode: "arena", name: "擂台赛", intro: "擂主和每对攻擂选手各对阵1次" },
    ],
    singles: [
      {
        mode: "singlesRound",
        name: "单打转",
        intro: "2 - 20人，每位选手比赛N次",
      },
      {
        mode: "freeRound",
        name: "自由转",
        intro: "2 - 50人，自由安排选手对阵",
      },
      {
        mode: "loop",
        name: "单循环积分赛",
        intro: "每位选手和其他选手各比赛1次",
      },
      { mode: "arena", name: "擂台赛", intro: "擂主和每位攻擂选手各比赛1次" },
      {
        mode: "doubleLoop",
        name: "双循环积分赛",
        intro: "每位选手和其他选手各比赛2次",
      },
    ],
    matches: [
      { mode: "teamRound", name: "小队转", intro: "每队2-20人，队内各搭档1次" },
      {
        mode: "wheelMatch",
        name: "轮比转",
        intro: "每队2-16人，队内前后轮转搭档",
      },
      {
        mode: "freeMatch",
        name: "自由对抗赛",
        intro: "每队2-18人，自由安排选手对阵",
      },
      {
        mode: "fixedMatch",
        name: "固搭对抗赛",
        intro: "每队2-20人，队间固搭各对阵1次",
      },
      {
        mode: "relayMatch",
        name: "接力赛",
        intro: "自由安排选手对阵，按顺序接力",
      },
      {
        mode: "singlesMatch",
        name: "单打对抗赛",
        intro: "每队1-10人，队间选手各对阵1次",
      },
    ],
    teams: [],
    crtMode: "eight",
  },
  methods: {
    setModeType: function (e) {
      var o = this;
      (0, a.mylog)("setModeType: ", e);
      var t = "";
      switch (e.mode) {
        case "eight":
        case "eightSuper":
        case "mixRound":
        case "weakStrong":
        case "fixedRound":
          t = "doubles";
          break;
        case "singlesRound":
        case "loop":
        case "doubleLoop":
        case "arena":
        case "promote":
        case "freeRound":
          t =
            -1 != e.raceType.indexOf("Singles") ||
            -1 != e.raceType.indexOf("singles")
              ? "singles"
              : "doubles";
          break;
        case "teamRound":
        case "wheelMatch":
        case "relayMatch":
        case "normalMatch":
        case "freeMatch":
        case "fixedMatch":
        case "singlesMatch":
        case "communicate":
          t = "match";
          break;
        case "grading":
        case "classic":
        case "eightTeams":
          t = "teams";
      }
      var s = setTimeout(function () {
        o.setData({
          crtType: t,
          crtTypeIdx: o._getTypeIndex(t),
          crtMode: e.mode,
        }),
          clearTimeout(s);
      }, 300);
    },
    onModeSelect: function (e) {
      var a = e.currentTarget.dataset.mode;
      this.setData({ crtMode: a });
    },
    onLevels: function () {
      var a = this.data.crtMode,
        o = this.data.crtType;
      (0, e.navTo)({
        url:
          "/packageA/pages/mine/contest/contest?mode=" + a + "&raceType=" + o,
      });
    },
    onConfirm: function () {
      (0, a.mylog)(
        "onConfirm, mode: ",
        this.data.crtMode,
        ", crtType: ",
        this.data.crtType
      );
      var e = "nolimitDoubles";
      switch (this.data.crtMode) {
        case "eight":
        case "eightSuper":
        case "mixRound":
        case "weakStrong":
        case "fixedRound":
          e = "nolimitDoubles";
          break;
        case "singlesRound":
        case "loop":
        case "doubleLoop":
        case "arena":
        case "promote":
        case "freeRound":
          e =
            "singles" === this.data.crtType
              ? "nolimitSingles"
              : "nolimitDoubles";
          break;
        case "teamRound":
        case "wheelMatch":
        case "relayMatch":
        case "normalMatch":
        case "freeMatch":
        case "fixedMatch":
        case "communicate":
          e = "nolimitDoubles";
          break;
        case "singlesMatch":
          e = "nolimitSingles";
      }
      this.triggerEvent(
        "modeSelected",
        { mode: this.data.crtMode, raceType: e },
        {}
      ),
        this.closeAnimate();
    },
  },
});
