require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js");
var e = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
getApp();
Component({
  behaviors: [e],
  properties: {
    infos: { type: Object, value: "" },
    configs: { type: Object, value: "" },
  },
  data: {
    figuresType: "byAll",
    figures: 16,
    figuresMan: 8,
    figuresWoman: 8,
    manFigures: [
      "男不可报名",
      "男1人",
      "男2人",
      "男3人",
      "男4人",
      "男5人",
      "男6人",
      "男7人",
      "男8人",
    ],
    womanFigures: [
      "女不可报名",
      "女1人",
      "女2人",
      "女3人",
      "女4人",
      "女5人",
      "女6人",
      "女7人",
      "女8人",
    ],
  },
  methods: {
    show: function () {
      var e = this.data.infos,
        s = this.data.infos.figuresType;
      s || (s = "byAll"),
        "byAll" === s
          ? this.setData({ figuresType: s, figures: e.figures })
          : this.setData({
              figuresType: s,
              figuresMan: e.figuresMan,
              figuresWoman: e.figuresWoman,
            });
    },
    onFiguresTypeByAll: function () {
      this.setData({ figuresType: "byAll" });
    },
    onFiguresTypeByGender: function () {
      this.setData({ figuresType: "byGender" });
    },
    onFiguresChangeByAll: function (e) {
      var s = parseInt(e.detail.value);
      this.setData({ figures: s + 2 });
    },
    onFiguresChangeByGender: function (e) {
      var s = parseInt(e.detail.value[0]),
        i = parseInt(e.detail.value[1]);
      this.setData({ figuresMan: s, figuresWoman: i });
    },
    onPersonConfirm: function () {
      if (
        "byGender" !== this.data.figuresType ||
        0 !== this.data.figuresMan ||
        0 !== this.data.figuresWoman
      ) {
        var e = this.data.infos;
        (e.figuresType = this.data.figuresType),
          "byAll" === this.data.figuresType
            ? (e.figures = this.data.figures)
            : ((e.figuresMan = this.data.figuresMan),
              (e.figuresWoman = this.data.figuresWoman));
      } else
        wx.showModal({
          content: "按性别限报名人数时，男女至少有一方超过1人哦",
          showCancel: !1,
          confirmText: "好的",
        });
    },
  },
});
