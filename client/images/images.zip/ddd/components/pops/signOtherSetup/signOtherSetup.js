var t = require("../../../9CD29CB36B9DF5DFFAB4F4B41AA455F2.js"),
  i =
    (require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
    require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
    require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"));
Component({
  behaviors: [i],
  properties: { infos: { type: Object, value: "" } },
  data: { configs: (0, t.getConfig)() },
  methods: {
    setInfos: function (t) {
      this.setData({ infos: JSON.parse(JSON.stringify(t)) });
    },
    onCanOther: function () {
      this.setData({ "infos.signOther": "canOther" });
    },
    onOnlySelf: function () {
      this.setData({ "infos.signOther": "onlySelf" });
    },
    onSignOtherLimitChange: function (t) {
      var i = parseInt(t.detail.value);
      this.setData({
        "infos.signOther": "canOther",
        "infos.signOtherLimit": i,
      });
    },
    onConfirm: function () {
      this.triggerEvent("setSignOther", { infos: this.data.infos }, {}),
        this.closePop();
    },
  },
});
