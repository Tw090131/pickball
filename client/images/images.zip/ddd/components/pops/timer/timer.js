var n = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
getApp();
Component({
  options: { pureDataPattern: /^_/ },
  behaviors: [t],
  properties: {},
  data: {
    hours: [
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
      21, 22, 23,
    ],
    minutes: [
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
      21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
      39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
      57, 58, 59,
    ],
    durations: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    valueHour: [19],
    valueMinute: [0],
    valueDuration: [2],
    valueEndhour: [21],
    valueEndMinute: [0],
    _selTimer: "",
    startHourChanging: !1,
    startMinuteChanging: !1,
    endHourChanging: !1,
    endMinuteChanging: !1,
  },
  lifetimes: {
    attached: function () {
      this.init(null);
    },
  },
  methods: {
    init: function (t) {
      for (var e = [], i = 0; i < 24; i++) {
        var a = i;
        e.push(a);
      }
      for (var u = [], o = 0; o < 60; o += 1) {
        var r = "" + o;
        o < 10 && (r = "0" + o), u.push(r);
      }
      for (var s = [], h = 1; h <= 12; h++) {
        var d = h + "小时";
        s.push(d);
      }
      var g = { hour: 19, minute: 0, duration: 2, endhour: 21, endminute: 0 };
      null != t &&
        (g = JSON.parse(JSON.stringify(t))).duration &&
        !g.endhour &&
        0 != g.endhour &&
        ((g.endhour = (g.hour + g.duration) % 24), (g.endminute = g.minute)),
        this.setData({
          hours: e,
          minutes: u,
          durations: s,
          valueHour: [g.hour],
          valueMinute: [parseInt(g.minute / 1)],
          valueDuration: [g.duration - 1],
          valueEndHour: [g.endhour],
          valueEndMinute: [parseInt(g.endminute / 1)],
          _selTimer: g,
          startHourChanging: !1,
          startMinuteChanging: !1,
          endHourChanging: !1,
          endMinuteChanging: !1,
        }),
        (0, n.mylog)("timer init: ", this.data);
    },
    onHourChange: function (t) {
      (0, n.mylog)("onHourChange: ", t);
      var e = this.data._selTimer;
      (e.hour = t.detail.value[0]),
        this.setData({ _selTimer: e }),
        (0, n.mylog)("选择时：", e.hour);
    },
    onMinuteChange: function (t) {
      (0, n.mylog)("onMinuteChange: ", t);
      var e = this.data._selTimer;
      (e.minute = 1 * t.detail.value[0]),
        this.setData({ _selTimer: e }),
        (0, n.mylog)("选择分：", e.minute);
    },
    onEndHourChange: function (t) {
      (0, n.mylog)("onEndHourChange: ", t);
      var e = this.data._selTimer;
      (e.endhour = t.detail.value[0]),
        this.setData({ _selTimer: e }),
        (0, n.mylog)("选择时：", e.endhour);
    },
    onEndMinuteChange: function (t) {
      (0, n.mylog)("onEndMinuteChange: ", t);
      var e = this.data._selTimer;
      (e.endminute = 1 * t.detail.value[0]),
        this.setData({ _selTimer: e }),
        (0, n.mylog)("选择分：", e.endminute);
    },
    onStarthourPickStart: function () {
      this.setData({ startHourChanging: !0 });
    },
    onStarthourPickEnd: function () {
      this.setData({ startHourChanging: !1 });
    },
    onStartminutePickStart: function () {
      this.setData({ startMinuteChanging: !0 });
    },
    onStartminutePickEnd: function () {
      this.setData({ startMinuteChanging: !1 });
    },
    onEndhourPickStart: function () {
      this.setData({ endHourChanging: !0 });
    },
    onEndhourPickEnd: function () {
      this.setData({ endHourChanging: !1 });
    },
    onEndminutePickStart: function () {
      this.setData({ endMinuteChanging: !0 });
    },
    onEndminutePickEnd: function () {
      this.setData({ endMinuteChanging: !1 });
    },
    onConfirm: function () {
      if (
        ((0, n.mylog)("onConfirm: ", this.data._selTimer),
        this.data.startHourChanging ||
          this.data.startMinuteChanging ||
          this.data.endHourChanging ||
          this.data.endMinuteChanging)
      )
        wx.showToast({ title: "操作太快了哦", icon: "none" });
      else {
        var t = this.data._selTimer;
        if (this._checkTimerOK(t))
          60 * t.hour + t.minute >= 60 * t.endhour + t.endminute
            ? wx.showToast({ title: "开始时间得小于结束时间", icon: "none" })
            : (this.triggerEvent(
                "selcetTimer",
                { time: this.data._selTimer },
                {}
              ),
              this.closeAnimate(),
              (0, n.mylog)("点击确定"));
        else wx.showToast({ title: "操作太快了哦", icon: "none" });
      }
    },
    _checkTimerOK: function (n) {
      return (
        !(!n.hour && 0 != n.hour) &&
        !(!n.minute && 0 != n.minute) &&
        !(!n.endhour && 0 != n.endhour) &&
        !(!n.endminute && 0 != n.endminute)
      );
    },
  },
});
