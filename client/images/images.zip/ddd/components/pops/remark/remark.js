var e = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [t],
  properties: {
    remarks: { type: String, value: "" },
    navInfo: { type: Object, value: { height: 88 } },
  },
  data: { keyHeight: 0 },
  methods: {
    onKeyboardHeight: function (t) {
      (0, e.mylog)("onKeyboardHeight, e:", t),
        t.detail.height != this.data.keyHeight &&
          this.setData({ keyHeight: t.detail.height });
    },
    onRemarksInput: function (e) {
      this.setData({ remarks: e.detail.value }),
        this.triggerEvent("fullRemarksInput", { value: e.detail.value }, {});
    },
  },
});
