var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = (getApp(), require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"));
Component({
  behaviors: [i],
  properties: { page: { type: String, value: "login" } },
  data: {},
  methods: {
    onService: function () {
      (0, e.navTo)({ url: "/packageA/pages/mine/agreement/service" });
    },
    onPrivacy: function () {
      (0, t.mylog)("onPrivacy"),
        wx.openPrivacyContract
          ? wx.openPrivacyContract()
          : wx.showModal({
              content: "请升级至最新微信，查看隐私政策",
              cancelText: "暂不",
              confirmText: "去升级",
              success: function (e) {
                e.cancel || (e.confirm && wx.updateWeChatApp());
              },
            });
    },
    onReject: function () {
      this.closeAnimate(), this.triggerEvent("privacyReject", {}, {});
    },
    onAgreePrivacyAuthorization: function () {
      this.closeAnimate(), this.triggerEvent("privacyAgree", {}, {});
    },
  },
});
