var e = require("../../../@babel/runtime/helpers/objectSpread2"),
  a = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp(),
  n = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [n],
  properties: {},
  data: {
    type: "",
    subtype: "self",
    gender: "",
    fee: "",
    raceid: "",
    playerNO: "",
    isAlternate: !1,
    activityid: "",
    nickname: "",
    level: "",
    levelvice: "",
    isAgree: !0,
    anonymous: "",
    selectGroupNo: "",
  },
  methods: {
    setPayforRace: function (e) {
      (0, t.mylog)("setPayforRace: ", e),
        this.setData({
          type: e.type,
          fee: e.fee,
          raceid: e.raceid,
          playerNO: e.playerNO,
          isAlternate: e.isAlternate,
          isAgree: e.fee <= 50,
        });
    },
    setPayforActivity: function (e) {
      (0, t.mylog)("setPayforActivity: ", e),
        this.setData({
          type: e.type,
          subtype: e.subtype,
          gender: e.gender,
          fee: e.fee,
          activityid: e.activityid,
          nickname: e.nickname,
          level: e.level,
          levelvice: e.levelvice,
          anonymous: e.anonymous,
          isAgree: e.fee <= 50,
          selectGroupNo: e.selectGroupNo,
        });
    },
    onAgree: function () {
      this.data.isAgree
        ? this.setData({ isAgree: !1 })
        : this.setData({ isAgree: !0 });
    },
    onAgreement: function () {
      switch (this.data.type) {
        case "race":
          (0, a.navTo)({ url: "/packageA/pages/mine/agreement/payRace" });
          break;
        case "activity":
          (0, a.navTo)({
            url: "/packageA/pages/mine/agreement/payRace?type=activity",
          });
      }
    },
    onPayConfirm: function () {
      this.data.isAgree
        ? "race" === this.data.type
          ? this._dealPayRace()
          : this._dealPayActivity()
        : wx.showToast({ title: "请同意付款和退款协议", icon: "none" });
    },
    _dealPayRace: function () {
      var e = this;
      wx.showLoading({ title: "支付中", mask: !0 }),
        wx.cloud.callFunction({
          name: "tradeRace",
          data: {
            fun: "joinCharge",
            raceInfo: {
              raceid: this.data.raceid,
              playerNO: this.data.playerNO,
            },
            playerNO: this.data.playerNO,
            isAlternate: this.data.isAlternate,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (a) {
            if (
              ((0, t.mylog)("tradeRace.joinCharge, res: ", a),
              "fail" === a.result.type)
            )
              e.triggerEvent("refresh", {}, {}),
                wx.hideLoading(),
                wx.showModal({
                  content: a.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              var i = a.result.payment.payment;
              (0, t.mylog)("payment res: ", i),
                e._wxPay(i, a.result.detail._id);
            }
          },
          fail: function (e) {
            (0, t.mylog)(e), (0, a.networkFail)(!1, e, "tradeRace.joinCharge");
          },
        });
    },
    _dealPayActivity: function () {
      var e = this;
      wx.showLoading({ title: "支付中", mask: !0 });
      var n = void 0;
      "signOther" === this.data.subtype &&
        (n = {
          gender: this.data.gender,
          nickname: this.data.nickname,
          level: this.data.level,
          levelvice: this.data.levelvice,
        }),
        wx.cloud.callFunction({
          name: "tradeActivity",
          data: {
            fun: "joinCharge",
            actInfo: {
              activityid: this.data.activityid,
              subtype: this.data.subtype,
              gender: this.data.gender,
            },
            signType: this.data.subtype,
            signOtherInfo: n,
            anonymous: this.data.anonymous,
            selectGroupNo: this.data.selectGroupNo,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (a) {
            if (
              ((0, t.mylog)("tradeActivity.joinCharge, res: ", a),
              "fail" === a.result.type)
            )
              e.triggerEvent("refresh", {}, {}),
                wx.hideLoading(),
                wx.showModal({
                  content: a.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              var i = a.result.payment.payment;
              (0, t.mylog)("payment res: ", i),
                e._wxPay(i, a.result.detail._id);
            }
          },
          fail: function (e) {
            (0, t.mylog)(e), (0, a.networkFail)(!1, e, "tradeRace.joinCharge");
          },
        });
    },
    _wxPay: function (a, i) {
      var n = this;
      wx.requestPayment(
        e(
          e({}, a),
          {},
          {
            success: function (e) {
              (0, t.mylog)("_wxPay success", e),
                n.triggerEvent("paySuccess", { tradeDetailid: i }, {}),
                n.closeAnimate();
            },
            fail: function (e) {
              (0, t.mylog)("_wxPay fail", e),
                wx.hideLoading({ success: function (e) {} }),
                n._dealCancelPay(i);
            },
          }
        )
      );
    },
    _dealCancelPay: function (e) {
      var n = "tradeRace";
      "activity" === this.data.type && (n = "tradeActivity"),
        wx.cloud.callFunction({
          name: n,
          data: {
            fun: "cancelPay",
            tradeDetailid: e,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (e) {
            (0, t.mylog)("_dealCancelPay, res:", e);
          },
          fail: function (e) {
            (0, t.mylog)("_dealCancelPay, err: ", e),
              (0, a.networkFail)(!1, e, n + ".cancelPay");
          },
        });
    },
  },
});
