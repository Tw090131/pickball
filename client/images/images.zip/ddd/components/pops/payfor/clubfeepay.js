var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp(),
  a = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [a],
  properties: {
    activity: { type: Object, value: "" },
    raceInfo: { type: Object, value: "" },
  },
  data: {
    clubid: "",
    type: "",
    subtype: "self",
    costKind: "normal",
    gender: "",
    fee: "",
    raceid: "",
    playerNO: "",
    isAlternate: !1,
    activityid: "",
    nickname: "",
    level: "",
    levelvice: "",
    anonymous: "",
    selectGroupNo: "",
  },
  methods: {
    setPayforRace: function (e) {
      (0, t.mylog)("setPayforRace: ", e),
        this.setData({
          clubid: e.clubid,
          type: e.type,
          costKind: e.costKind,
          fee: e.costFee,
          raceid: e.raceid,
          playerNO: e.playerNO,
          isAlternate: e.isAlternate,
        });
    },
    setPayforActivity: function (e) {
      (0, t.mylog)("setPayforActivity: ", e),
        this.setData({
          clubid: e.clubid,
          type: e.type,
          subtype: e.subtype,
          costKind: e.costKind,
          gender: e.gender,
          fee: e.costFee,
          activityid: e.activityid,
          nickname: e.nickname,
          level: e.level,
          levelvice: e.levelvice,
          anonymous: e.anonymous,
          selectGroupNo: e.selectGroupNo,
        });
    },
    setPayforReceipt: function (e) {
      (0, t.mylog)("setPayforReceipt: ", e),
        this.setData({
          clubid: e.clubid,
          type: e.type,
          costKind: e.costKind,
          fee: e.costFee,
          receiptid: e.receiptid,
        });
    },
    onClubFeeRecharge: function () {
      (0, e.navTo)({
        url:
          "/packageD/pages/club/club?clubid=" + this.data.clubid + "&type=me",
      });
    },
    onPayConfirm: function () {
      "receipt" === this.data.type
        ? this._dealPayReceipt()
        : "race" === this.data.type
        ? this._dealPayRace()
        : this._dealPayActivity();
    },
    _dealPayRace: function () {
      var a = this;
      wx.showLoading({ title: "报名中", mask: !0 }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "clubfeePayJoin",
            raceInfo: {
              clubid: this.data.clubid,
              raceid: this.data.raceid,
              playerNO: this.data.playerNO,
              isAlternate: this.data.isAlternate,
            },
            checkUnreceived: !0,
            costKind: this.data.costKind,
            costFee: 100 * this.data.fee,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (i) {
            if (
              ((0, t.mylog)("multiRace.clubfeePayJoin, res: ", i),
              a.triggerEvent("refresh", {}, {}),
              "fail" === i.result.type)
            )
              if ((wx.hideLoading(), i.result.listUnrceived)) {
                var c = "请先完成未付款账单，否则不能报名该";
                "alone" != a.data.raceInfo._infos.clubid
                  ? (c += "俱乐部")
                  : (c += "组织者"),
                  (c += "的新比赛哦"),
                  wx.showModal({
                    content: c,
                    showCancel: !1,
                    confirmText: "账单详情",
                    complete: function (t) {
                      if (t.confirm) {
                        var i = a.data.raceInfo._creatorid,
                          c = a.data.raceInfo._infos.clubid;
                        (0, e.navTo)({
                          url:
                            "/packageA/pages/mine/myBill/unReceived?creatorid=" +
                            i +
                            "&clubid=" +
                            c,
                        });
                      }
                    },
                  });
              } else
                wx.showModal({
                  content: i.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              a.closeAnimate();
              var o = setTimeout(function () {
                a.triggerEvent(
                  "clubfeePayJoined",
                  { multiRacePlayerid: i.result.multiRacePlayerid },
                  {}
                ),
                  clearTimeout(o);
              }, 200);
            }
          },
          fail: function (e) {
            (0, t.mylog)("multiRace.clubfeePayJoin, err: ", e);
          },
        });
    },
    _dealPayActivity: function () {
      var a = this;
      wx.showLoading({ title: "报名中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "clubfeePayJoin",
            clubid: this.data.clubid,
            activityid: this.data.activityid,
            signType: this.data.subtype,
            costKind: this.data.costKind,
            costFee: 100 * this.data.fee,
            nickName: this.data.nickname,
            gender: this.data.gender,
            level: this.data.level,
            levelvice: this.data.levelvice,
            anonymous: this.data.anonymous,
            selectGroupNo: this.data.selectGroupNo,
            checkUnreceived: !0,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (i) {
            if (
              ((0, t.mylog)("activity.clubfeePayJoin, res: ", i),
              "fail" === i.result.type)
            )
              if (
                (a.triggerEvent("refresh", {}, {}),
                wx.hideLoading(),
                i.result.listUnrceived)
              ) {
                var c = "请先完成未付款账单，否则不能报名该";
                "alone" != a.data.activity._infos.clubid
                  ? (c += "俱乐部")
                  : (c += "组织者"),
                  (c += "的新活动哦"),
                  wx.showModal({
                    content: c,
                    showCancel: !1,
                    confirmText: "账单详情",
                    complete: function (t) {
                      if (t.confirm) {
                        var i = a.data.activity._creatorid,
                          c = a.data.activity._infos.clubid;
                        (0, e.navTo)({
                          url:
                            "/packageA/pages/mine/myBill/unReceived?creatorid=" +
                            i +
                            "&clubid=" +
                            c,
                        });
                      }
                    },
                  });
              } else
                wx.showModal({
                  content: i.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              a.closeAnimate();
              var o = setTimeout(function () {
                a.triggerEvent(
                  "clubfeePayJoined",
                  { activityPlayerid: i.result.activityPlayerid },
                  {}
                ),
                  clearTimeout(o);
              }, 200);
            }
          },
          fail: function (e) {
            (0, t.mylog)("activity.clubfeePayJoin, err: ", e);
          },
        });
    },
    _dealPayReceipt: function () {
      var e = this;
      wx.showLoading({ title: "扣费中", mask: !0 }),
        wx.cloud.callFunction({
          name: "tradeReceipt",
          data: {
            fun: "clubfeePay",
            clubid: this.data.clubid,
            receiptid: this.data.receiptid,
            costKind: this.data.costKind,
            costFee: 100 * this.data.fee,
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (i) {
            if (
              ((0, t.mylog)("receipt.clubfeePay, res: ", i),
              "fail" === i.result.type)
            )
              e.triggerEvent("refresh", {}, {}),
                wx.hideLoading(),
                wx.showModal({
                  content: i.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              e.closeAnimate();
              var a = setTimeout(function () {
                e.triggerEvent("refresh", {}, {}), clearTimeout(a);
              }, 200);
            }
          },
          fail: function (e) {
            (0, t.mylog)("receipt.clubfeePay, err: ", e);
          },
        });
    },
  },
});
