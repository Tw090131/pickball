var e = getApp(),
  t = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  i = require("../../../7C3896856B9DF5DF1A5EFE82E3B155F2.js");
Component({
  behaviors: [t, i],
  properties: {
    mode: { type: String, value: "visit" },
    page: { type: String, value: "activity" },
    crtMil: { type: Number, value: new Date().getTime() },
  },
  data: { feeMode: "month", venueCnt: 1 },
  pageLifetimes: {
    show: function () {
      var t = e.globalData.selfInfo,
        i = this.data.crtMil;
      t && t.trustLevel >= 4 && t.trustDueMil >= i && this.closeAnimate();
    },
  },
  methods: {
    setMode: function (e) {
      this.setData({ mode: e });
    },
    setRole: function (e) {
      "player" === e || "visitor" === e
        ? this.setData({ feeMode: "month" })
        : this.setData({ feeMode: "year" });
    },
    setVenueCnt: function (e) {
      this.setData({ venueCnt: e });
    },
  },
});
