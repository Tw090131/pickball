Component({
  properties: {
    item: {
      type: Object,
      value: {
        type: "",
        subtype: "",
        total: "",
        wins: "",
        loss: "",
        even: "",
        p1: { _openid: "", _avatarUrl: "", _nickName: "" },
        p2: { _openid: "", _avatarUrl: "", _nickName: "" },
        p3: { _openid: "", _avatarUrl: "", _nickName: "" },
        p4: { _openid: "", _avatarUrl: "", _nickName: "" },
        _nos: "",
        _status: "",
        _scoreAll: "",
      },
    },
    selfid: { type: String, value: "" },
    showMe: { type: Boolean, value: !0 },
    showTime: { type: Boolean, value: !1 },
    canClickHead: { type: Boolean, value: !1 },
    groups: { type: Number, value: 0 },
    showChaseRoundScore: { type: Boolean, value: !1 },
  },
  data: {},
  methods: {
    onTapRow: function () {
      this.data.item._status &&
        this.triggerEvent(
          "tosinglerace",
          {
            raceid: this.data.item._id,
            order: this.data.item._order,
            race: this.data.item,
          },
          {}
        );
    },
    onClickHead: function (e) {
      this.data.canClickHead
        ? this.triggerEvent(
            "clickhead",
            { role: e.currentTarget.dataset.role },
            {}
          )
        : this.onTapRow();
    },
  },
});
