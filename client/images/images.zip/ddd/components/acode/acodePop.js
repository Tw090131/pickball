var e = require("../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  a = getApp();
Component({
  behaviors: [e],
  properties: {
    aimid: { type: String, value: "" },
    title: { type: String, value: "请裁判扫码，加入本场比赛" },
  },
  data: { acodeUrl: "" },
  methods: {
    getAcode: function (e, t) {
      var o = this;
      this.data.acodeUrl ||
        wx.cloud.callFunction({
          name: "acode",
          data: {
            pageType: e,
            scene: t,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            if (a.result.acode) {
              var t = wx.getFileSystemManager(),
                i = wx.env.USER_DATA_PATH + "/" + e + ".jpg";
              t.writeFile({
                filePath: i,
                encoding: "binary",
                data: a.result.acode.buffer,
                success: function (e) {
                  o.setData({ acodeUrl: i });
                },
              });
            } else
              a.result.errCode &&
                wx.showModal({
                  content: "抱歉，系统繁忙，请重试",
                  showCancel: !1,
                  confirmText: "好的",
                });
          },
        });
    },
  },
});
