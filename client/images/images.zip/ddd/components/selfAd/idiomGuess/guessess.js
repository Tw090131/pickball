var s = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  e = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = getApp();
Component({
  properties: { page: { type: String, value: "" } },
  data: { guesses: "", crtIndex: 0, autoplay: !0 },
  lifetimes: {
    attached: function () {
      this._getGuessesForAd();
    },
  },
  methods: {
    _getGuessesForAd: function () {
      var i = this;
      wx.cloud.callFunction({
        name: "idiomGuess",
        data: {
          fun: "getIdiomGuessesForAd",
          isDebug: a.globalData.isDebug,
          version: a.globalData.frontVersion,
        },
        success: function (s) {
          (0, e.mylog)("getIdiomGuessesForAd, res: ", s),
            s.result.guesses &&
              (i.setData({ guesses: s.result.guesses }), i._addGuessViewAd());
        },
        fail: function (a) {
          (0, e.mylog)("getIdiomGuessesForAd, err: ", a),
            (0, s.networkFail)(!1, a, "idiom.getIdiomGuessesForAd");
        },
      });
    },
    _addGuessViewAd: function () {
      for (var s = this.data.guesses, e = [], i = 0; i < s.length; i++)
        e.push(s[i]._id);
      wx.cloud.callFunction({
        name: "idiomGuess",
        data: {
          fun: "addGuessViewAd",
          guessids: e,
          isDebug: a.globalData.isDebug,
          version: a.globalData.frontVersion,
        },
      });
    },
    onSwiperChanged: function (s) {
      (0, e.mylog)("onSwiperChanged, e: ", s),
        this.setData({ crtIndex: s.detail.current }),
        "touch" === s.detail.source && this.setData({ autoplay: !1 });
    },
    onToGuess: function () {
      var e = this.data.guesses[this.data.crtIndex];
      (a.globalData.guessInfo.crtGuess = e),
        (0, s.navTo)({
          url: "/packageE/pages/leisure/idiomGuess/idiomGuess?from=selfAdGuess",
        }),
        this._addGuessAdClick(e._id);
    },
    onGuessAnswer: function () {
      var e = this.data.guesses[this.data.crtIndex];
      (a.globalData.guessInfo.crtGuess = e),
        (0, s.navTo)({
          url: "/packageE/pages/leisure/idiomGuess/idiomGuess?from=selfAdGuess&action=lookAnswer",
        }),
        this._addGuessAdClick(e._id);
    },
    _addGuessAdClick: function (s) {
      wx.cloud.callFunction({
        name: "idiomGuess",
        data: {
          fun: "addGuessAdClick",
          guessid: s,
          isDebug: a.globalData.isDebug,
          version: a.globalData.frontVersion,
        },
      });
    },
  },
});
