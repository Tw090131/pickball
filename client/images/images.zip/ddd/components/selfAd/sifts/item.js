var t = require("../../../6360A9646B9DF5DF0506C1638BF155F2.js"),
  i = getApp();
Component({
  behaviors: [t],
  properties: {
    sift: { type: Object, value: "" },
    page: { type: String, value: "" },
  },
  data: { remainMil: null, crtTimeMil: new Date().getTime() },
  lifetimes: {
    attached: function () {
      this.setData({ crtTimeMil: new Date().getTime() }), this._countDown();
    },
  },
  methods: {
    _addClick: function (t) {
      var a = this.data.sift;
      wx.cloud.callFunction({
        name: "comm",
        data: {
          fun: "adclick",
          paras: {
            _page: this.data.page,
            _type: "sift",
            _mainid: a._id,
            _urlKind: t.kind,
            _toUrl: t.url,
            _action: t.action,
          },
          isDebug: i.globalData.isDebug,
          version: i.globalData.frontVersion,
        },
      });
    },
  },
});
