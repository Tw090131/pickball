var t = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  s = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp();
Component({
  properties: { page: { type: String, value: "" } },
  data: { sifts: [], showCnt: 1 },
  lifetimes: {
    attached: function () {
      this._getSifts();
    },
  },
  methods: {
    _getSifts: function () {
      var t = this;
      wx.cloud.callFunction({
        name: "shopSift",
        data: {
          fun: "getSifts",
          page: this.data.page,
          isDebug: i.globalData.isDebug,
          version: i.globalData.frontVersion,
        },
        success: function (i) {
          (0, s.mylog)("getSifts, res: ", i),
            i.result.sifts &&
              t.setData({ sifts: i.result.sifts, showCnt: i.result.showCnt });
        },
        fail: function (t) {
          (0, s.mylog)("getSifts, err: ", t);
        },
      });
    },
    onSiftList: function () {
      (0, t.navTo)({ url: "/packageE/pages/sifts/list/list" });
    },
    onSiftIntro: function () {
      (0, t.navTo)({ url: "/packageE/pages/sifts/intro/intro" });
    },
  },
});
