Component({
  properties: {
    diam: { type: Number, value: 100 },
    percent: { type: Number, value: 20 },
    showMid: { type: Boolean, value: !0 },
  },
  data: {},
  methods: {},
});
