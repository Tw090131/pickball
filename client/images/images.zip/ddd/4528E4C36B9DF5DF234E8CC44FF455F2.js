var s = require("88EDE3756B9DF5DFEE8B8B72923555F2.js");
module.exports = {
  getMultiConfig: function () {
    for (
      var a = [], r = [], l = [], u = [], n = 2;
      n <= o.groups.loop.max;
      n++
    ) {
      var p = (n * (n - 1)) / 2;
      a.push(n + "人，共" + p + "场"),
        r.push(2 * n + "人，共" + p + "场"),
        l.push(n + "人，每人" + (n - 1) + "场，共" + p + "场"),
        u.push(2 * n + "人，每人" + (n - 1) + "场，共" + p + "场");
    }
    (o.groups.loop.singles = a),
      (o.groups.loop.doubles = r),
      (o.groups.loop.singles_2 = l),
      (o.groups.loop.doubles_2 = u),
      (a = []),
      (r = []),
      (l = []),
      (u = []);
    for (var i = 2; i <= o.groups.doubleLoop.max; i++) {
      var m = i * (i - 1);
      a.push(i + "人，共" + m + "场"),
        r.push(2 * i + "人，共" + m + "场"),
        l.push(i + "人，每人" + 2 * (i - 1) + "场，共" + m + "场"),
        u.push(2 * i + "人，每人" + 2 * (i - 1) + "场，共" + m + "场");
    }
    (o.groups.doubleLoop.singles = a),
      (o.groups.doubleLoop.doubles = r),
      (o.groups.doubleLoop.singles_2 = l),
      (o.groups.doubleLoop.doubles_2 = u),
      (a = []),
      (r = []),
      (l = []),
      (u = []);
    for (var t = 2; t <= o.groups.arena.max; t++) {
      var g = t;
      a.push(t + "人次，共" + g + "场"),
        r.push(2 * t + "人次，共" + g + "场"),
        l.push(t + "人次，共" + g + "场"),
        u.push(2 * t + "人次，共" + g + "场");
    }
    (o.groups.arena.singles = a),
      (o.groups.arena.doubles = r),
      (o.groups.arena.singles_2 = l),
      (o.groups.arena.doubles_2 = u),
      (a = []),
      (r = []),
      (l = []),
      (u = []);
    for (var d = 2; d <= o.groups.promote.max; d++) {
      var h = d,
        f = "",
        v = "";
      if ((0, s.isPowerTwo)(h))
        (f = h + "人(标准)，共" + (h - 1) + "场"),
          (v = 2 * h + "人(标准)，共" + (h - 1) + "场");
      else {
        var b = (0, s.standardLen)(h);
        (f = h + "人，首轮" + (b - h) + "人轮空，共" + (h - 1) + "场"),
          (v =
            2 * h + "人，首轮" + 2 * (b - h) + "人轮空，共" + (h - 1) + "场");
      }
      a.push(f), r.push(v), l.push(f), u.push(v);
    }
    (o.groups.promote.top2.singles = a),
      (o.groups.promote.top2.doubles = r),
      (o.groups.promote.top2.singles_2 = l),
      (o.groups.promote.top2.doubles_2 = u),
      (a = []),
      (r = []),
      (l = []),
      (u = []);
    for (var x = 2; x <= o.groups.promote.max; x++) {
      var c = x,
        _ = "",
        M = "";
      if (2 === c) (_ = "2人(标准)，共1场"), (M = "4人(标准)，共1场");
      else if (3 === c)
        (_ = "3人，首轮1人轮空，共2场"), (M = "6人，首轮2人轮空，共2场");
      else if ((0, s.isPowerTwo)(c))
        (_ = c + "人(标准)，共" + (c - 1 + 1) + "场"),
          (M = 2 * c + "人(标准)，共" + (c - 1 + 1) + "场");
      else {
        var R = (0, s.standardLen)(c);
        (_ = c + "人，首轮" + (R - c) + "人轮空，共" + (c - 1 + 1) + "场"),
          (M =
            2 * c +
            "人，首轮" +
            2 * (R - c) +
            "人轮空，共" +
            (c - 1 + 1) +
            "场");
      }
      a.push(_), r.push(M), l.push(_), u.push(M);
    }
    (o.groups.promote.top4.singles = a),
      (o.groups.promote.top4.doubles = r),
      (o.groups.promote.top4.singles_2 = l),
      (o.groups.promote.top4.doubles_2 = u);
    var w = [];
    w = [
      "每队2人，开启可选1/2/3场",
      "每队3人，开启可选3/6/9场",
      "每队4人，开启可选6~18场",
      "每队5人，开启可选10~20场",
      "每队6人，开启可选12~30场",
      "每队7人，开启可选14/21场",
      "每队8人，开启可选16~28场",
      "每队9人，开启可选18~36场",
      "每队10人，开启可选20~45场",
      "每队11人，开启可选22~55场",
    ];
    for (var D = 12; D <= o.groups.teamRound.max; D++)
      w.push("每队" + D + "人，每人8场共" + (8 * D) / 2 + "场");
    (o.groups.teamRound.list = w), (w = []);
    for (var y = 2; y <= o.groups.wheelMatch.max; y++)
      w.push("每队" + y + "人，每人2局共" + y + "局");
    (o.groups.wheelMatch.list = w), (w = []);
    for (var L = 2; L <= o.groups.freeMatch.max; L++) w.push("每队" + L + "人");
    (o.groups.freeMatch.list = w), (w = []);
    for (var S = 2; S <= o.groups.relayMatch.max; S++)
      w.push("每队" + S + "人");
    (o.groups.relayMatch.list = w), (w = []);
    for (var A = 1; A <= o.groups.fixedMatch.max; A++)
      w.push("每队" + 2 * A + "人，每人" + A + "场共" + A * A + "场");
    (o.groups.fixedMatch.list = w), (w = []);
    for (var P = 1; P <= o.groups.singlesMatch.max; P++)
      w.push("每队" + P + "人，每人" + P + "场共" + P * P + "场");
    (o.groups.singlesMatch.list = w),
      (w = [
        "4人，开启可选1/2/3场",
        "6人，开启可选3/6/9场",
        "8人，开启可选6-18场",
        "10人，开启可选10-25场",
        "12人，开启可选12-30场",
        "14人，开启可选14-42场",
        "16人，开启可选16-48场",
        "18人，开启可选18-54场",
        "20人，开启可选20-60场",
        "22人，开启可选22-55场",
        "24人，开启可选24-66场",
      ]);
    for (var T = 13; T <= o.groups.fixedRound.max; T++)
      w.push(2 * T + "人，每人8场共" + (8 * T) / 2 + "场");
    (o.groups.fixedRound.list = w),
      (w = [
        "2人，开启可选1/2/3场",
        "3人，开启可选3/6/9场",
        "4人，开启可选6-18场",
        "5人，开启可选10-25场",
        "6人，开启可选12-30场",
        "7人，开启可选14-42场",
        "8人，开启可选16-48场",
        "9人，开启可选18-54场",
        "10人，开启可选20-60场",
        "11人，开启可选22-55场",
        "12人，开启可选24-66场",
      ]);
    for (var k = 13; k <= o.groups.singlesRound.max; k++)
      w.push(k + "人，每人8场共" + (8 * k) / 2 + "场");
    (o.groups.singlesRound.list = w), (w = []);
    for (var F = o.groups.freeRound.min; F <= o.groups.freeRound.max; F++)
      w.push(F + "人");
    (o.groups.freeRound.list = w),
      (w = [
        "2男2女，开启可选2/4/6/8场",
        "3男3女，开启可选6/9/18场",
        "4男4女，开启可选8/16/24场",
        "5男5女，开启时可选10-30场",
        "6男6女，开启时可选12-36场",
        "7男7女，开启时可选14-42场",
        "8男8女，开启时可选16-48场",
        "9男9女，开启时可选18-54场",
        "10男10女，开启可选20-60场",
      ]);
    for (var C = 11; C <= o.groups.mixRound.max; C++)
      w.push(C + "男" + C + "女，每人8场，共" + (8 * C) / 2 + "场");
    (o.groups.mixRound.list = w),
      (w = [
        "4人，开启可选2/4/6/8场",
        "6人，开启时可选6/9/18场",
        "8人，开启可选8/16/24场",
        "10人，开启时可选10-30场",
        "12人，开启时可选12-36场",
        "14人，开启时可选14-42场",
        "16人，开启时可选16-48场",
        "18人，开启时可选18-54场",
        "20人，开启时可选20-60场",
      ]);
    for (var j = 11; j <= o.groups.weakStrong.max; j++)
      w.push(2 * j + "人，每人8场，共" + (8 * j) / 2 + "场");
    o.groups.weakStrong.list = w;
    for (
      var q = [
          "4人，开启时可选3/6/9场",
          "5人，开启时可选5/10/15场",
          "6人，开启可选6/9/12/15场",
          "7人，开启时可选7/14/21场",
          "8人，每人7场，共14场",
          "9人，每人4/8场，共9/18场",
          "10人，开启时可选5~30场",
          "11人，开启可选11/22/33场",
          "12人，开启时可选6~36场",
          "13人，开启可选13/26/39场",
          "14人，开启时可选7~42场",
          "15人，开启可选15/30/45场",
          "16人，开启时可选8~60场",
          "17人，开启时可选17~68场",
          "18人，开启时可选9~54场",
          "19人，开启时可选19/38场",
          "20人，开启时可选10~95场",
        ],
        N = 21;
      N <= o.groups.eight.max;
      N++
    )
      q.push(N + "人，每人8场，共" + 2 * N + "场");
    o.groups.eight.list = q;
    for (var W = ["提前1小时"], z = 2; z <= 96; z++) W.push(z + "小时");
    if (((o.retreats = W), e.globalData.transfer.clubs))
      var B = e.globalData.transfer.clubs;
    else {
      B = wx.getStorageSync(e.globalData.storageName.myManageClubs);
      e.globalData.transfer.clubs = B;
    }
    if (B) {
      for (var E = 0; E < B.names.length; E++)
        o.clubs.names.push(B.names[E]), o.clubs.values.push(B.values[E]);
      if (B.roles)
        for (var G = 0; G < B.names.length; G++) o.clubs.roles.push(B.roles[G]);
      if (B.vipPrices)
        for (var H = 0; H < B.vipPrices.length; H++)
          o.clubs.vipPrices.push(B.vipPrices[H]);
    }
    return o;
  },
  getWheelMatchPairModes: function () {
    return { values: [1, 2, 3], modes: ["once", "twice", "plus"] };
  },
};
var e = getApp(),
  o = {
    modes: {
      values: [
        "eight",
        "mixRound",
        "loop",
        "doubleLoop",
        "weakStrong",
        "arena",
        "teamRound",
        "fixedRound",
        "singlesRound",
        "freeRound",
        "wheelMatch",
        "freeMatch",
        "relayMatch",
        "fixedMatch",
        "singlesMatch",
        "promote",
      ],
      names: [
        "八人转/超八转",
        "混双转",
        "单循环积分赛",
        "双循环积分赛",
        "前后转",
        "擂台赛",
        "小队转",
        "固搭转",
        "单打转",
        "自由转",
        "轮比转",
        "自由对抗赛",
        "接力赛",
        "固搭对抗赛",
        "单打对抗赛",
        "晋级赛",
      ],
      names_2: [
        "八人转/超八转",
        "混双转",
        "单循环",
        "双循环",
        "前后转",
        "擂台赛",
        "小队转",
        "固搭转",
        "单打转",
        "自由转",
        "轮比转",
        "自由决",
        "接力赛",
        "固搭决",
        "单打决",
        "晋级赛",
      ],
    },
    types: {
      values: [
        "manSingles",
        "womanSingles",
        "nolimitSingles",
        "manDoubles",
        "womanDoubles",
        "mixedDoubles",
        "nolimitDoubles",
      ],
      names: [
        "男单",
        "女单",
        "不限性别单打",
        "男双",
        "女双",
        "混双",
        "不限组合双打",
      ],
      names_2: ["男单", "女单", "单打", "男双", "女双", "混双", "双打"],
    },
    eightTypes: {
      values: ["manDoubles", "womanDoubles", "nolimitDoubles"],
      names: ["男", "女", "不限"],
      names_2: ["男专场", "女专场", "不限性别"],
    },
    doublesTypes: {
      values: ["manDoubles", "womanDoubles", "mixedDoubles", "nolimitDoubles"],
      names: ["男双", "女双", "混双", "不限组合双打"],
      names_2: ["男双", "女双", "混双", "不限双"],
    },
    singlesTypes: {
      values: ["manSingles", "womanSingles", "nolimitSingles"],
      names: ["男单", "女单", "不限性别"],
      names_2: ["男单", "女单", "不限单"],
    },
    groups: {
      loop: {
        min: 2,
        max: 20,
        singles: "",
        doubles: "",
        singles_2: "",
        doubles_2: "",
      },
      doubleLoop: {
        min: 2,
        max: 10,
        singles: "",
        doubles: "",
        singles_2: "",
        doubles_2: "",
      },
      arena: {
        min: 2,
        max: 30,
        list: "",
        singles: "",
        doubles: "",
        singles_2: "",
        doubles_2: "",
      },
      eight: { min: 4, max: 50, list: "" },
      mixRound: { min: 2, max: 18, list: [] },
      weakStrong: { min: 2, max: 18, list: [] },
      teamRound: { min: 2, max: 20, list: [] },
      fixedRound: { min: 2, max: 25, list: [] },
      singlesRound: { min: 2, max: 25, list: [] },
      freeRound: { min: 2, max: 60 },
      wheelMatch: { min: 2, max: 16, list: [] },
      promote: {
        min: 2,
        max: 64,
        list: [],
        top2: { singles: "", doubles: "", singles_2: "", doubles_2: "" },
        top4: { singles: "", doubles: "", singles_2: "", doubles_2: "" },
      },
      freeMatch: { min: 2, max: 18, list: [] },
      relayMatch: { min: 2, max: 18, list: [] },
      fixedMatch: { min: 1, max: 10, list: [] },
      singlesMatch: { min: 1, max: 10, list: [] },
    },
    rounds: {
      values: [1, 3, 5],
      names: ["一局定胜负", "三局两胜", "五局三胜"],
      names_2: ["每场一局定胜负", "每场三局两胜", "每场五局三胜"],
    },
    balls: {
      values: [7, 10, 11, 15, 16, 18, 20, 21, 25, 30, 31, 35, 41, 42],
      names: [
        "每局7分",
        "每局10分",
        "每局11分",
        "每局15分",
        "每局16分",
        "每局18分",
        "每局20分",
        "每局21分",
        "每局25分",
        "每局30分",
        "每局31分",
        "每局35分",
        "每局41分",
        "每局42分",
      ],
      names_2: [
        "每局7分",
        "每局10分",
        "每局11分",
        "每局15分",
        "每局16分",
        "每局18分",
        "每局20分",
        "每局21分",
        "每局25分",
        "每局30分，15分换边",
        "每局31分，16分换边",
        "每局35分，18分换边",
        "每局41分，20分换边",
        "每局42分，21分换边",
      ],
    },
    wheelModes: {
      values: ["chase", "isolate"],
      names: ["连续追分", "每局从零开始"],
      names_2: ["接力追分", "每场独立记分"],
    },
    feeModes: {
      names: [
        "多退少补",
        "报名时收取",
        "赛前收款",
        "赛后按人收取",
        "赛后AA收款",
        "会费已包含",
        "活动费已包含",
        "免费参与",
        "自行付费",
      ],
      names_2: [
        "多退少补",
        "报名时收取",
        "赛前收款",
        "赛后收取",
        "赛后AA收款",
        "会费已包含",
        "活动费已包含",
        "免费参与",
        "自行付费",
      ],
      values: [
        "moreless",
        "charge",
        "before",
        "offline",
        "AAafter",
        "inMemFee",
        "inActFee",
        "free",
        "byself",
      ],
    },
    retreats: ["提前1小时"],
    rangeTypes: { names: ["不限，开放报名"], values: ["open"] },
    clubs: {
      names: ["无所属俱乐部"],
      values: ["alone"],
      roles: ["none"],
      vipPrices: ["closed"],
    },
    partnerModes: {
      names: ["固定搭档", "抽签搭档", "势均力敌"],
      names_2: ["报名时固定搭档", "开启前抽签配对(随机)", "抽签时势均力敌"],
      names_3: ["报名时固搭", "随机抽签配对", "势均力敌抽签"],
      values: ["fixed", "random", "bylevel"],
    },
    minLevels: [
      "最低萌新",
      "1级",
      "2级",
      "3级",
      "4级",
      "5级",
      "6级",
      "7级",
      "8级",
      "9级",
      "专业级",
    ],
    maxLevels: [
      "萌新",
      "1级",
      "2级",
      "3级",
      "4级",
      "5级",
      "6级",
      "7级",
      "8级",
      "9级",
      "最高专业级",
    ],
    comLevels: [
      "萌新",
      "1级",
      "2级",
      "3级",
      "4级",
      "5级",
      "6级",
      "7级",
      "8级",
      "9级",
      "专业级",
    ],
    promoteFinals: {
      values: ["top2", "top4"],
      names: ["仅冠亚军", "分冠亚季军"],
    },
  };
