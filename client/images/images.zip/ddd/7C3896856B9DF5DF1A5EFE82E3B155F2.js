var e = require("@babel/runtime/helpers/objectSpread2.js"),
  t = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  n = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = getApp();
module.exports = Behavior({
  data: { feeMode: "year", isAgree: !0 },
  methods: {
    onFeeCurrent: function () {
      this.setData({ feeMode: "current" });
    },
    onFeeMonth: function () {
      this.setData({ feeMode: "month" });
    },
    onFeeYear: function () {
      this.setData({ feeMode: "year" });
    },
    onAgree: function () {
      this.data.isAgree
        ? this.setData({ isAgree: !1 })
        : this.setData({ isAgree: !0 });
    },
    onAgreement: function () {
      (0, t.navTo)({ url: "/packageA/pages/mine/agreement/vipfun" });
    },
    onPayConfirm: function () {
      this._checkOK() && this._dealPayVipfun();
    },
    _checkOK: function () {
      if (!this.data.isAgree)
        return wx.showToast({ title: "请同意付费特权协议", icon: "none" }), !1;
      if (!a.globalData.selfInfo) {
        wx.showToast({
          title: "请先微信登录",
          icon: "none",
          duration: 1e3,
          mask: !0,
        });
        var e = setTimeout(function () {
          (0, t.navTo)({ url: "/pages/login/login" }), clearTimeout(e);
        }, 1e3);
        return !1;
      }
      return !0;
    },
    _dealPayVipfun: function () {
      var e = this;
      wx.showLoading({ title: "支付中", mask: !0 }),
        wx.cloud.callFunction({
          name: "tradeVipfun",
          data: {
            fun: "payVipfun",
            feeMode: this.data.feeMode,
            payAt: a.globalData.payVipfunInfo.payAt,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (t) {
            if (
              ((0, n.mylog)("tradeVipfun.payVipfun, res: ", t),
              "fail" === t.result.type)
            )
              e.triggerEvent("refresh", {}, {}),
                wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              var a = t.result.payment.payment;
              (0, n.mylog)("payment res: ", a),
                e._wxPay(a, t.result.detail._id);
            }
          },
          fail: function (e) {
            wx.hideLoading(), (0, n.mylog)("_dealPayVipfun, err", e);
          },
        });
    },
    _wxPay: function (t, a) {
      var i = this;
      wx.requestPayment(
        e(
          e({}, t),
          {},
          {
            success: function (e) {
              (0, n.mylog)("_wxPay success", e),
                wx.showToast({ title: "付费成功", duration: 1500 }),
                i._getUserInfo(),
                i.triggerEvent("paySuccess", { vipfunDetailid: a }, {}),
                i.closeAnimate();
            },
            fail: function (e) {
              (0, n.mylog)("_wxPay fail", e),
                wx.hideLoading(),
                i._dealCancelPay(a);
              i._getUserInfo(!0);
            },
          }
        )
      );
    },
    _dealCancelPay: function (e) {
      wx.cloud.callFunction({
        name: "tradeVipfun",
        data: {
          fun: "cancelPay",
          vipfunDetailid: e,
          isDebug: a.globalData.isDebug,
          version: a.globalData.frontVersion,
        },
        success: function (e) {
          (0, n.mylog)("_dealCancelPay, res:", e);
        },
        fail: function (e) {
          (0, n.mylog)("_dealCancelPay, err: ", e);
        },
      });
    },
    _getUserInfo: function (e) {
      var t = this;
      wx.cloud.callFunction({
        name: "user",
        data: {
          fun: "selfInfo",
          isDebug: a.globalData.isDebug,
          version: a.globalData.frontVersion,
        },
        success: function (i) {
          if (((0, n.mylog)("selfInfo: ", i), i.result.userinfo)) {
            a.globalData.selfInfo = i.result.userinfo;
            var o = i.result;
            if (e) {
              if (
                o.userinfo.trustLevel >= 4 &&
                o.userinfo.trustDueMil > o.crtMil
              ) {
                wx.showToast({
                  title: "您已付费",
                  icon: "none",
                  duration: 1200,
                });
                var s = setTimeout(function () {
                  t.closeAnimate(), clearTimeout(s);
                }, 1300);
              }
            } else
              (o.userinfo.trustLevel < 4 ||
                (o.userinfo.trustLevel >= 4 &&
                  o.userinfo.trustDueMil <= o.crtMil)) &&
                wx.showModal({
                  content:
                    "网络有延迟，未获得最新付费状态，请点击右上角【···】，然后【重新进入小程序】",
                  showCancel: !1,
                  confirmText: "好的",
                });
          }
        },
        fail: function (e) {
          (0, n.mylog)("selfInfo err: ", e);
        },
      });
    },
    onMore: function () {
      (0, t.navTo)({
        url: "/packageA/pages/vipfun/vipfun?from=" + this.data.page,
      });
    },
  },
});
