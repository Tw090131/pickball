getApp();
Component({
  data: {
    selected: 0,
    color: "#999",
    selectedColor: "#FFA000",
    tabs: [
      {
        type: "page",
        pagePath: "/pages/index/index",
        text: "首页",
        iconPath: "/images/nav/index-02.png",
        selectedIconPath: "/images/nav/index-01.png",
        event: "onSwitchTab",
      },
      { type: "btn", event: "onCreate", text: "发起" },
      {
        type: "page",
        pagePath: "/pages/mine/mine",
        text: "我的",
        iconPath: "/images/nav/mine-02.png",
        selectedIconPath: "/images/nav/mine-01.png",
        event: "onSwitchTab",
      },
    ],
    isShowBar: !0,
  },
  methods: {
    onSwitchTab: function (e) {
      var t = e.currentTarget.dataset,
        a = t.path;
      wx.switchTab({ url: a }), this.setData({ selected: t.index });
    },
    hidebar: function () {
      this.setData({ isShowBar: !1 });
    },
    showbar: function () {
      this.setData({ isShowBar: !0 });
    },
    onCreate: function () {
      this.selectComponent("#selecter").showPop();
    },
  },
});
