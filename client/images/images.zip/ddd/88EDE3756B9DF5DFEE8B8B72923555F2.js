var e = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  r = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  n = getApp();
function t(e) {
  return e < 10 ? "0" + e : "" + e;
}
function a(e, n) {
  for (var t = "", a = 0; a < n.length; a++) {
    var o = a + 1 + "、",
      s = n[a];
    e.isRealname && s._realName.length > 0
      ? (o += s._realName[0])
      : e.copyMode &&
        e.copyMode.showAnonymous &&
        s._anonymous &&
        s._anonymous.isAnonymous &&
        s._anonymous.nickName
      ? (o += s._anonymous.nickName)
      : (o += s._nickName[0]),
      "other" === s._signType &&
        ((o += "+" + s._num),
        s._otherInfos &&
          s._otherInfos.nickName &&
          (o += "，" + s._otherInfos.nickName)),
      2 === s.gender && (o += "[玫瑰]"),
      s._postscript && (o += "（" + s._postscript + "）"),
      e.copyMode &&
        e.copyMode.needLevel &&
        ((s._signType && s._activityid && "self" === s._signType) ||
        (!s._signType && s._raceid)
          ? (s._anonymous &&
              s._anonymous.isAnonymous &&
              s._anonymous.secretLevel) ||
            (s._memInfo &&
            s._memInfo.level &&
            s._memInfo.level.length > 0 &&
            s._memInfo.level[0] >= 0
              ? ((o += "，"),
                (o += (0, r.showLevel)(
                  s._memInfo.level[0],
                  s._memInfo.levelvice[0]
                )))
              : s._infos &&
                s._infos.length > 0 &&
                s._infos[0].level >= 0 &&
                ((o += "，"),
                (o += (0, r.showLevel)(
                  s._infos[0].level,
                  s._infos[0].levelvice
                ))))
          : s._signType &&
            s._activityid &&
            "other" === s._signType &&
            s._otherInfos &&
            (0 === s._otherInfos.level || s._otherInfos.level > 0) &&
            ((o += "，"),
            (o += (0, r.showLevel)(
              s._otherInfos.level,
              s._otherInfos.levelvice
            )))),
      (t += o += "\n");
  }
  return t;
}
function o(e, r) {
  for (var n = 0; n < e.length; n++) if (e[n]._no === r) return e[n];
  return null;
}
function s(e) {
  switch (e) {
    case 1:
      return "A";
    case 2:
      return "B";
    case 3:
      return "C";
    case 4:
      return "D";
    case 5:
      return "E";
    case 6:
      return "F";
    case 7:
      return "G";
    case 8:
      return "H";
    case 9:
      return "I";
    case 10:
      return "J";
    case 11:
      return "K";
    case 12:
      return "L";
    case 13:
      return "M";
    case 14:
      return "N";
    case 15:
      return "O";
    case 16:
      return "P";
    case 17:
      return "Q";
    case 18:
      return "R";
    case 19:
      return "S";
    case 20:
      return "T";
    case 21:
      return "U";
    case 22:
      return "V";
    case 23:
      return "W";
    case 24:
      return "X";
    case 25:
      return "Y";
    case 26:
      return "Z";
  }
  return "未知";
}
module.exports = {
  copyNameList: function (n) {
    var o = n.infos,
      u = n.signs,
      i = n.alternates,
      l = n.url,
      c = n.typeName,
      f = n.groups,
      m = "";
    o.title && (m += o.title + "\n");
    if (o.date) {
      var h = "日期：";
      (h += o.date.year + "."),
        (h += t(o.date.month) + "." + t(o.date.day)),
        (h += "（" + (0, r.getWeek)(o.date.weekDay) + "）"),
        (m += h + "\n");
    }
    if (o.time) {
      var g = "时间：";
      (g += t(o.time.hour) + ":" + t(o.time.minute) + " - "),
        (g += t(o.time.endhour) + ":" + t(o.time.endminute)),
        (m += g + "\n");
    }
    o.location && (m += "地点：" + o.location.name + "\n");
    o.venue && (m += "场地号：" + o.venue + "\n");
    o.copyMode && "group" === o.copyMode.listType && f && f.length > 0
      ? (m += (function (e, r) {
          for (var n = "", t = e.groups, o = 0; o < r.length; o++) {
            var u = r[o];
            u.players &&
              u.players.length > 0 &&
              (o < r.length - 1
                ? o < t.length
                  ? ((n += s(o + 1) + "组"),
                    t[o].name && (n += "（" + t[o].name + "）"))
                  : (n += "未知组")
                : (n += "待分组"),
              (n += "\n"),
              (n += a(e, u.players)),
              o < r.length - 1 && (n += "\n"));
          }
          return n;
        })(o, f))
      : ((m += "已报名：\n"), (m += a(o, u)));
    i.length > 0 &&
      o.copyMode.needAlternates &&
      ((m += "\n"), (m += "候补：\n"), (m += a(o, i)));
    o.remarks &&
      o.copyMode.needRemarks &&
      ((m += "\n"), (m += "温馨提示：\n"), (m += o.remarks + "\n"));
    l && ((m += "\n"), (m += "羽毛球助手小程序" + c + "详情：\n"), (m += l));
    return (0, e.mylog)("nameList: ", m), m;
  },
  dealNameList: a,
  chooseListNames: function (e, r) {
    for (var n = "", t = "", a = "", o = 0; o < r.length; o++) {
      var s = "",
        u = r[o];
      "self" === u._signType
        ? (e.isRealname && u._realName.length > 0
            ? (s += u._realName[0])
            : (s += u._nickName[0]),
          (t += s += "\n"))
        : (e.isRealname && u._realName.length > 0
            ? (s += u._realName[0])
            : (s += u._nickName[0]),
          (s += "+" + u._num),
          u._otherInfos &&
            u._otherInfos.nickName &&
            ((s += "，"), (s += u._otherInfos.nickName)),
          (a += s += "\n"));
    }
    t && ((n += "已自动报名：\n"), (n += t));
    a &&
      ((n += "\n"),
      (n += "比赛需要独立主体记录比分，带人请单独报名：\n"),
      (n += a));
    return n;
  },
  compareVersion: function (e, r) {
    (e = e.split(".")), (r = r.split("."));
    var n = Math.max(e.length, r.length);
    for (; e.length < n; ) e.push("0");
    for (; r.length < n; ) r.push("0");
    for (var t = 0; t < n; t++) {
      var a = parseInt(e[t]),
        o = parseInt(r[t]);
      if (a > o) return 1;
      if (a < o) return -1;
    }
    return 0;
  },
  makeAvatarPath: function (e) {
    var r = new Date(),
      n = [];
    n = -1 != e.indexOf("_") ? e.split("_") : e.split("/");
    var t = "";
    n.length > 1
      ? (t = n[n.length - 1])
      : ((n = e.split(".")), (t = r.getTime() + "." + n[n.length - 1]));
    return (
      "userheads/" +
      r.getFullYear() +
      "/" +
      (r.getMonth() + 1) +
      "/" +
      r.getDate() +
      "/" +
      t
    );
  },
  toCreateClub: function () {
    var e = "/packageD/pages/club/club?from=creater";
    n.globalData.selfInfo
      ? (0, r.navTo)({ url: e })
      : ((n.globalData.loginTargetUrl = e),
        (0, r.navTo)({ url: "/pages/login/login?action=target" }));
  },
  matchPlayer: o,
  checkNickName: function (e) {
    for (
      var r = [
          "匿名",
          "神秘",
          "男高",
          "女高",
          "蒙面",
          "注销",
          "用户",
          "删除",
          "移除",
          "账号",
          "账户",
          "登录",
          "null",
          "Null",
          "NULL",
          "待定",
          "待加入",
          "轮空",
        ],
        n = 0;
      n < r.length;
      n++
    )
      if (-1 != e.indexOf(r[n]))
        return (
          wx.showModal({
            content: r[n] + "是系统专有词汇，昵称请不要包含" + r[n] + "哦",
            showCancel: !1,
            confirmText: "好的",
          }),
          !1
        );
    return !0;
  },
  canManage: function (e, r) {
    if (!e) return !1;
    if (!r) return !1;
    if (e === r._creatorid) return !0;
    if (!r.me) return !1;
    if (!r.me.role) return !1;
    if (r.me.role.length <= 0) return !1;
    if ("president" === r.me.role[0] || "manager" === r.me.role[0]) return !0;
    return !1;
  },
  raceRole: function (e, r) {
    if (!e) return null;
    if (!r) return null;
    if (e === r._creatorid) return "creator";
    if (r.me && r.me.role && r.me.role.length > 0) {
      if ("president" === r.me.role[0]) return "president";
      if ("manager" === r.me.role[0]) return "manager";
    }
    if (r.isMultyPlayer || r.isPlayer) return "player";
    if (r._referees && r._referees.length > 0)
      for (var n = 0; n < r._referees.length; n++)
        if (e === r._referees[n]) return "referee";
    return "visitor";
  },
  pairToIntTeamRound: function (e, r) {
    switch (e) {
      case "one":
        return 1;
      case "two":
        return 2;
      case "three":
        return 3;
      case "half":
        return 4;
      case "five":
        return 5;
      case "six":
        return 6;
      case "seven":
        return 7;
      case "super":
        return 8;
      case "nine":
        return 9;
      case "ten":
        return 10;
      case "twelve":
        return 12;
      case "once":
        return r - 1;
      case "twice":
        return 2 * (r - 1);
      case "plus":
        return 3 * (r - 1);
      default:
        return 8;
    }
  },
  lookWho: function (e, r) {
    if (!e) return "error";
    if (r) return e === r ? "meout-self" : "other";
    return "self";
  },
  numToAZ: s,
  getRaceFigures: function (e) {
    if (!e) return 0;
    var r = e._infos.mode,
      n = e._infos.type,
      t = e._infos.groups,
      a = 0;
    switch (r) {
      case "loop":
      case "doubleLoop":
      case "promote":
        a = -1 != n.indexOf("Singles") ? t : 2 * t;
        break;
      case "arena":
        (t += e._infos.groupsArena),
          (a = -1 != n.indexOf("Singles") ? t : 2 * t);
        break;
      case "eight":
      case "singlesRound":
      case "freeRound":
        a = t;
        break;
      case "mixRound":
      case "weakStrong":
      case "fixedRound":
        a = 2 * t;
        break;
      case "teamRound":
      case "wheelMatch":
      case "freeMatch":
      case "relayMatch":
      case "singlesMatch":
        a = 2 * t;
        break;
      case "fixedMatch":
        a = 4 * t;
    }
    return a;
  },
  dealDoubles: function (e) {
    if (!e) return [];
    if (e.length <= 0) return [];
    var r = [],
      n = e[e.length - 1]._no;
    n % 2 == 1 && n++;
    for (var t = n / 2, a = 0; a < t; a++) {
      var s = o(e, 2 * a + 1),
        u = o(e, 2 * a + 2);
      s && u && r.push([s, u]);
    }
    return r;
  },
  standardLen: function (e) {
    if (e <= 2) return 2;
    if (e <= 4) return 4;
    if (e <= 8) return 8;
    if (e <= 16) return 16;
    if (e <= 32) return 32;
    if (e <= 64) return 64;
    if (e <= 128) return 128;
    if (e <= 256) return 256;
    if (e <= 512) return 512;
    if (e <= 1024) return 1024;
    if (e <= 2048) return 2048;
  },
  isPowerTwo: function (e) {
    return e > 0 && 0 == (e & (e - 1));
  },
};
