App({
  globalData: {
    frontVersion: "3.33.2",
    selfInfo: null,
    selfid: "",
    meout: "",
    clubInfo: {
      crtClub: null,
      crtMeout: null,
      clubName: "",
      clubNameSimple: "",
    },
    multiRaceInfo: {
      raceInfo: null,
      crtPlayers: null,
      crtRaces: null,
      isMultiPlayer: !1,
      refereeInfo: null,
      copyRace: null,
      crtScore: null,
      backFromAdd: !1,
      isFromPlayers: !1,
    },
    singleRaceInfo: { raceInfo: null, players: null, role: null },
    activityInfo: {
      crtActivity: null,
      crtPlayers: null,
      copyActivity: null,
      isFromPlayers: !1,
      groupChanged: !1,
      groupManaged: !1,
      limitChanged: !1,
      autoGrouped: !1,
      showGroupControl: !1,
    },
    receiptInfo: { crtReceipt: null },
    creditInfo: { crtCredit: null },
    storageName: { myManageClubs: "local_storage_myManageClubs" },
    transfer: { clubs: null },
    options: { type: "", inviterid: "", channel: null },
    prePage: { name: "", url: "" },
    loginTargetUrl: "",
    isLoginedReturn: !1,
    siftInfo: { crtSift: null },
    guessInfo: { crtGuess: null },
    upGradeInfo: { upPrices: null, packPrice: null, inviter: null },
    payVipfunInfo: { payAt: null },
    insureInfo: { content: null, from: null },
  },
  onLaunch: function (l) {
    wx.cloud
      ? this.globalData.isDebug
        ? wx.cloud.init({ traceUser: !0, env: "debug-0g0fddqe75f976e1" })
        : wx.cloud.init({ traceUser: !0, env: "release-4gu559kx64ec58e8" })
      : console.error("请使用 2.2.3 或以上的基础库以使用云能力");
    var e = wx.getUpdateManager(),
      n = this;
    e.onCheckForUpdate(function (l) {
      n.globalData.isDebug &&
        l.hasUpdate &&
        wx.showToast({ title: "新版本： " + (l.hasUpdate ? "有" : "无") });
    }),
      e.onUpdateReady(function () {
        wx.showModal({
          showCancel: !1,
          title: "更新提示",
          content: "有新版本更新，请重启小程序",
          success: function (l) {
            l.confirm && e.applyUpdate();
          },
        });
      }),
      e.onUpdateFailed(function () {}),
      this.globalData.selfInfo && this.globalData.selfid
        ? this._judgeAccount()
        : this._getSelfInfo(),
      this.globalData.isDebug &&
        (console.log("frontVersion: ", this.globalData.frontVersion),
        console.log("onLoad options: ", l));
  },
  _getSelfInfo: function () {
    var l = this,
      e = {
        fun: "selfInfo",
        isDebug: this.globalData.isDebug,
        version: this.globalData.frontVersion,
      };
    this.globalData.userOpenId &&
      (e.userInfo = { openId: this.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "user",
        data: e,
        success: function (e) {
          l.globalData.isConsoleLog && console.log("global selfInfo res: ", e),
            (l.globalData.selfInfo = e.result.userinfo),
            (l.globalData.selfid = e.result.selfid),
            l._judgeAccount();
        },
        fail: function (e) {
          l.globalData.isConsoleLog && console.log("global selfInfo err: ", e);
        },
      });
  },
  _judgeAccount: function () {
    var l = this.globalData.selfInfo;
    l &&
      (-100 === l.trustLevel
        ? wx.showModal({
            content: "抱歉，您因为违反相关规定，账号已被封禁",
            showCancel: !1,
            confirmText: "关闭",
            complete: function (l) {
              l.cancel, l.confirm && wx.exitMiniProgram();
            },
          })
        : -1e3 === l.trustLevel &&
          wx.showModal({
            content: "您已注销账号，本微信号无法再次登录哦",
            showCancel: !1,
            confirmText: "关闭",
            complete: function (l) {
              l.cancel, l.confirm && wx.exitMiniProgram();
            },
          }));
  },
  onShow: function (l) {
    this._judgeAccount();
  },
});
