module.exports = Behavior({
  data: { loginBtnColor: "#ffB600" },
  methods: {
    onManualStart: function () {
      this.setData({ loginBtnColor: "#ffC900" });
    },
    onManualEnd: function () {
      this.setData({ loginBtnColor: "#ffB600" });
    },
  },
});
