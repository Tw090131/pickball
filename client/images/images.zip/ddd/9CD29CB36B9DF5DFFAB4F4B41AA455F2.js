module.exports = {
  getConfig: function () {
    if (e.globalData.transfer.clubs) var a = e.globalData.transfer.clubs;
    else {
      a = wx.getStorageSync(e.globalData.storageName.myManageClubs);
      e.globalData.transfer.clubs = a;
    }
    if (a) {
      for (var r = 0; r < a.names.length; r++)
        s.clubs.names.push(a.names[r]), s.clubs.values.push(a.values[r]);
      if (a.roles)
        for (var l = 0; l < a.roles.length; l++) s.clubs.roles.push(a.roles[l]);
      if (a.vipPrices)
        for (var n = 0; n < a.vipPrices.length; n++)
          s.clubs.vipPrices.push(a.vipPrices[n]);
    }
    for (var t = [], o = 2; o <= 500; o++) t.push(o + "人");
    s.figures = t;
    for (var u = ["开始前，都可退坑"], i = 1; i <= 96; i++) u.push(i + "小时");
    return (s.retreats = u), s;
  },
};
var e = getApp(),
  s = {
    feeModes: {
      names: [
        "多退少补",
        "报名时收取",
        "活动前收款",
        "活动后按人收取",
        "活动后AA收款",
        "会费已包含",
        "免费参与",
        "自行付费",
      ],
      names_2: [
        "多退少补",
        "报名时收取",
        "活动前收款",
        "活动后收取",
        "活动后AA收款",
        "会费已包含",
        "免费参与",
        "自行付费",
      ],
      values: [
        "moreless",
        "charge",
        "before",
        "offline",
        "AAafter",
        "inMemFee",
        "free",
        "byself",
      ],
    },
    retreats: ["开始前，都可退坑"],
    rangeTypes: { names: ["不限，开放报名"], values: ["open"] },
    clubs: {
      names: ["无所属俱乐部"],
      values: ["alone"],
      roles: ["none"],
      vipPrices: ["closed"],
    },
    figures: ["2人"],
    signOthers: {
      names: ["可带人报名", "仅本人报名"],
      names_2: ["可带人(需付报名费)", "仅本人报名"],
      values: ["canOther", "onlySelf"],
    },
    signOtherLimits: [
      "不限人数",
      "限带1人",
      "限带2人",
      "限带3人",
      "限带4人",
      "限带5人",
      "限带6人",
      "限带7人",
      "限带8人",
      "限带9人",
    ],
    canSignLater: {
      names: ["开始后，不可补报名", "结束前，可补报名"],
      values: [!1, !0],
    },
  };
