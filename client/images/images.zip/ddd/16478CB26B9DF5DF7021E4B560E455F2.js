var e = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = getApp(),
  r = {
    names: ["智能排序", "报名顺序", "等级排序", "备注排序"],
    values: ["smart", "bytime", "bylevel", "byremark"],
  },
  s = {
    names: ["分组安排", "智能排序", "报名顺序", "等级排序", "备注排序"],
    values: ["group", "smart", "bytime", "bylevel", "byremark"],
  };
module.exports = Behavior({
  data: {
    players: [],
    crtOrder: "",
    orderConfig: r,
    groupList: null,
    signed: null,
    smart: null,
    levels: null,
    byremarks: null,
    manCnt: "",
    womanCnt: "",
    nogender: "",
    alternates: "",
    retreats: "",
    uniPlayers: "",
    selfPlayer: "",
    isAlready: !1,
    crtTimeMil: "",
    hasAnonymous: !1,
    hasOtherHead: !1,
    hasGrouped: !1,
    maxGroupNO: 0,
  },
  methods: {
    _getActivityPlayers: function () {
      var r = this;
      this.data.activity &&
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "getActivityPlayers",
            activityid: this.data.activity._id,
            clubid: this.data.activity._infos.clubid,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (e) {
            wx.hideLoading(),
              (0, t.mylog)("getActivityPlayers: ", e),
              null === e.result.players
                ? r.setData({
                    players: [],
                    roles: r._dealRoles([]),
                    hasAnonymous: !1,
                    hasOtherHead: !1,
                  })
                : (r.setData({
                    players: e.result.players,
                    roles: r._dealRoles(e.result.players),
                  }),
                  r._dealPlayersCommNext()),
              (a.globalData.activityInfo.crtPlayers = r.data.players);
          },
          fail: function (a) {
            (0, t.mylog)("getActivityPlayers err: ", a),
              (0, e.networkFail)(!1, a, "activity.getActivityPlayers");
          },
          complete: function (e) {
            r.setData({ triggered: !1 });
          },
        });
    },
    _dealRoles: function (l) {
      l || (l = []);
      var n = new Date().getTime();
      (0, t.mylog)("start: ", n);
      for (var i = 0; i < l.length; i++) {
        var o = l[i];
        "self" === o._signType
          ? (o.gender = o._gender[0])
          : (o.gender = o._otherInfos.gender);
      }
      for (var p = [], h = 0; h < l.length; h++) {
        for (var d = 0; d < p.length && p[d].playerid !== l[h]._playerid; d++);
        d >= p.length
          ? ("self" === l[h]._signType ? (l[h]._num = 0) : (l[h]._num = 1),
            p.push({ playerid: l[h]._playerid, players: [l[h]] }))
          : ("self" === p[d].players[0]._signType
              ? (l[h]._num = p[d].players.length)
              : (l[h]._num = p[d].players.length + 1),
            p[d].players.push(l[h]));
      }
      for (var g = [], u = 0; u < p.length; u++)
        for (var _ = 0; _ < p[u].players.length; _++) g.push(p[u].players[_]);
      for (var y = [], f = [], v = 0; v < g.length; v++)
        "normal" === g[v]._status ? y.push(g[v]) : f.push(g[v]);
      y = y.sort(function (e, t) {
        return e._no - t._no;
      });
      for (var c = [], m = [], T = !1, O = 0, b = 0; b < y.length; b++) {
        var w = y[b];
        b < this.data.activity._infos.figures
          ? ((w._isAlternate = !1),
            c.push(w),
            w._groupNo && ((T = !0), O < w._groupNo && (O = w._groupNo)))
          : ((w._isAlternate = !0), m.push(w));
      }
      for (var I = null, A = 0; A < y.length; A++) {
        var D = y[A];
        if ("self" === D._signType && D._playerid === this.data.selfid) {
          I = D;
          break;
        }
      }
      (f = f.sort(function (e, t) {
        return e._updatetimemil - t._updatetimemil;
      })),
        (g = []);
      for (var P = 0; P < c.length; P++) g.push(c[P]);
      p = [];
      for (var x = [], L = 0; L < g.length; L++) {
        var G = g[L];
        for (d = 0; d < p.length && p[d]._playerid !== G._playerid; d++);
        if (d >= p.length) {
          p.push(G);
          var N = p[p.length - 1];
          (N._total = 1),
            "self" === G._signType
              ? G._gender[0] <= 1
                ? ((N._man = 1), (N._woman = 0))
                : ((N._man = 0), (N._woman = 1))
              : G._otherInfos.gender <= 1
              ? ((N._man = 1), (N._woman = 0))
              : ((N._man = 0), (N._woman = 1)),
            (N.selected = !0),
            x.push([G]);
        } else {
          var k = p[d];
          k._total++,
            "self" === G._signType
              ? G._gender[0] <= 1
                ? k._man++
                : k._woman++
              : G._otherInfos.gender <= 1
              ? k._man++
              : k._woman++,
            x[d].push(G);
        }
      }
      for (var C = 0; C < x.length; C++)
        x[C] = x[C].sort(function (e, t) {
          return t._signType < e._signType
            ? -1
            : t._signType === e._signType
            ? 0
            : 1;
        });
      for (var S = [], H = 0; H < x.length; H++)
        for (var F = 0; F < x[H].length; F++) S.push(x[H][F]);
      var R = [];
      if (T) {
        for (var M = 0; M <= O; M++) R.push({ showPlayers: !0, players: [] });
        for (var j = 0; j < S.length; j++) {
          var q = JSON.parse(JSON.stringify(S[j]));
          q._groupNo ? R[q._groupNo - 1].players.push(q) : R[O].players.push(q);
        }
      }
      for (var B = [], J = 0; J < S.length; J++) {
        var V = S[J];
        "self" === V._signType
          ? V._memInfo &&
            V._memInfo.level &&
            V._memInfo.level.length > 0 &&
            V._memInfo.level >= 0
            ? (V.level = (0, e.calcLevel)(
                V._memInfo.level[0],
                V._memInfo.levelvice[0]
              ))
            : V._infos &&
              V._infos.length > 0 &&
              (V._infos[0].level || 0 === V._infos[0].level)
            ? (V.level = (0, e.calcLevel)(
                V._infos[0].level,
                V._infos[0].levelvice
              ))
            : (V.level = -1)
          : V._otherInfos && V._otherInfos.level
          ? (V.level = (0, e.calcLevel)(
              V._otherInfos.level,
              V._otherInfos.levelvice
            ))
          : (V.level = -1),
          B.push(V);
      }
      B = B.sort(function (e, t) {
        return t.level - e.level;
      });
      for (var z = [], E = 0; E < S.length; E++) {
        var K = S[E];
        z.push(K);
      }
      z = z.sort(function (e, t) {
        return e._postscript && t._postscript
          ? e._postscript === t._postscript
            ? 0
            : e._postscript < t._postscript
            ? -1
            : 1
          : !e._postscript && t._postscript
          ? 1
          : e._postscript && !t._postscript
          ? -1
          : 0;
      });
      for (var Q = !1, U = 0; U < l.length; U++) {
        var W = l[U];
        if (W._anonymous && W._anonymous.isAnonymous) {
          Q = !0;
          break;
        }
      }
      for (var X = !1, Y = 0; Y < l.length; Y++) {
        var Z = l[Y];
        if (Z._setOtherHead && Z._setOtherHead.isSetted) {
          X = !0;
          break;
        }
      }
      if ("mySelf" === this.data.listType) {
        for (var $ = [], ee = 0; ee < c.length; ee++)
          c[ee]._playerid === this.data.selfid && $.push(c[ee]);
        (c = $), ($ = []);
        for (var te = 0; te < S.length; te++)
          S[te]._playerid === this.data.selfid && $.push(S[te]);
        (S = $), ($ = []);
        for (var ae = 0; ae < m.length; ae++)
          m[ae]._playerid === this.data.selfid && $.push(m[ae]);
        (m = $), ($ = []);
        for (var re = 0; re < f.length; re++)
          f[re]._playerid === this.data.selfid && $.push(f[re]);
        (f = $), (Q = !1);
        for (var se = 0; se < l.length; se++) {
          var le = l[se];
          if (
            le._playerid === this.data.selfid &&
            le._anonymous &&
            le._anonymous.isAnonymous
          ) {
            Q = !0;
            break;
          }
        }
        X = !1;
        for (var ne = 0; ne < l.length; ne++) {
          var ie = l[ne];
          if (
            ie._playerid === this.data.selfid &&
            ie._setOtherHead &&
            ie._setOtherHead.isSetted
          ) {
            X = !0;
            break;
          }
        }
        c.length <= 0 &&
          (m.length > 0
            ? this.setData({ crtTypeIdx: 1, crtType: "alternates" })
            : this.setData({ crtTypeIdx: 2, crtType: "retreats" }));
      }
      ("players" !== this.data.pageType &&
        "manager" !== this.data.pageType &&
        "retreat" !== this.data.pageType) ||
        this.setData({
          "switchList[0].text": "报名 (" + c.length + ")",
          "switchList[1].text": "候补 (" + m.length + ")",
          "switchList[2].text": "退坑 (" + f.length + ")",
        });
      var oe = r,
        pe = "smart";
      if (
        (this.data.activity._infos.groupOnlyManager &&
        "players" === this.data.pageType
          ? this.data.crtOrder &&
            "group" != this.data.crtOrder &&
            (pe = this.data.crtOrder)
          : (T &&
              (("players" !== this.data.pageType &&
                "manager" !== this.data.pageType &&
                "addSubRace" !== this.data.pageType &&
                "groupsByhand" !== this.data.pageType &&
                "groupsModify" !== this.data.pageType &&
                "groupsRescind" !== this.data.pageType) ||
                (oe = s)),
            T && !this.data.crtOrder
              ? (pe = "group")
              : this.data.crtOrder &&
                (pe =
                  T || "group" !== this.data.crtOrder
                    ? this.data.crtOrder
                    : "smart")),
        this.setData({
          signed: c,
          smart: S,
          levels: B,
          byremarks: z,
          groupList: R,
          hasGrouped: T,
          maxGroupNO: O,
          alternates: m,
          retreats: f,
          uniPlayers: p,
          selfPlayer: I,
          crtTimeMil: n,
          isAlready: !0,
          hasAnonymous: Q,
          hasOtherHead: X,
          orderConfig: oe,
          crtOrder: pe,
        }),
        this._countGenders(),
        this._dealShowAlternates(),
        a.globalData.isConsoleLog)
      ) {
        var he = new Date().getTime();
        console.log("end: ", he, "耗时：", he - n + "ms");
      }
    },
    _countGenders: function () {
      for (
        var e = this.data.signed, t = 0, a = 0, r = 0, s = 0;
        s < e.length;
        s++
      ) {
        var l = e[s];
        "self" === l._signType
          ? l._gender.length > 0 &&
            (1 === l._gender[0] ? t++ : 2 === l._gender[0] ? a++ : r++)
          : l._otherInfos &&
            (1 === l._otherInfos.gender
              ? t++
              : 2 === l._otherInfos.gender
              ? a++
              : r++);
      }
      this.setData({ manCnt: t, womanCnt: a, nogender: r });
    },
    _dealShowAlternates: function () {},
    _dealPlayersCommNext: function () {},
    onGroupsFold: function (e) {
      this._dealGroupsFoldOpen(e, !1);
    },
    onGroupsOpen: function (e) {
      this._dealGroupsFoldOpen(e, !0);
    },
    _dealGroupsFoldOpen: function (e, t) {
      var a = e.currentTarget.dataset.index,
        r = this.data.groupList;
      (r[a].showPlayers = t), this.setData({ groupList: r });
    },
  },
});
