module.exports = {
  getHeadsConfig: function () {
    return e;
  },
};
var e = {
  path: "https://7265-release-4gu559kx64ec58e8-1304436009.tcb.qcloud.la/sysheads/anonymous/",
  genderHeads: {
    man: [
      { id: "ghm_010", name: "匿名小哥", file: "genderHeads/man/ghm_010.png" },
      { id: "ghm_020", name: "匿名小帅", file: "genderHeads/man/ghm_020.png" },
      { id: "ghm_030", name: "匿名小卡", file: "genderHeads/man/ghm_030.png" },
      { id: "ghm_040", name: "匿名学长", file: "genderHeads/man/ghm_040.png" },
      { id: "ghm_050", name: "匿名学弟", file: "genderHeads/man/ghm_050.png" },
      { id: "ghm_060", name: "匿名大哥", file: "genderHeads/man/ghm_060.png" },
      { id: "ghm_070", name: "匿名帅哥", file: "genderHeads/man/ghm_070.png" },
      { id: "ghm_080", name: "匿名叔叔", file: "genderHeads/man/ghm_080.png" },
      { id: "ghm_090", name: "匿名大叔", file: "genderHeads/man/ghm_090.png" },
      { id: "ghm_100", name: "匿名医生", file: "genderHeads/man/ghm_100.png" },
      { id: "ghm_110", name: "匿名大厨", file: "genderHeads/man/ghm_110.png" },
      {
        id: "ghm_120",
        name: "匿名工程师",
        file: "genderHeads/man/ghm_120.png",
      },
    ],
    woman: [
      {
        id: "ghw_010",
        name: "匿名小姐姐",
        file: "genderHeads/woman/ghw_010.png",
      },
      {
        id: "ghw_020",
        name: "匿名学妹",
        file: "genderHeads/woman/ghw_020.png",
      },
      {
        id: "ghw_030",
        name: "匿名学姐",
        file: "genderHeads/woman/ghw_030.png",
      },
      {
        id: "ghw_040",
        name: "匿名姐姐",
        file: "genderHeads/woman/ghw_040.png",
      },
      {
        id: "ghw_050",
        name: "匿名小美",
        file: "genderHeads/woman/ghw_050.png",
      },
      {
        id: "ghw_060",
        name: "匿名忙姐",
        file: "genderHeads/woman/ghw_060.png",
      },
      {
        id: "ghw_070",
        name: "匿名靓妹",
        file: "genderHeads/woman/ghw_070.png",
      },
      {
        id: "ghw_080",
        name: "匿名大姐",
        file: "genderHeads/woman/ghw_080.png",
      },
      {
        id: "ghw_090",
        name: "知心大姐",
        file: "genderHeads/woman/ghw_090.png",
      },
      {
        id: "ghw_100",
        name: "匿名萌妹",
        file: "genderHeads/woman/ghw_100.png",
      },
      {
        id: "ghw_120",
        name: "美女老师",
        file: "genderHeads/woman/ghw_120.png",
      },
      {
        id: "ghw_130",
        name: "美女大厨",
        file: "genderHeads/woman/ghw_130.png",
      },
    ],
  },
  roleHeads: {
    man: [
      { id: "rhm_010", name: "匿名萌新", file: "roleHeads/man/rhm_010.png" },
      { id: "rhm_020", name: "匿名小趴菜", file: "roleHeads/man/rhm_020.png" },
      { id: "rhm_030", name: "羽球新秀", file: "roleHeads/man/rhm_030.png" },
      { id: "rhm_040", name: "羽林老鸟", file: "roleHeads/man/rhm_040.png" },
      { id: "rhm_050", name: "匿名重炮手", file: "roleHeads/man/rhm_050.png" },
      { id: "rhm_060", name: "匿名挑战者", file: "roleHeads/man/rhm_060.png" },
      { id: "rhm_070", name: "高手小哥", file: "roleHeads/man/rhm_070.png" },
      { id: "rhm_080", name: "匿名男高", file: "roleHeads/man/rhm_080.png" },
      { id: "rhm_090", name: "封网男高", file: "roleHeads/man/rhm_090.png" },
      { id: "rhm_100", name: "超强男高", file: "roleHeads/man/rhm_100.png" },
      { id: "rhm_110", name: "专业男高", file: "roleHeads/man/rhm_110.png" },
      { id: "rhm_120", name: "裁判大叔", file: "roleHeads/man/rhm_120.png" },
    ],
    woman: [
      { id: "rhw_010", name: "萌萌新", file: "roleHeads/woman/rhw_010.png" },
      { id: "rhw_000", name: "啦啦队", file: "roleHeads/woman/rhw_000.png" },
      {
        id: "rhw_020",
        name: "匿名小可爱",
        file: "roleHeads/woman/rhw_020.png",
      },
      {
        id: "rhw_030",
        name: "匿名小菜鸟",
        file: "roleHeads/woman/rhw_030.png",
      },
      {
        id: "rhw_040",
        name: "只打养生球",
        file: "roleHeads/woman/rhw_040.png",
      },
      { id: "rhw_050", name: "打我队友", file: "roleHeads/woman/rhw_050.png" },
      { id: "rhw_060", name: "美女新秀", file: "roleHeads/woman/rhw_060.png" },
      { id: "rhw_070", name: "匿名女高", file: "roleHeads/woman/rhw_070.png" },
      { id: "rhw_080", name: "超强女高", file: "roleHeads/woman/rhw_080.png" },
      { id: "rhw_090", name: "羽球女王", file: "roleHeads/woman/rhw_090.png" },
      { id: "rhw_100", name: "专业女神", file: "roleHeads/woman/rhw_100.png" },
      { id: "rhw_110", name: "裁判大姐", file: "roleHeads/woman/rhw_110.png" },
    ],
  },
  secretHeads: {
    man: [
      { id: "shm_010", name: "神秘嘉宾", file: "secretHeads/man/shm_010.png" },
      { id: "shm_020", name: "蒙面球王", file: "secretHeads/man/shm_020.png" },
      { id: "shm_030", name: "神秘男高", file: "secretHeads/man/shm_030.png" },
    ],
    woman: [
      {
        id: "shw_010",
        name: "神秘嘉宾",
        file: "secretHeads/woman/shw_010.png",
      },
      {
        id: "shw_020",
        name: "蒙面女神",
        file: "secretHeads/woman/shw_020.png",
      },
      {
        id: "shw_030",
        name: "神秘女高",
        file: "secretHeads/woman/shw_030.png",
      },
    ],
  },
};
