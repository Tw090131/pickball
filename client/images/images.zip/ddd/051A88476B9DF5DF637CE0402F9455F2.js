var t = require("BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp();
module.exports = Behavior({
  data: {
    activity: null,
    status: "loading",
    selfid: "",
    isActPlayer: !1,
    isSignOther: !1,
  },
  methods: {
    _getActivity: function () {
      var e = this,
        l = {
          fun: "getActivity",
          activityid: this.data.activityid,
          isDebug: i.globalData.isDebug,
          version: i.globalData.frontVersion,
        };
      i.globalData.userOpenId &&
        (l.userInfo = { openId: i.globalData.userOpenId }),
        wx.cloud.callFunction({
          name: "activity",
          data: l,
          success: function (t) {
            (0, a.mylog)("getActivity: ", t),
              null === t.result.activity
                ? e.setData({ status: "normal", activity: null })
                : (e.setData({
                    activity: t.result.activity,
                    status: t.result.activity._status,
                    selfid: t.result.selfid,
                    isActPlayer: t.result.isPlayer,
                    isSignOther: t.result.signOther,
                  }),
                  e._dealBanShare()),
              (i.globalData.activityInfo.crtActivity = e.data.activity),
              (i.globalData.selfid = e.data.selfid),
              wx.hideLoading();
          },
          fail: function (i) {
            (0, a.mylog)("getActivity err: ", i),
              (0, t.networkFail)(!1, i, "activity.getActivity");
          },
          complete: function (t) {
            e.setData({ triggered: !1 });
          },
        });
    },
    _dealBanShare: function () {
      if (
        "activity" === this.data.pageType ||
        "players" === this.data.pageType
      ) {
        var t = this.data.activity,
          a = t._infos,
          i = new Date().getTime();
        !a.banShare ||
        i > t._startTimeMil ||
        this.data.selfid === t._creatorid ||
        (t.me &&
          t.me.role.length > 0 &&
          ("president" === t.me.role[0] || "manager" === t.me.role[0]))
          ? wx.showShareMenu()
          : wx.hideShareMenu();
      }
    },
    _getClubMsgCount: function () {
      this.data.activity &&
        this.data.activity.me &&
        this.data.activity.me.role.length > 0 &&
        ("president" === this.data.activity.me.role[0] ||
          "manager" === this.data.activity.me.role[0]) &&
        wx.cloud.callFunction({
          name: "club",
          data: {
            fun: "getClubNews",
            clubid: this.data.activity.club._id[0],
            isDebug: i.globalData.isDebug,
            version: i.globalData.frontVersion,
          },
          success: function (t) {
            (0, a.mylog)("getClubNews: ", t);
          },
          fail: function (t) {
            (0, a.mylog)("getClubNews: ", t);
          },
        });
    },
  },
});
