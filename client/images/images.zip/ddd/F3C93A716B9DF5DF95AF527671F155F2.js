var t = require("981C1DB26B9DF5DFFE7A75B5964555F2.js");
module.exports = Behavior({
  data: {
    groups: [],
    groupCanPlayer: !1,
    groupOnlyManager: !1,
    changed: !1,
    toView: "",
    limitChanged: !1,
  },
  methods: {
    _initGroups: function (t) {
      var a = Math.round(t / 6);
      a < 2 ? (a = 2) : a > 5 && (a = 5);
      for (var e = [], n = 0; n < a; n++)
        e.push({
          no: n + 1,
          name: "",
          limitMax: this.data.groupCanPlayer ? 6 : "",
          crtPerson: 0,
        });
      return e;
    },
    onGroupNameLimit: function (a) {
      (0, t.mylog)("onGroupNameLimit, e: ", a);
      var e = a.currentTarget.dataset.index;
      this._nameLimitPop(e);
    },
    _nameLimitPop: function (t) {
      var a = this.selectComponent("#nameLimit");
      a && (a.init({ groups: this.data.groups, groupIndex: t }), a.showPop());
    },
    onGroupEdited: function (t) {
      this.setData({
        groups: t.detail.groups,
        changed: !0,
        limitChanged: t.detail.limitChanged,
      });
    },
    onAddGroup: function () {
      var t = this,
        a = this.data.groups;
      if (a.length >= 20)
        wx.showToast({ title: "最多20个分组哦", icon: "none" });
      else {
        a.push({
          no: a.length,
          name: "",
          limitMax: this.data.groupCanPlayer ? 6 : "",
          crtPerson: 0,
        }),
          this.setData({ groups: a, changed: !0 });
        var e = setTimeout(function () {
          t.setData({ toView: "listEnd" }), clearTimeout(e);
        }, 300);
      }
    },
    onDeleteGroup: function (a) {
      var e = this.data.groups,
        n = a.currentTarget.dataset.index;
      (0, t.mylog)("onDeleteGroup, index: ", n),
        e.splice(n, 1),
        this.setData({ groups: e, changed: !0 });
    },
    onGroupPublic: function () {
      this.setData({ groupOnlyManager: !1, changed: !0 });
    },
    onGroupOnlyManager: function () {
      this.setData({ groupOnlyManager: !0, changed: !0 });
    },
  },
});
