module.exports = {
  getBattleConfig: function () {
    return JSON.parse(JSON.stringify(e));
  },
};
var e = {
  member: 0,
  memGender: 0,
  memRaceCnt: 0,
  memLevel: -1,
  timeRange: { nearDays: 180, start: 15552e6, end: 0 },
  multiMode: "all",
  multiType: "all",
  selections: {
    point: !0,
    ballsNet: !0,
    alls: !1,
    wins: !1,
    gold: !1,
    silver: !1,
    copper: !1,
    last: !1,
    roundAll: !1,
    roundWin: !1,
    ballsAll: !1,
    ballsWin: !1,
    winRate: !0,
    roundRate: !1,
    ballsRate: !1,
  },
};
