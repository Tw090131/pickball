module.exports = Behavior({
  methods: {
    _getTypeIndex: function (t) {
      for (var e = this.data.switchList, i = 0; i < e.length; i++)
        if (t === e[i].type) return i;
      return 0;
    },
    _getTypeText: function (t) {
      for (var e = this.data.switchList, i = 0; i < e.length; i++)
        if (t === e[i].type) return e[i].text;
      return "";
    },
    _getTypeText2: function (t) {
      for (var e = this.data.switchList, i = 0; i < e.length; i++)
        if (t === e[i].type) return e[i].text2;
      return "";
    },
    onSwitchType: function (t) {
      var e = this.data.crtType;
      this.setData({
        crtType: t.detail.type,
        crtTypeIdx: this._getTypeIndex(t.detail.type),
      }),
        e != this.data.crtType && this._dealSwitchType();
    },
    onSwiperChanged: function (t) {
      if ("touch" === t.detail.source) {
        var e = t.detail.current;
        this.setData({ crtType: this.data.switchList[e].type, crtTypeIdx: e }),
          this._dealSwitchType();
      }
    },
    _dealSwitchType: function () {},
    _getFirstType: function () {
      return this.data.switchList.length > 0
        ? this.data.switchList[0].type
        : "";
    },
    _getCrtType: function () {
      return this.data.crtType;
    },
  },
});
