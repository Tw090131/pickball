var e = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  a = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  n = getApp(),
  o = require("../../265411956B9DF5DF40327992F90555F2.js");
Page({
  behaviors: [o],
  data: {
    navInfo: (0, e.getNavInfo)(),
    nickname: "",
    gender: 0,
    action: "",
    isAgree: !1,
  },
  onLoad: function (e) {
    var t = this;
    e.action && this.setData({ action: e.action }),
      wx.getPrivacySetting &&
        wx.getPrivacySetting({
          success: function (e) {
            if (
              ((0, a.mylog)("getPrivacySetting, res: ", e), e.needAuthorization)
            )
              var n = setTimeout(function () {
                t.selectComponent("#privacy").showPop(), clearTimeout(n);
              }, 600);
          },
        });
  },
  onReady: function () {},
  onShow: function () {
    var t = {
      fun: "selfInfo",
      isDebug: n.globalData.isDebug,
      version: n.globalData.frontVersion,
    };
    n.globalData.userOpenId &&
      (t.userInfo = { openId: n.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "user",
        data: t,
        success: function (t) {
          if (((0, a.mylog)("selfInfo: ", t), t.result.userinfo)) {
            (n.globalData.selfInfo = t.result.userinfo),
              (n.globalData.selfid = t.result.selfid),
              wx.showToast({ title: "您已登录哦", duration: 2e3 });
            var o = setTimeout(function () {
              (0, e.dealBack)(), clearTimeout(o);
            }, 2e3);
          }
        },
        fail: function (e) {
          (0, a.mylog)("selfInfo err: ", e);
        },
      });
  },
  onHide: function () {},
  onUnload: function () {},
  onNickInput: function (e) {
    (0, a.mylog)("onNickInput, e: ", e),
      this.setData({ nickname: e.detail.value });
  },
  onGenderMan: function () {
    this.setData({ gender: 1 });
  },
  onGenderWoman: function () {
    this.setData({ gender: 2 });
  },
  onAgree: function () {
    this.data.isAgree
      ? this.setData({ isAgree: !1 })
      : this.setData({ isAgree: !0 });
  },
  onAgreement: function () {
    (0, e.navTo)({ url: "/packageA/pages/mine/agreement/service" });
  },
  onConfirm: function () {
    if (this.data.avatarUrl && this.data.avatarUrl !== this.data.defaultUrl) {
      var e = this.data.nickname;
      e
        ? (e = e.trim())
          ? (0, t.checkNickName)(e) &&
            (this.data.gender
              ? this.data.isAgree
                ? this._upLoadFile()
                : wx.showToast({
                    title: "请同意羽毛球助手服务协议",
                    icon: "none",
                  })
              : wx.showToast({ title: "请选择性别", icon: "none" }))
          : wx.showToast({ title: "请输入有效昵称", icon: "none" })
        : wx.showToast({ title: "请输入昵称", icon: "none" });
    } else wx.showToast({ title: "请设置头像", icon: "none" });
  },
  _upLoadFile: function () {
    var n = this;
    wx.showLoading({ title: "登录中", mask: !0 }),
      wx.cloud.uploadFile({
        cloudPath: (0, t.makeAvatarPath)(this.data.avatarUrl),
        filePath: this.data.avatarUrl,
        success: function (e) {
          (0, a.mylog)("uploadFile, res: ", e), n._getUrl(e.fileID);
        },
        fail: function (t) {
          (0, a.mylog)("uploadFile, err: ", t),
            wx.showToast({ title: "系统繁忙，请重试", icon: "none" }),
            (0, e.cloudLog)({ funName: "uploadFile", type: "fail", err: t });
        },
      });
  },
  _getUrl: function (t) {
    var n = this;
    wx.cloud.getTempFileURL({
      fileList: [t],
      success: function (e) {
        (0, a.mylog)("getUrl, res: ", e),
          e.fileList.length <= 0
            ? wx.showToast({ title: "系统繁忙，请重试", icon: "none" })
            : n._dealLogin(e.fileList[0].tempFileURL, t);
      },
      fail: function (t) {
        (0, a.mylog)("getUrl, err: ", t),
          wx.showToast({ title: "系统繁忙，请重试", icon: "none" }),
          (0, e.cloudLog)({ funName: "getTempFileURL", type: "fail", err: t });
      },
    });
  },
  _dealLogin: function (t, o) {
    var i = this,
      s = {
        nickName: this.data.nickname.trim(),
        avatarUrl: t,
        avatarID: o,
        gender: this.data.gender,
      };
    wx.cloud.callFunction({
      name: "user",
      data: {
        fun: "wxLogin",
        userinfo: s,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      },
      success: function (t) {
        if (
          ((0, a.mylog)("wxLogin, res: ", t),
          wx.hideLoading(),
          "fail" === t.result.type)
        )
          wx.showModal({
            content: t.result.msg,
            showCancel: !1,
            confirmText: "好的",
          });
        else {
          (n.globalData.selfInfo = s),
            (n.globalData.selfid = t.result.openId),
            (n.globalData.options.channel = t.result.channel),
            wx.showToast({ title: "登录成功", duration: 1e3 });
          var o = setTimeout(function () {
            switch (i.data.action) {
              case "target":
                wx.redirectTo({ url: n.globalData.loginTargetUrl });
                break;
              case "returnext":
                (n.globalData.isLoginedReturn = !0), (0, e.dealBack)();
                break;
              default:
                (0, e.dealBack)();
            }
            clearTimeout(o);
          }, 1e3);
        }
      },
      fail: function (e) {
        wx.hideLoading(), (0, a.mylog)("wxLogin, err: ", e);
      },
    });
  },
  onPrivacyReject: function () {
    wx.navigateBack();
  },
  onPrivacyAgree: function () {
    this.setData({ isAgree: !0 });
  },
  onGenderQues: function () {
    wx.showModal({
      content:
        "羽毛球分男单/女单/男双/女双/混双，为了防止数据混乱，登录后性别不可修改。若混双转男女人数不等，改用前后转即可。",
      showCancel: !1,
      confirmText: "好的",
    });
  },
});
