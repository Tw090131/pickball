var e = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js");
Page({
  data: { navInfo: (0, e.getNavInfo)() },
  onLoad: function (e) {
    if (
      ((0, a.mylog)("multiRace, onLoad, options: ", e),
      e.from && "creater" === e.from)
    )
      wx.redirectTo({
        url:
          "/packageC/pages/multiRace/multiRace?from=creater&raceMode=" +
          e.raceMode,
      });
    else if (e.from && "clubCreate" === e.from)
      wx.redirectTo({
        url:
          "/packageC/pages/multiRace/multiRace?from=clubCreate&raceMode=" +
          e.raceMode +
          "&clubid=" +
          e.clubid,
      });
    else {
      var r = "";
      e.raceid && (r += "raceid=" + e.raceid),
        e.scene && (r && (r += "&"), (r += "scene=" + e.scene)),
        e.from && (r && (r += "&"), (r += "from=" + e.from)),
        e.raceMode && (r && (r += "&"), (r += "raceMode=" + e.raceMode)),
        e.clubid && (r && (r += "&"), (r += "clubid=" + e.clubid)),
        e.no && (r && (r += "&"), (r += "no=" + e.no)),
        e.invite && (r && (r += "&"), (r += "invite=" + e.invite)),
        e.tabType && (r && (r += "&"), (r += "tabType=" + e.tabType)),
        (0, a.mylog)("qura: ", r),
        wx.redirectTo({ url: "/packageC/pages/multiRace/multiRace?" + r });
    }
  },
});
