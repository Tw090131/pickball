var e = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  r = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js");
Page({
  data: { navInfo: (0, e.getNavInfo)() },
  onLoad: function (e) {
    if (e.from && "creater" === e.from)
      wx.redirectTo({ url: "/packageD/pages/club/club?from=creater" });
    else {
      var a = "";
      e.type && (a += "type=" + e.type),
        e.subtype && (a && (a += "&"), (a += "subtype=" + e.subtype)),
        e.share && (a && (a += "&"), (a += "share=" + e.share)),
        e.clubid && (a && (a += "&"), (a += "clubid=" + e.clubid)),
        e.scene && (a && (a += "&"), (a += "scene=" + e.scene)),
        e.invitorid && (a && (a += "&"), (a += "invitorid=" + e.invitorid)),
        e.name && (a && (a += "&"), (a += "name=" + e.name)),
        (0, r.mylog)("qura: ", a),
        wx.redirectTo({ url: "/packageD/pages/club/club?" + a });
    }
  },
});
