var n = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js");
Page({
  data: { navInfo: (0, n.getNavInfo)() },
  onLoad: function (n) {
    wx.redirectTo({ url: "/packageE/pages/levels/levels" });
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {},
});
