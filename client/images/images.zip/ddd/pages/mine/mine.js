var e = require("../../@babel/runtime/helpers/objectSpread2"),
  a = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  n = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  o = getApp();
Page({
  data: {
    navInfo: (0, a.getNavInfo)(),
    selfInfo: null,
    collect: null,
    triggered: !1,
    isDebug: !1,
    isLogining: !1,
    showUpgrade: !1,
    upgradeInfo: { tips: "从萌新到高手" },
    showUpgradeTest: !1,
    highestGrade: "",
  },
  onLoad: function (e) {
    this.setData({
      isDebug: o.globalData.isDebug,
      isConsoleLog: o.globalData.isConsoleLog,
    }),
      this._getTotalInfos();
  },
  onReady: function () {},
  onShow: function () {
    "function" == typeof this.getTabBar &&
      this.getTabBar() &&
      this.getTabBar().setData({ selected: 2 }),
      this._getUserInfo();
  },
  _getUserInfo: function () {
    var e = this,
      a = {
        fun: "selfInfo",
        isDebug: o.globalData.isDebug,
        version: o.globalData.frontVersion,
      };
    o.globalData.userOpenId &&
      (a.userInfo = { openId: o.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "user",
        data: a,
        success: function (a) {
          (0, n.mylog)("selfInfo: ", a),
            a.result.userinfo
              ? (e.setData({
                  selfInfo: a.result.userinfo,
                  selfid: a.result.selfid,
                  showUpgrade: a.result.showUpgrade,
                  upgradeInfo: a.result.upgrade,
                  showUpgradeTest: a.result.showUpgradeTest,
                }),
                (o.globalData.selfInfo = a.result.userinfo))
              : e.setData({
                  selfInfo: [],
                  showUpgrade: a.result.showUpgrade,
                  upgradeInfo: a.result.upgrade,
                  showUpgradeTest: a.result.showUpgradeTest,
                }),
            wx.hideLoading();
        },
        fail: function (e) {
          (0, n.mylog)("selfInfo err: ", e);
        },
        complete: function (a) {
          e.setData({ isLogining: !1 });
        },
      });
  },
  _getTotalInfos: function () {
    var e = this,
      a = {
        fun: "memCollect",
        clubid: null,
        memid: null,
        isDebug: o.globalData.isDebug,
        version: o.globalData.frontVersion,
      };
    o.globalData.userOpenId && (a.memid = o.globalData.userOpenId),
      wx.cloud.callFunction({
        name: "mine",
        data: a,
        success: function (a) {
          (0, n.mylog)("memCollect res: ", a),
            e.setData({ collect: a.result.collect });
        },
        fail: function (e) {
          (0, n.mylog)("memCollect err: ", e);
        },
        complete: function (a) {
          e.setData({ triggered: !1 });
        },
      });
  },
  _getHighestGrade: function () {
    var e = this,
      a = {
        fun: "getHighestGrade",
        isDebug: o.globalData.isDebug,
        version: o.globalData.frontVersion,
      };
    o.globalData.userOpenId &&
      (a.userInfo = { openId: o.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "tradeUpgrade",
        data: a,
        success: function (a) {
          (0, n.mylog)("getHighestGrade res: ", a),
            e.setData({ highestGrade: a.result.highestGrade });
        },
        fail: function (e) {
          (0, n.mylog)("getHighestGrade err: ", e);
        },
      });
  },
  onHide: function () {},
  onUnload: function () {},
  onShareAppMessage: function (e) {
    this._addShare();
    var a = "/pages/index/index";
    return "button" === e.from && "recommend" === e.target.id
      ? {
          imageUrl:
            "https://7265-release-4gu559kx64ec58e8-1304436009.tcb.qcloud.la/share/index/13-2.jpeg",
          title: "高效组织活动报名、八人转、混双转、循环积分赛，管理俱乐部",
          path: a,
        }
      : this.data.selfInfo && this.data.selfInfo.openid
      ? {
          title: "我的个人主页",
          path:
            "pages/mine/othermine/othermine?userid=" +
            this.data.selfInfo.openid,
        }
      : {
          imageUrl:
            "https://7265-release-4gu559kx64ec58e8-1304436009.tcb.qcloud.la/share/index/13-2.jpeg",
          title: "高效组织活动报名、八人转、混双转、循环积分赛，管理俱乐部",
          path: a,
        };
  },
  _addShare: function () {
    wx.cloud.callFunction({
      name: "share",
      data: {
        fun: "addShare",
        type: "personal",
        isDebug: o.globalData.isDebug,
        version: o.globalData.frontVersion,
      },
      success: function (e) {
        (0, n.mylog)("addShare, res: ", e);
      },
      fail: function (e) {
        (0, n.mylog)("addShare, err: ", e);
      },
    });
  },
  onWxLogin: function () {
    o.globalData.selfInfo || (0, a.navTo)({ url: "/pages/login/login" });
  },
  onMineSetting: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/setting/setting?from=mine" });
  },
  onRefresh: function () {
    this._getUserInfo(), this._getTotalInfos();
  },
  onAssess: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/setting/setting?action=assess" });
  },
  onMySingles: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/amount/winRate/singles" });
  },
  onMyDoubles: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/amount/winRate/doubles" });
  },
  onMyRefereeSingles: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/amount/referee/singles" });
  },
  onMyRefereeDoubles: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/amount/referee/doubles" });
  },
  onMyActivity: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myActivity/myActivity" });
  },
  onMyRace: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myRace/myRace" });
  },
  onMyScore: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myScore/myScore" });
  },
  onLevels: function () {
    (0, a.navTo)({ url: "/packageE/pages/levels/levels" });
  },
  onLevelsFromUnlogined: function () {
    (0, a.navTo)({ url: "/packageE/pages/levels/levels" });
  },
  onContest: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/contest/contest" });
  },
  onMyBalance: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myBalance/myBalance" });
  },
  onMypoint: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myPoint/myPoint" });
  },
  onMyBill: function () {
    (0, a.navTo)({ url: "/packageA/pages/mine/myBill/myBill" });
  },
  onGuider: function () {
    (0, a.navTo)({ url: "/packageE/pages/guider/guider" });
  },
  onUpgrade: function () {
    o.globalData.upGradeInfo.inviter
      ? (0, a.navTo)({ url: "/packageA/pages/upgrade/upgrade" })
      : (0, a.navTo)({
          url: "/packageA/pages/upgrade/upgrade?inviter=optHW5MV5MCYgEHvfuKKAmvvBf-0",
        });
  },
  onLeisure: function () {
    (0, a.navTo)({ url: "/packageE/pages/leisure/idiomGuess/idiomGuess" });
  },
  onVipfun: function () {
    (0, a.navTo)({ url: "/packageA/pages/vipfun/vipfun?from=mine" });
  },
  onHeadLoad: function (e) {
    (0, a.judgeHead)({
      head: e.detail,
      openid: e.currentTarget.dataset.playerid,
      selfid: this.data.selfInfo.openid,
    });
  },
  onPayTest: function () {
    wx.showLoading({ title: "支付中", mask: !0 }),
      wx.cloud.callFunction({
        name: "trade",
        data: {
          fun: "paycomm",
          isDebug: o.globalData.isDebug,
          version: o.globalData.frontVersion,
        },
        success: function (a) {
          var o = a.result.payment;
          (0, n.mylog)("payment: ", o),
            wx.hideLoading(),
            wx.requestPayment(
              e(
                e({}, o),
                {},
                {
                  success: function (e) {
                    (0, n.mylog)("pay res", e);
                  },
                  fail: function (e) {
                    (0, n.mylog)("pay err", e);
                  },
                  complete: function (e) {
                    wx.hideLoading();
                  },
                }
              )
            );
        },
        fail: function (e) {
          (0, n.mylog)("paycomm, err: ", e), wx.hideLoading();
        },
      });
  },
  onPayTest_2: function () {
    wx.showLoading({ title: "v3支付中", mask: !0 }),
      wx.cloud.callFunction({
        name: "tradeApiV3",
        data: {
          fun: "wxpay_v3",
          isDebug: o.globalData.isDebug,
          version: o.globalData.frontVersion,
        },
        success: function (a) {
          var o = a.result;
          (0, n.mylog)("payment: ", o),
            wx.hideLoading(),
            wx.requestPayment(
              e(
                e({}, o),
                {},
                {
                  success: function (e) {
                    (0, n.mylog)("pay res: ", e);
                  },
                  fail: function (e) {
                    (0, n.mylog)("pay fail", e);
                  },
                  complete: function (e) {
                    wx.hideLoading();
                  },
                }
              )
            );
        },
        fail: function (e) {
          (0, n.mylog)("wxpay_v3, err: ", e), wx.hideLoading();
        },
      });
  },
  onCashRetry: function () {
    (0, a.navTo)({ url: "/packageA/pages/manage/cashToWxRetry/cashRetry" });
  },
  onAllActivities: function () {
    (0, a.navTo)({ url: "/packageA/pages/manage/all/activity/activity" });
  },
  onAllRaces: function () {
    (0, a.navTo)({ url: "/packageA/pages/manage/all/race/race" });
  },
  onAllClubs: function () {
    (0, a.navTo)({ url: "/packageA/pages/manage/all/club/club" });
  },
});
