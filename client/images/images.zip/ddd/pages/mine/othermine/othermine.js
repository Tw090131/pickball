var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = e.getNavInfo,
  a = e.navTo,
  i = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js").mylog,
  n = getApp();
Page({
  data: {
    navInfo: t(),
    userid: null,
    userInfo: null,
    collect: null,
    isloading: !1,
    isDebug: n.globalData.isDebug,
    isConsoleLog: n.globalData.isConsoleLog,
    adOK: !0,
    isOrganizer: !1,
    nowMil: new Date().getTime(),
  },
  onLoad: function (e) {
    e.userid && this.setData({ userid: e.userid }),
      "asclub" === e.from &&
        this.setData({ from: "asclub", clubid: e.clubid, merole: e.merole });
    var t = getCurrentPages(),
      a = t.length;
    if ((i("crtPages: ", t), a >= 2)) {
      var s = n.globalData.selfid,
        o = t[a - 2].route;
      if (
        "packageC/pages/multiRace/multiRace" === o ||
        "packageC/pages/multiRace/loop/enter/players/players" === o ||
        "packageC/pages/multiRace/loop/enter/manager/manager" === o
      ) {
        var r = n.globalData.multiRaceInfo.raceInfo._infos.needPhone,
          u = n.globalData.multiRaceInfo.raceInfo._organizer;
        r && u === s && this.setData({ isOrganizer: !0 });
      } else if (
        "pages/activity/activity" === o ||
        "pages/activity/main/players/players" === o ||
        "pages/activity/main/manager/manager" === o
      ) {
        var l = n.globalData.activityInfo.crtActivity._infos.needPhone,
          c = n.globalData.activityInfo.crtActivity._creatorid;
        l && c === s && this.setData({ isOrganizer: !0 });
      }
    }
  },
  onReady: function () {},
  onShow: function () {
    this._getUserInfo(), this._getTotalInfos(), this._addView();
  },
  _addView: function () {
    this.data.userid &&
      wx.cloud.callFunction({
        name: "visitor",
        data: {
          fun: "addView",
          type: "personal",
          mainid: this.data.userid,
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (e) {
          i("addView, res: ", e);
        },
        fail: function (e) {
          i("addView, err: ", e);
        },
      });
  },
  _getUserInfo: function () {
    var e = this;
    wx.cloud.callFunction({
      name: "user",
      data: {
        fun: "userInfoSec",
        type: "other",
        openid: this.data.userid,
        visitorIsOrganizer: this.data.isOrganizer,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      },
      success: function (t) {
        i("userInfoSec: ", t),
          e.setData({
            userInfo: t.result.userinfo,
            selfid: t.result.selfid,
            nowMil: t.result.crtMil,
          });
      },
      fail: function (e) {
        i("userInfoSec err: ", e);
      },
    });
  },
  _getTotalInfos: function () {
    var e = this;
    this.data.collect || this.setData({ isloading: !0 }),
      wx.cloud.callFunction({
        name: "mine",
        data: {
          fun: "memCollect",
          clubid: null,
          memid: this.data.userid,
          isDebug: n.globalData.isDebug,
          version: n.globalData.frontVersion,
        },
        success: function (t) {
          i("memCollect res: ", t),
            e.setData({ collect: t.result.collect }),
            wx.hideLoading();
        },
        fail: function (e) {
          i("memCollect err: ", e);
        },
        complete: function (t) {
          e.setData({ triggered: !1, isloading: !1 });
        },
      });
  },
  onHide: function () {},
  onUnload: function () {},
  onShareAppMessage: function () {
    return {
      title: this.data.userInfo.nickName + "的个人主页",
      path: "pages/mine/othermine/othermine?userid=" + this.data.userid,
    };
  },
  onBigAvatar: function () {
    if ((this.data.isDebug || this.data.isConsoleLog) && this._checkVipfun()) {
      var e = this.selectComponent("#bigAvatar");
      e && (e.init({ user: this.data.userInfo }), e.showPop());
    }
  },
  _checkVipfun: function () {
    var e = n.globalData.selfInfo,
      t = this.data.nowMil;
    if (e && e.trustLevel >= 4 && e.trustDueMil > t) return !0;
    n.globalData.payVipfunInfo.payAt = {
      from: "othermine",
      userid: this.data.userid,
      mode: "bigAvatar",
    };
    var a = this.selectComponent("#payVisit");
    return a && (a.setMode("bigAvatar"), a.showPop()), !1;
  },
  onMySingles: function () {
    this._checkHideWinRate() &&
      (this._setMeout(),
      a({
        url:
          "/packageA/pages/mine/amount/winRate/singles?userid=" +
          this.data.userid,
      }));
  },
  onMyDoubles: function () {
    this._checkHideWinRate() &&
      (this._setMeout(),
      a({
        url:
          "/packageA/pages/mine/amount/winRate/doubles?userid=" +
          this.data.userid,
      }));
  },
  _checkHideWinRate: function () {
    var e = this.data.userInfo;
    if (!e) return wx.showToast({ title: "加载中，请稍等", icon: "none" }), !1;
    var t = this.data.nowMil;
    return (
      !(e.hideWinRate && e.trustLevel >= 4 && e.trustDueMil >= t) ||
      (wx.showModal({
        content: e.nickName + "已将胜率隐藏，查看不了详情哦",
        showCancel: !1,
        confirmText: "好的",
      }),
      !1)
    );
  },
  onMyRefereeSingles: function () {
    this._setMeout(),
      a({
        url:
          "/packageA/pages/mine/amount/referee/singles?userid=" +
          this.data.userid,
      });
  },
  onMyRefereeDoubles: function () {
    this._setMeout(),
      a({
        url:
          "/packageA/pages/mine/amount/referee/doubles?userid=" +
          this.data.userid,
      });
  },
  _setMeout: function () {
    n.globalData.meout = this.data.userInfo;
  },
  onMineSetting: function () {
    a({ url: "/packageA/pages/mine/setting/setting?from=mine" });
  },
  onOthersActivity: function () {
    (n.globalData.meout = this.data.userInfo),
      a({
        url:
          "/packageA/pages/forOther/activities/othersAct?userid=" +
          this.data.userid,
      });
  },
  onOthersRace: function () {
    this._setMeout(),
      a({
        url: "/packageA/pages/mine/myRace/myRace?userid=" + this.data.userid,
      });
  },
  onRefresh: function () {
    this._getUserInfo(), this._getTotalInfos();
  },
  onAssess: function () {
    a({ url: "/packageA/pages/mine/setting/setting?action=assess" });
  },
  onClub: function () {
    a({ url: "/packageD/pages/club/club?clubid=" + this.data.clubid });
  },
  onLevels: function () {
    a({ url: "/packageE/pages/levels/levels?type=simple" });
  },
  onAdLoad: function () {
    this.setData({ adOK: !0 });
  },
  onAdError: function () {
    this.setData({ adOK: !1 });
  },
  onCallPhone: function () {
    wx.makePhoneCall({ phoneNumber: this.data.userInfo.phone.phoneNumber });
  },
});
