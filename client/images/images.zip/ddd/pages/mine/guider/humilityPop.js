var e = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({ behaviors: [e], properties: {}, data: {}, methods: {} });
