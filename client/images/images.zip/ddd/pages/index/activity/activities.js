var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../9CD29CB36B9DF5DFFAB4F4B41AA455F2.js"),
  i = getApp(),
  a = require("../../../3F754DC46B9DF5DF591325C3CB1555F2.js");
Component({
  behaviors: [a],
  properties: {
    activityLoaded: { type: Boolean, value: "" },
    activityList: { type: Array, value: [] },
    selfid: { type: String, value: "" },
    triggered: { type: Boolean, value: !1 },
    allnum: { type: Number, value: 0 },
  },
  data: {
    navInfo: (0, e.getNavInfo)(),
    activityConfigs: (0, t.getConfig)(),
    nowMil: new Date().getTime(),
    isDebug: i.globalData.isDebug,
  },
  observers: {
    activityList: function () {
      this.setData({ nowMil: new Date().getTime() });
    },
  },
  pageLifetimes: {
    show: function () {
      this.setData({ nowMil: new Date().getTime() });
    },
  },
  methods: {
    onCreateActivity: function () {
      (0, e.navTo)({ url: "/pages/activity/activity?from=creater" });
    },
    onActivity: function (t) {
      (0, e.navTo)({
        url:
          "/pages/activity/activity?activityid=" +
          t.currentTarget.dataset.activityid,
      });
    },
    onLongpress: function (e) {
      this.onActivity(e);
    },
    onMoreActivity: function () {
      (0, e.navTo)({ url: "/packageA/pages/mine/myActivity/myActivity" });
    },
    onRefresh: function () {
      this.triggerEvent("refresh", {}, {});
    },
    onUpgrade: function () {
      (0, e.navTo)({ url: "/packageA/pages/upgrade/upgrade" });
    },
    onNewRace: function () {
      (0, e.navTo)({
        url: "/pages/index/creater/racePre?type=match&mode=freeMatch",
      });
    },
    onNewAct: function () {
      (0, e.navTo)({
        url: "/packageA/pages/receipt_2/intro/intro?id=receipt_10",
      });
    },
  },
});
