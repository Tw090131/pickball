var t = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  e = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = require("../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js"),
  s = getApp();
Page({
  behaviors: [a],
  data: {
    navInfo: (0, t.getNavInfo)(),
    crtTypeIdx: 0,
    crtType: "race",
    switchList: [
      { type: "race", text: "比赛" },
      { type: "activity", text: "活动" },
      { type: "club", text: "俱乐部" },
    ],
    raceList: [],
    raceLoaded: !1,
    raceAllNum: 0,
    activityList: [],
    activityLoaded: !1,
    actAllNum: 0,
    selfid: "",
    triggered: !1,
    myclubs: { list: null, crtPageNO: 1, isNoMore: !1 },
    myclubLoaded: !1,
    nearClubs: null,
    isLoading: !0,
    firstTab: "",
    ads: null,
  },
  onLoad: function (t) {
    (0, e.mylog)("index onload"), this._getNavTab();
  },
  testString: function () {},
  _getNavTab: function () {
    var t = this,
      a = {
        fun: "nav",
        isDebug: s.globalData.isDebug,
        version: s.globalData.frontVersion,
      };
    s.globalData.userOpenId &&
      (a.userInfo = { openId: s.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "index",
        data: a,
        success: function (a) {
          (0, e.mylog)("index nav: ", a),
            t.setData({ firstTab: a.result.firstTab, ads: a.result.ads }),
            t._setNav();
        },
        fail: function (a) {
          (0, e.mylog)("index nav: ", a),
            t.setData({ firstTab: "race" }),
            t._setNav();
        },
      });
  },
  _setNav: function () {
    switch (this.data.firstTab) {
      case "race":
        this.setData({
          crtTypeIdx: 0,
          crtType: "race",
          switchList: [
            { type: "race", text: "比赛" },
            { type: "activity", text: "活动" },
            { type: "club", text: "俱乐部" },
          ],
        }),
          this._getRecentRace();
        break;
      case "activity":
        this.setData({
          crtTypeIdx: 0,
          crtType: "activity",
          switchList: [
            { type: "activity", text: "活动" },
            { type: "race", text: "比赛", showNew: !0 },
            { type: "club", text: "俱乐部" },
          ],
        }),
          this._getRecentActivity();
    }
  },
  onReady: function () {
    (0, e.mylog)("index onReady");
  },
  onShow: function () {
    (0, e.mylog)("index onShow"),
      "function" == typeof this.getTabBar &&
        this.getTabBar() &&
        this.getTabBar().setData({ selected: 0 }),
      this.data.firstTab && this.onRefresh();
  },
  onRefresh: function () {
    switch (this.data.crtType) {
      case "race":
        this._getRecentRace();
        break;
      case "activity":
        this._getRecentActivity();
        break;
      case "club":
        this._getMyClubs(1);
        break;
      case "nearby":
        this._getNearClubs();
    }
  },
  _getRecentActivity: function () {
    var a = this,
      i = {
        fun: "recentActivitySec",
        isDebug: s.globalData.isDebug,
        version: s.globalData.frontVersion,
      };
    s.globalData.userOpenId &&
      (i.userInfo = { openId: s.globalData.userOpenId }),
      (this.data.activityList && 0 !== this.data.activityList.length) ||
        this.setData({ isLoading: !0 }),
      wx.cloud.callFunction({
        name: "index",
        data: i,
        success: function (s) {
          (0, e.mylog)("index recent activity: ", s),
            s.result && null !== s.result.list
              ? a.setData({
                  activityList: (0, t.makeUniPlayers)(s.result.list),
                  selfid: s.result.selfid,
                  actAllNum: s.result.count,
                })
              : a.setData({ activityList: [], actAllNum: s.result.count });
        },
        fail: function (t) {
          (0, e.mylog)("index recent activity fail: ", t);
        },
        complete: function (t) {
          a.setData({ isLoading: !1, triggered: !1, activityLoaded: !0 });
        },
      });
  },
  _getRecentRace: function () {
    var t = this,
      a = {
        fun: "recentRaceSec",
        isDebug: s.globalData.isDebug,
        version: s.globalData.frontVersion,
      };
    s.globalData.userOpenId &&
      (a.userInfo = { openId: s.globalData.userOpenId }),
      (this.data.raceList && 0 !== this.data.raceList.length) ||
        this.setData({ isLoading: !0 }),
      wx.cloud.callFunction({
        name: "index",
        data: a,
        success: function (a) {
          if (
            ((0, e.mylog)("index recent race: ", a),
            a.result && null !== a.result.list)
          ) {
            if (
              (t.setData({
                raceList: a.result.list,
                selfid: a.result.selfid,
                raceAllNum: a.result.count,
              }),
              "race" === t.data.firstTab)
            ) {
              var s = t.data.switchList;
              (s[1].showNew = !0), t.setData({ switchList: s });
            }
          } else t.setData({ raceList: [], raceAllNum: a.result.count });
        },
        fail: function (t) {
          (0, e.mylog)("index recent race fail: ", t);
        },
        complete: function (e) {
          t.setData({ isLoading: !1, triggered: !1, raceLoaded: !0 });
        },
      });
  },
  _getMyClubs: function (t) {
    var a = this;
    if (
      (1 === t && this.setData({ "myclubs.isNoMore": !1 }),
      !this.data.myclubs.isNoMore)
    ) {
      (null === this.data.myclubs.list || t >= 2) &&
        this.setData({ isLoading: !0 });
      var i = {
        fun: "myclubs",
        pageNO: t,
        isDebug: s.globalData.isDebug,
        version: s.globalData.frontVersion,
      };
      s.globalData.userOpenId &&
        (i.userInfo = { openId: s.globalData.userOpenId }),
        wx.cloud.callFunction({
          name: "index",
          data: i,
          success: function (s) {
            if (((0, e.mylog)("myclubs res: ", s), null === s.result.clubs))
              a.setData({
                myclubs: { list: null, crtPageNO: 1, isNoMore: !1 },
              });
            else {
              if (t <= 1) var i = s.result.clubs;
              else
                null === (i = a.data.myclubs.list) && (i = []),
                  (i = i.concat(s.result.clubs));
              a.setData({
                myclubs: { list: i, crtPageNO: t, isNoMore: s.result.isNoMore },
              });
            }
          },
          fail: function (t) {
            (0, e.mylog)("myclubs fail: ", t);
          },
          complete: function (t) {
            a.setData({ isLoading: !1, triggered: !1, myclubLoaded: !0 });
          },
        });
    }
  },
  _getNearClubs: function () {
    var t = this,
      a = {
        fun: "nearclubs",
        isDebug: s.globalData.isDebug,
        version: s.globalData.frontVersion,
      };
    s.globalData.userOpenId &&
      (a.userInfo = { openId: s.globalData.userOpenId }),
      null === this.data.nearClubs && this.setData({ isLoading: !0 }),
      wx.cloud.callFunction({
        name: "index",
        data: a,
        success: function (a) {
          (0, e.mylog)("nearclubs res: ", a),
            null === a.result.clubs
              ? t.setData({ nearclubs: null })
              : t.setData({ nearclubs: a.result.clubs });
        },
        fail: function (t) {
          (0, e.mylog)("nearclubs fail: ", t);
        },
        complete: function (e) {
          t.setData({ isLoading: !1, triggered: !1 });
        },
      });
  },
  _dealSwitchType: function () {
    switch (this.data.crtType) {
      case "race":
        (this.data.raceList && this.data.raceList.length > 0) ||
          this._getRecentRace();
        break;
      case "activity":
        (this.data.activityList && this.data.activityList.length > 0) ||
          this._getRecentActivity();
        break;
      case "club":
        (this.data.myclubs.list && this.data.myclubs.list.length > 0) ||
          this._getMyClubs(1);
        break;
      case "nearby":
        (this.data.nearClubs && this.data.nearClubs.length > 0) ||
          this._getNearClubs();
    }
  },
  onLower: function () {
    switch (this.data.crtType) {
      case "club":
        this._getMyClubs(this.data.myclubs.crtPageNO + 1);
    }
  },
  onHide: function () {},
  onUnload: function () {},
  onShareAppMessage: function () {
    return (
      this._addShare(),
      {
        imageUrl:
          "https://7265-release-4gu559kx64ec58e8-1304436009.tcb.qcloud.la/share/index/13-2.jpeg",
        title: "高效组织活动报名、八人转、混双转、循环积分赛，管理俱乐部",
        path: "/pages/index/index",
      }
    );
  },
  _addShare: function () {
    if (this.data.selfid) {
      var t = new Date(),
        a =
          "_" + t.getFullYear() + "_" + (t.getMonth() + 1) + "_" + t.getDate();
      wx.cloud.callFunction({
        name: "share",
        data: {
          fun: "addShare",
          type: "index",
          mainid: this.data.crtType + a,
          isDebug: s.globalData.isDebug,
          version: s.globalData.frontVersion,
        },
        success: function (t) {
          (0, e.mylog)("addShare, res: ", t);
        },
        fail: function (t) {
          (0, e.mylog)("addShare, err: ", t);
        },
      });
    }
  },
});
