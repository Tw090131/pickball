var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../4528E4C36B9DF5DF234E8CC44FF455F2.js"),
  r = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = getApp(),
  o = require("../../../3F754DC46B9DF5DF591325C3CB1555F2.js");
Component({
  behaviors: [o],
  properties: {
    raceLoaded: { type: Boolean, value: "" },
    raceList: { type: Array, value: [] },
    selfid: { type: String, value: "" },
    triggered: { type: Boolean, value: !1 },
    allnum: { type: Number, value: 0 },
  },
  data: {
    navInfo: (0, e.getNavInfo)(),
    raceConfig: (0, a.getMultiConfig)(),
    isDebug: t.globalData.isDebug,
  },
  methods: {
    onRace: function (a) {
      (0, e.navTo)({
        url:
          "/packageC/pages/multiRace/multiRace?raceid=" +
          a.currentTarget.dataset.race._id,
      });
    },
    onLongpress: function (e) {
      this.onRace(e);
    },
    onMoreRace: function () {
      (0, e.navTo)({ url: "/packageA/pages/mine/myRace/myRace" });
    },
    onRefresh: function () {
      this.triggerEvent("refresh", {}, {});
    },
    onCreateRace: function (a) {
      (0, r.mylog)("onCreateRace, e: ", a);
      var t = a.currentTarget.dataset.mode,
        o = a.currentTarget.dataset.type;
      (0, e.navTo)({
        url:
          "/packageC/pages/multiRace/multiRace?from=creater&raceMode=" +
          t +
          "&type=" +
          o,
      });
    },
    onUpgrade: function () {
      (0, e.navTo)({ url: "/packageA/pages/upgrade/upgrade" });
    },
    onNewRace: function () {
      (0, e.navTo)({
        url: "/pages/index/creater/racePre?type=doubles&mode=promote",
      });
    },
    onNewRace_2: function () {
      (0, e.navTo)({
        url: "/pages/index/creater/racePre?type=doubles&mode=freeRound",
      });
    },
  },
});
