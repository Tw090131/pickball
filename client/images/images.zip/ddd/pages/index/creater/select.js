var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  i = require("../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [i],
  properties: {
    clubid: { type: String, value: "" },
    clubSelf: { type: Object, value: "" },
    from: { type: String, value: "creater" },
  },
  data: {},
  methods: {
    onActivity: function () {
      (0, e.navTo)({
        url:
          "/pages/activity/activity?from=" +
          this.data.from +
          "&clubid=" +
          this.data.clubid,
      }),
        this._closeSelf();
    },
    onMultiRace: function () {
      (0, e.navTo)({
        url:
          "/pages/index/creater/racePre?from=" +
          this.data.from +
          "&clubid=" +
          this.data.clubid,
      }),
        this._closeSelf();
    },
    onClubMain: function () {
      (0, t.toCreateClub)(), this._closeSelf();
    },
    _closeSelf: function () {
      var e = this,
        t = setTimeout(function () {
          e.closeAnimate(), clearTimeout(t);
        }, 150);
    },
    onClubManager: function () {
      (0, e.navTo)({
        url:
          "/packageD/pages/club/main/manage/manage?clubid=" +
          this.data.clubid +
          "&selfRole=" +
          this.data.clubSelf.memRole,
      });
    },
  },
});
