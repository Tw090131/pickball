var e = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../3F754DC46B9DF5DF591325C3CB1555F2.js"),
  o = require("../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js");
Page({
  behaviors: [a, o],
  data: {
    navInfo: (0, t.getNavInfo)(),
    clubid: "",
    from: "",
    crtType: "doubles",
    crtTypeIdx: 0,
    switchList: [
      { type: "doubles", text: "双打" },
      { type: "singles", text: "单打" },
      { type: "match", text: "对抗", showNew: !0, newSpace: "2rpx" },
      { type: "teams", text: "团体" },
    ],
    crtMode: "",
  },
  onLoad: function (t) {
    var a = this;
    if (
      ((0, e.mylog)("比赛类型选择页onLoad, options: ", t),
      t.from &&
        "clubCreate" === t.from &&
        this.setData({ clubid: t.clubid, from: t.from }),
      t.type && "doubles" != t.type)
    )
      var o = setTimeout(function () {
        a.setData({ crtType: t.type, crtTypeIdx: a._getTypeIndex(t.type) }),
          clearTimeout(o);
      }, 1200);
    var r = 2500;
    if ((t.type && "doubles" === t.type && (r = 1200), t.mode))
      var c = setTimeout(function () {
        a.setData({ crtMode: t.mode }), clearTimeout(c);
      }, r);
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {},
  onCreateRace: function (t) {
    (0, e.mylog)("onCreateRace, e: ", t);
    var a = t.currentTarget.dataset.mode,
      o = t.currentTarget.dataset.type;
    "clubCreate" === this.data.from
      ? wx.redirectTo({
          url:
            "/packageC/pages/multiRace/multiRace?from=clubCreate&raceMode=" +
            a +
            "&clubid=" +
            this.data.clubid +
            "&type=" +
            o,
        })
      : wx.redirectTo({
          url:
            "/packageC/pages/multiRace/multiRace?from=creater&raceMode=" +
            a +
            "&type=" +
            o,
        });
  },
});
