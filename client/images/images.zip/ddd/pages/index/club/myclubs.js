var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  n = require("../../../3F754DC46B9DF5DF591325C3CB1555F2.js");
Component({
  behaviors: [n],
  properties: {
    myclubs: { type: Object, value: null },
    selfid: { type: String, value: "" },
    triggered: { type: Boolean, value: !1 },
    isloading: { type: Boolean, value: !0 },
    myclubLoaded: { type: Boolean, value: "" },
  },
  data: { navInfo: (0, e.getNavInfo)() },
  methods: {
    onCreateClub: function () {
      (0, t.toCreateClub)();
    },
    onClub: function (t) {
      var n = t.currentTarget.dataset.club;
      (0, e.navTo)({
        url:
          "/packageD/pages/club/club?clubid=" +
          n._id +
          "&name=" +
          (n._nameSimple[0] ? n._nameSimple[0] : n._name[0]),
      });
    },
    onRefresh: function () {
      this.triggerEvent("refresh", {}, {});
    },
    onLower: function () {
      this.triggerEvent("lower", {}, {});
    },
  },
});
