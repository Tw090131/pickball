var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = (getApp(), require("../../../../051A88476B9DF5DF637CE0402F9455F2.js")),
  n = require("../../../../12CAB7436B9DF5DF74ACDF443EC455F2.js"),
  i = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  o = require("../../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js");
Page({
  behaviors: [t, n, i, o],
  data: {
    navInfo: (0, e.getNavInfo)(),
    listType: "mySelf",
    pageType: "retreat",
  },
  onLoad: function (e) {
    this._dealOptions(e);
  },
  onReady: function () {},
  onShow: function () {
    this.data.activity || this._getActivity(),
      (!this.data.players || this.data.players.length <= 0) &&
        this._getActivityPlayers();
  },
  onHide: function () {},
  onUnload: function () {},
  onModifyOther: function (e) {
    var t = e.currentTarget.dataset.role;
    this.selectComponent("#signOther").set({
      gender: t._otherInfos.gender,
      nickname: t._otherInfos.nickName,
      level: t._otherInfos.level,
      levelvice: t._otherInfos.levelvice,
      activityPlayerid: t._id,
    }),
      this.selectComponent("#signOther").showPop();
  },
});
