var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  i = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = getApp(),
  a = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [a],
  properties: {
    classify: { type: String, value: "activity" },
    activityid: { type: String, value: "" },
    raceid: { type: String, value: "" },
    title: { type: String, value: "" },
  },
  data: { crtTitle: "" },
  observers: {
    title: function () {
      this.setData({ crtTitle: this.data.title });
    },
  },
  methods: {
    onTitleInput: function (t) {
      this.setData({ crtTitle: t.detail.value });
    },
    onTitleModify: function () {
      "activity" === this.data.classify
        ? this._dealModify()
        : this._dealModifyRace();
    },
    _dealModify: function () {
      var a = this;
      wx.showLoading({ title: "修改中", mask: !0 });
      var o = this.data.crtTitle;
      o || (o = o.trim()),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifyTitle",
            activityid: this.data.activityid,
            title: o,
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (t) {
            (0, i.mylog)("modifyTitle, res: ", t),
              "fail" === t.result.type
                ? (wx.showModal({
                    content: t.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }),
                  wx.hideLoading({ success: function (t) {} }))
                : (a.triggerEvent("refresh", {}, {}), a.closeAnimate());
          },
          fail: function (e) {
            (0, i.mylog)("modifyTitle, err: ", e),
              (0, t.networkFail)(!1, e, "activity.modifyTitle");
          },
        });
    },
    _dealModifyRace: function () {
      var a = this;
      wx.showLoading({ title: "修改中", mask: !0 });
      var o = this.data.crtTitle;
      o || (o = o.trim()),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "modifyTitle",
            raceid: this.data.raceid,
            title: o,
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (t) {
            (0, i.mylog)("modifyTitle, res: ", t),
              "fail" === t.result.type
                ? (wx.showModal({
                    content: t.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }),
                  wx.hideLoading({ success: function (t) {} }))
                : (a.triggerEvent("refreshRace", {}, {}), a.closeAnimate());
          },
          fail: function (e) {
            (0, i.mylog)("modifyTitle, err: ", e),
              (0, t.networkFail)(!1, e, "multiRace.modifyTitle");
          },
        });
    },
    onTitleRecover: function () {
      this.setData({ crtTitle: this.data.title });
    },
    onTitleClear: function () {
      this.setData({ crtTitle: "" });
    },
  },
});
