var a = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = getApp(),
  i = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [i],
  properties: {
    classify: { type: String, value: "activity" },
    activityid: { type: String, value: "" },
    raceid: { type: String, value: "" },
    remarks: { type: String, value: "" },
  },
  data: { crtRemark: "" },
  observers: {
    remarks: function () {
      this.setData({ crtRemark: this.data.remarks });
    },
  },
  methods: {
    onRemarkInput: function (a) {
      this.setData({ crtRemark: a.detail.value });
    },
    onRemarkModify: function () {
      "activity" === this.data.classify
        ? this._dealModify()
        : this._dealModifyRace();
    },
    _dealModify: function () {
      var i = this;
      wx.showLoading({ title: "修改中", mask: !0 });
      var r = this.data.crtRemark;
      r || (r = r.trim()),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifyRemark",
            activityid: this.data.activityid,
            remarks: r,
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (a) {
            (0, t.mylog)("modifyRemark, res: ", a),
              "fail" === a.result.type
                ? (wx.showModal({
                    content: a.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }),
                  wx.hideLoading({ success: function (a) {} }))
                : (i.triggerEvent("refresh", {}, {}), i.closeAnimate());
          },
          fail: function (e) {
            (0, t.mylog)("modifyRemark, err: ", e),
              (0, a.networkFail)(!1, e, "activity.modifyRemark");
          },
        });
    },
    _dealModifyRace: function () {
      var i = this;
      wx.showLoading({ title: "修改中", mask: !0 });
      var r = this.data.crtRemark;
      r || (r = r.trim()),
        wx.cloud.callFunction({
          name: "multiRace",
          data: {
            fun: "modifyRemark",
            raceid: this.data.raceid,
            remarks: r,
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (a) {
            (0, t.mylog)("modifyRemark, res: ", a),
              "fail" === a.result.type
                ? (wx.showModal({
                    content: a.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }),
                  wx.hideLoading({ success: function (a) {} }))
                : (i.triggerEvent("refreshRace", {}, {}), i.closeAnimate());
          },
          fail: function (e) {
            (0, t.mylog)("modifyRemark, err: ", e),
              (0, a.networkFail)(!1, e, "multiRace.modifyRemark");
          },
        });
    },
    onRemarkRecover: function () {
      this.setData({ crtRemark: this.data.remarks });
    },
    onRemarkClear: function () {
      this.setData({ crtRemark: "" });
    },
  },
});
