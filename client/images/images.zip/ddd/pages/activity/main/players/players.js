var t = require("../../../../@babel/runtime/helpers/defineProperty"),
  e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp(),
  n = require("../../../../051A88476B9DF5DF637CE0402F9455F2.js"),
  s = require("../../../../12CAB7436B9DF5DF74ACDF443EC455F2.js"),
  r = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  o = require("../../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js");
Page({
  behaviors: [n, s, r, o],
  data: t(
    t(
      {
        navInfo: (0, e.getNavInfo)(),
        listType: "all",
        pageType: "players",
        crtTimeMil: "",
        hasRemark: !1,
        justSelf: !1,
        genderType: -1,
        longRemark: !1,
        toTop: !1,
        isDebug: i.globalData.isDebug,
      },
      "pageType",
      "players"
    ),
    "isSharing",
    !1
  ),
  interAd: null,
  onLoad: function (t) {
    this._dealOptions(t), this._dealBanShare(), this.createInterAd();
  },
  onReady: function () {},
  onShow: function () {
    this.data.activity || this._getActivity(),
      (!this.data.players || this.data.players.length <= 0) &&
        this._getActivityPlayers(),
      this.setData({ crtTimeMil: new Date().getTime() });
  },
  onHide: function () {},
  onUnload: function () {
    this.destroyInterAd();
  },
  onShareAppMessage: function () {
    var t = this;
    this.setData({ isSharing: !0 });
    var a = setTimeout(function () {
      t.setData({ isSharing: !1 }), clearTimeout(a);
    }, 2e3);
    this._addShare();
    var i = this.data.activity._infos.date,
      n =
        i.month +
        "月" +
        i.day +
        "日(" +
        (0, e.getWeek)(i.weekDay) +
        ")活动名单";
    return (
      this.data.activity._infos.title && (n = this.data.activity._infos.title),
      {
        title: n,
        path: "pages/activity/activity?activityid=" + this.data.activityid,
      }
    );
  },
  _addShare: function () {
    this.data.activityid &&
      wx.cloud.callFunction({
        name: "share",
        data: {
          fun: "addShare",
          type: "activity",
          mainid: this.data.activityid,
          isDebug: i.globalData.isDebug,
          version: i.globalData.frontVersion,
        },
        success: function (t) {
          (0, a.mylog)("addShare, res: ", t);
        },
        fail: function (t) {
          (0, a.mylog)("addShare, err: ", t);
        },
      });
  },
  onOrderPickerChange: function (t) {
    var e = this.data.orderConfig,
      a = parseInt(t.detail.value);
    this.setData({ crtOrder: e.values[a], toTop: !0 });
  },
  onHasRemark: function () {
    this.data.hasRemark
      ? this.setData({ hasRemark: !1 })
      : this.setData({ hasRemark: !0 }),
      this._countGenders();
  },
  onJustSelf: function () {
    this.data.justSelf
      ? this.setData({ justSelf: !1 })
      : this.setData({ justSelf: !0 }),
      this._countGenders();
  },
  onLongRemark: function () {
    this.data.longRemark
      ? this.setData({ longRemark: !1 })
      : this.setData({ longRemark: !0 }),
      this._countGenders();
  },
  onGenderMan: function () {
    this.setData({ genderType: 1 });
  },
  onGenderWoman: function () {
    this.setData({ genderType: 2 });
  },
  onGenderUnknow: function () {
    this.setData({ genderType: 0 });
  },
  onGenderRestore: function () {
    this.setData({ genderType: -1 });
  },
  onReturnAll: function () {
    this.setData({
      hasRemark: !1,
      justSelf: !1,
      genderType: -1,
      longRemark: !1,
    }),
      this._countGenders();
  },
  _countGenders: function () {
    for (
      var t = this.data.signed,
        e = 0,
        a = 0,
        i = 0,
        n = this.data.hasRemark,
        s = this.data.justSelf,
        r = this.data.selfid,
        o = 0;
      o < t.length;
      o++
    ) {
      var d = t[o];
      ((!n && !s) ||
        (n && !s && d._postscript) ||
        (!n && s && r === d._playerid) ||
        (n && s && d._postscript && r === d._playerid)) &&
        (1 === d.gender ? e++ : 2 === d.gender ? a++ : i++);
    }
    this.setData({ manCnt: e, womanCnt: a, nogender: i });
  },
  onManager: function () {
    wx.redirectTo({ url: "/pages/activity/main/manager/manager?from=players" });
  },
  onManagerAlternate: function () {
    (0, e.navTo)({
      url: "/pages/activity/main/manager/manager?from=players&type=alternate",
    });
  },
  onNavBack: function () {
    (0, a.mylog)("+++ onNavBack +++"),
      this.data.activity && this.data.activity.showInterAd
        ? this.showInterAd()
        : (0, e.dealBack)();
  },
  createInterAd: function () {
    var t = this,
      i = new Date().getTime(),
      n = this.data.selfInfo;
    if (!(n && n.trustLevel >= 4 && n.trustDueMil > i)) {
      var s = this.data.activity;
      (s && s._creatorid === this.data.selfid) ||
        (s &&
          s.showInterAd &&
          wx.createInterstitialAd &&
          !this.interAd &&
          ((this.interAd = wx.createInterstitialAd({
            adUnitId: "adunit-de95f4cc1bc3e4d4",
          })),
          this.interAd.onLoad(function () {
            (0, a.mylog)("interAd, 加载成功: ", t.interAd);
          }),
          this.interAd.onError(function (t) {
            (0, a.mylog)("interAd, err: ", t);
          }),
          this.interAd.onClose(function () {
            (0, a.mylog)("interAd, 点击关闭"),
              (0, e.dealBack)(),
              (0, e.cloudLog)({
                _classA: "ad",
                _classB: "interAd",
                _content: "close",
              });
          })));
    }
  },
  showInterAd: function () {
    this.interAd
      ? (wx.showLoading(),
        this.interAd
          .show()
          .then(function () {
            (0, a.mylog)("interAd，show"),
              wx.hideLoading(),
              (0, e.cloudLog)({
                _classA: "ad",
                _classB: "interAd",
                _content: "show ok",
              });
          })
          .catch(function (t) {
            (0, a.mylog)("interAd，show err: ", t),
              wx.hideLoading(),
              (0, e.dealBack)();
          }))
      : (0, e.dealBack)();
  },
  destroyInterAd: function () {
    this.interAd && this.interAd.destroy();
  },
});
