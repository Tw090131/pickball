var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  i = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = require("../../../6877D2976B9DF5DF0E11BA9039A155F2.js"),
  n = require("../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  o = require("../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js"),
  s = getApp();
Component({
  behaviors: [a, n, o],
  properties: {
    activity: { type: Object, value: "" },
    isPlayer: { type: Boolean, value: !1 },
    isSignOther: { type: Boolean, value: !1 },
    configs: { type: Object, value: "" },
    selfid: { type: String, value: "" },
    selfInfo: { type: Object, value: "" },
    triggered: { type: Boolean, value: !1 },
    referer: { type: String, value: "" },
    isSharing: { type: Boolean, value: !1 },
  },
  data: {
    navInfo: (0, e.getNavInfo)(),
    crtTimeMil: new Date().getTime(),
    isLogining: !1,
    crtType: "main",
    crtTypeIdx: 0,
    switchList: [
      { type: "main", text: "主活动" },
      { type: "subrace", text: "子比赛" },
      { type: "totalrank", text: "总排名" },
    ],
    selectGroupNo: "",
  },
  observers: {
    activity: function () {
      this._getActivityPlayers(),
        this.setData({ crtTimeMil: this.data.activity.crtMil }),
        (0, i.mylog)("activity main observers selfInfo: ", this.data.selfInfo);
    },
  },
  lifetimes: {
    attached: function () {
      var e = getCurrentPages().length;
      this.setData({ pagesCnt: e });
    },
  },
  methods: {
    showGroupsControlPop: function () {
      this.selectComponent("#groupsControl").setShow();
    },
    onRefresh: function () {
      this._dealRefresh();
    },
    _dealRefresh: function () {
      this.triggerEvent("refresh", {}, {}), this.setData({ selectGroupNo: "" });
    },
    onCancel: function () {
      var e = this;
      wx.showModal({
        content: "取消活动不可恢复，是否确定取消这次活动？",
        cancelText: "点错了",
        confirmText: "取消活动",
        success: function (t) {
          t.cancel || (t.confirm && e._doCancelConfirm());
        },
      });
    },
    _doCancelConfirm: function () {
      var e = this;
      wx.showModal({
        content: "为了防止误操作，请再次确认（操作顺序已变化哦）",
        cancelText: "取消活动",
        confirmText: "点错了",
        success: function (t) {
          t.cancel ? e._dealCancel() : t.confirm;
        },
      });
    },
    _dealCancel: function () {
      var t = this;
      wx.showLoading({ title: "取消中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "cancel",
            activityid: this.data.activity._id,
            isDebug: s.globalData.isDebug,
            version: s.globalData.frontVersion,
          },
          success: function (e) {
            (0, i.mylog)("cancel, res: ", e),
              t.triggerEvent("refresh", {}, {}),
              "fail" === e.result.type
                ? (wx.hideLoading(),
                  wx.showModal({
                    content: e.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }))
                : (e.result.detail && e.result.detail.total) ||
                  (e.result.clubfee && e.result.clubfee.total)
                ? t._refundBatch()
                : wx.hideLoading();
          },
          fail: function (t) {
            s.globalData.isConsoleLog && console.log("cancel err: ", t),
              (0, e.networkFail)(!1, t, "activity.cancel"),
              wx.hideLoading();
          },
        });
    },
    _refundBatch: function () {
      wx.showLoading({ title: "退款中", mask: !0 }),
        wx.cloud.callFunction({
          name: "tradeActivity",
          data: {
            fun: "refundBatch",
            activityid: this.data.activity._id,
            isDebug: s.globalData.isDebug,
            version: s.globalData.frontVersion,
          },
          success: function (e) {
            (0, i.mylog)("refundBatch, res: ", e),
              "fail" === e.result.type
                ? wx.showModal({
                    content: e.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  })
                : wx.showToast({ title: "退款完成", duration: 1200 });
          },
          fail: function (t) {
            (0, i.mylog)("refundBatch, err: ", t),
              (0, e.networkFail)(!1, t, "multiRace.refundBatch");
          },
          complete: function (e) {
            var t = setTimeout(function () {
              wx.hideLoading({ success: function (e) {} }), clearTimeout(t);
            }, 1300);
          },
        });
    },
    onRetreat: function () {
      this.data.isSignOther
        ? (0, e.navTo)({
            url: "/pages/activity/main/retreat/retreat?from=main",
          })
        : this.data.activity.selfPlayer &&
          (this.selectComponent("#retreat").setActPlayer(
            this.data.activity.selfPlayer
          ),
          this.selectComponent("#retreat").showPop());
    },
    onRefreshByRetreat: function () {
      this._dealRefresh();
    },
    onRefreshBySignother: function () {
      this._dealRefresh();
    },
    onModify: function () {
      this.triggerEvent("modify", {}, {});
    },
    onEnlist: function () {
      this.data.activity._isSuspend
        ? wx.showModal({
            content: "来晚一点点，报名已经截止了哦",
            showCancel: !1,
            confirmText: "好的",
          })
        : this._doEnlist();
    },
    _doEnlist: function () {
      var t = this;
      "alone" != this.data.activity._infos.clubid &&
      this.data.activity.me.status.length > 0 &&
      "sealed" === this.data.activity.me.status[0]
        ? wx.showModal({
            content: "您已被拉黑，请联系俱乐部会长解除拉黑后再报名",
            showCancel: !1,
            confirmText: "好的",
          })
        : "alone" != this.data.activity._infos.clubid &&
          "clubMember" === this.data.activity._infos.rangeType
        ? (s.globalData.isConsoleLog &&
            console.log("onEnlist me: ", this.data.activity.me),
          this.data.activity.me.status.length <= 0 ||
          "normal" != this.data.activity.me.status[0]
            ? wx.showModal({
                content:
                  "本次活动仅限【" +
                  this.data.activity.club._name[0] +
                  "】会员报名",
                cancelText: "好的",
                confirmText: "成为会员",
                success: function (i) {
                  i.confirm &&
                    (0, e.navTo)({
                      url:
                        "/packageD/pages/club/club?type=main&clubid=" +
                        t.data.activity._infos.clubid,
                    });
                },
              })
            : this._dealEnlist())
        : this._dealEnlist();
    },
    _dealEnlist: function () {
      var e = this;
      this.data.activity._nos.length - 1 >= this.data.activity._infos.figures
        ? this._toJoin()
        : new Date().getTime() >=
          this.data.activity._startTimeMil -
            3600 * this.data.activity._infos.retreatTime * 1e3
        ? wx.showModal({
            content: "现在报名不可退坑，是否报名？",
            cancelText: "暂不",
            confirmText: "报名",
            success: function (t) {
              t.cancel || (t.confirm && e._toJoin());
            },
          })
        : this._toJoin();
    },
    doContinueFromLogin: function () {
      this._toJoin();
    },
    _toJoin: function () {
      s.globalData.selfInfo
        ? this._dealJudgeRealname()
        : (0, e.navTo)({ url: "/pages/login/login?action=returnext" });
    },
    _dealJudgeRealname: function () {
      wx.hideLoading({ success: function (e) {} });
      var t = this.data.activity._infos,
        a = s.globalData.selfInfo.realName;
      (0, i.mylog)(
        "_dealJudgeRealname, isRealname: ",
        t.isRealname,
        "realName: ",
        a
      ),
        !a && t.isRealname
          ? wx.showModal({
              content: "本次活动组织者要求填写真实姓名，请完善真实姓名",
              cancelText: "暂不",
              confirmText: "去完善",
              success: function (t) {
                t.cancel ||
                  (t.confirm &&
                    (0, e.navTo)({
                      url: "/packageA/pages/mine/setting/setting?action=realname",
                    }));
              },
            })
          : this._dealJudgePhone();
    },
    _dealJudgePhone: function () {
      wx.hideLoading({ success: function (e) {} });
      var t = this.data.activity._infos;
      !s.globalData.selfInfo.phone && t.needPhone
        ? wx.showModal({
            content: "本次活动组织者要求填写手机号，请完善手机号",
            cancelText: "暂不",
            confirmText: "去完善",
            success: function (t) {
              t.cancel ||
                (t.confirm &&
                  (0, e.navTo)({
                    url: "/packageA/pages/mine/setting/setting?action=phone",
                  }));
            },
          })
        : this._dealJudgeLevel();
    },
    _dealJudgeLevel: function () {
      var t = this.data.activity._infos,
        a = s.globalData.selfInfo.gender;
      if (
        ((0, i.mylog)("_dealJudgeLevel, selfInfo: ", s.globalData.selfInfo),
        (0, i.mylog)("_dealJudgeLevel, infos: ", t),
        t.manLevel && t.womanLevel)
      )
        if (t.manLevel.islimit || t.womanLevel.islimit)
          if (0 !== a && a)
            if (
              (1 === a && t.manLevel.islimit) ||
              (2 === a && t.womanLevel.islimit)
            ) {
              var n = -1;
              if (
                this.data.activity.me &&
                this.data.activity.me.infos &&
                this.data.activity.me.infos.level &&
                this.data.activity.me.infos.level.length > 0 &&
                this.data.activity.me.infos.levelvice &&
                this.data.activity.me.infos.levelvice.length > 0
              ) {
                var o = this.data.activity.me.infos;
                n = (0, e.calcLevel)(o.level[0], o.levelvice[0]);
              }
              var c = -1;
              if (s.globalData.selfInfo.infos) {
                var l = s.globalData.selfInfo.infos;
                c = (0, e.calcLevel)(l.level, l.levelvice);
              }
              (0, i.mylog)("levelAtClub: ", n),
                (0, i.mylog)("assessLevel: ", c),
                t.clubid &&
                "alone" != t.clubid &&
                n <= -1 &&
                ((1 === a && t.manLevel.justCertified) ||
                  (2 === a && t.womanLevel.justCertified))
                  ? this._judgeLevelJustCertified(a)
                  : n <= -1 && c <= -1
                  ? this._judgeLevelNolevel(a)
                  : 1 === a
                  ? this._judgeLevelRange(n, c, t.manLevel, a)
                  : this._judgeLevelRange(n, c, t.womanLevel, a);
            } else this._dealJoin();
          else this._judgeLevelNogender();
        else this._dealJoin();
      else this._dealJoin();
    },
    _judgeLevelNogender: function () {
      wx.hideLoading(),
        wx.showModal({
          content: "本次活动对男女等级有要求，请完善性别、自评羽毛球等级",
          cancelText: "暂不",
          confirmText: "去完善",
          success: function (t) {
            t.cancel ||
              (t.confirm &&
                (0, e.navTo)({ url: "/packageA/pages/mine/setting/setting" }));
          },
        });
    },
    _judgeLevelJustCertified: function (t) {
      var i = this;
      wx.hideLoading();
      var a =
        "本次活动要求" +
        (1 === t ? "男" : "女") +
        "认证等级，请先在俱乐部认证等级哦";
      this.data.activity.me &&
        this.data.activity.me.status &&
        (this.data.activity.me.status.length <= 0 ||
          "normal" != this.data.activity.me.status[0]) &&
        (a =
          "本次活动要求" +
          (1 === t ? "男" : "女") +
          "认证等级，请先加入俱乐部并获得认证等级哦"),
        wx.showModal({
          content: a,
          cancelText: "好的",
          confirmText: "去俱乐部",
          success: function (t) {
            t.confirm &&
              (0, e.navTo)({
                url:
                  "/packageD/pages/club/club?type=me&clubid=" +
                  i.data.activity.club._id[0],
              });
          },
        });
    },
    _judgeLevelNolevel: function (t) {
      wx.hideLoading(),
        wx.showModal({
          content:
            "本次活动对" +
            (1 === t ? "男" : "女") +
            "等级有要求，请自评羽毛球等级",
          cancelText: "暂不",
          confirmText: "去自评",
          success: function (t) {
            t.cancel ||
              (t.confirm &&
                (0, e.navTo)({
                  url: "/packageA/pages/mine/setting/setting?action=assess",
                }));
          },
        });
    },
    _judgeLevelRange: function (t, i, a, n) {
      var o = this;
      t >= 0
        ? t < a.min || t > a.max
          ? (wx.hideLoading(),
            wx.showModal({
              content:
                "本次活动要求" +
                (1 === n ? "男" : "女") +
                (0, e.getLevelText)(a.min, a.max) +
                "，您的认证等级不符合要求，无法报名哦",
              cancelText: "好的",
              confirmText: "去俱乐部",
              success: function (t) {
                t.cancel ||
                  (t.confirm &&
                    (0, e.navTo)({
                      url:
                        "/packageD/pages/club/club?type=me&clubid=" +
                        o.data.activity.club._id[0],
                    }));
              },
            }))
          : this._dealJoin()
        : i >= 0 && (i < a.min || i > a.max)
        ? (wx.hideLoading({ success: function (e) {} }),
          wx.showModal({
            content:
              "本次活动要求" +
              (1 === n ? "男" : "女") +
              (0, e.getLevelText)(a.min, a.max) +
              "，您无法报名哦",
            cancelText: "好的",
            confirmText: "去自评",
            success: function (t) {
              t.cancel ||
                (t.confirm &&
                  (0, e.navTo)({
                    url: "/packageA/pages/mine/setting/setting?action=assess",
                  }));
            },
          }))
        : this._dealJoin();
    },
    _dealJoin: function () {
      var e = this.data.activity,
        t = this.data.activity._infos;
      t.groupCanPlayer && e._nos.length - 1 < t.figures
        ? this.selectComponent("#groupSelect").showPop()
        : this._dealJoinSec();
    },
    onGroupSelected: function (e) {
      var t = "";
      this.data.activity._infos.groupCanPlayer && (t = e.detail.groupNo),
        (0, i.mylog)("onGroupSelected, e: ", e, "groupNo: ", t),
        this.setData({ selectGroupNo: t }),
        this._dealJoinSec();
    },
    _dealJoinSec: function () {
      var t = this.data.activity._infos,
        a = s.globalData.selfInfo.gender;
      (0, i.mylog)("_dealJoin, feeMode: ", t.feeMode),
        "charge" === t.feeMode ||
        "moreless" === t.feeMode ||
        "before" === t.feeMode
          ? t.feeMan == t.feeWoman || a
            ? "moreless" === t.feeMode
              ? this._dealJoinCharge()
              : this._dealJoinPay()
            : (wx.hideLoading({ success: function (e) {} }),
              wx.showModal({
                content: "本次活动男女收费不同，请完善性别后再报名",
                cancelText: "暂不",
                confirmText: "去完善",
                success: function (t) {
                  t.cancel ||
                    (0, e.navTo)({
                      url: "/packageA/pages/mine/setting/setting?action=namegender",
                    });
                },
              }))
          : this._dealJoinComm();
    },
    _dealJoinPay: function () {
      var e = this.data.activity;
      if (
        e &&
        e.club &&
        e.club._creatorid &&
        e.club._creatorid.length > 0 &&
        e.me &&
        e.me.status &&
        e.me.status.length > 0 &&
        "normal" === e.me.status[0]
      ) {
        var t = e.club;
        t._vipfee &&
        t._vipfee.length > 0 &&
        t._vipfee[0].opened &&
        e.me &&
        e.me.memfee &&
        e.me.memfee.length > 0 &&
        e.me.memfee[0] > 0
          ? t._vipfee[0].vipPriceUsing &&
            e.me.role.length > 0 &&
            ("president" === e.me.role[0] ||
              "manager" === e.me.role[0] ||
              "vip" === e.me.role[0])
            ? this._dealVip()
            : this._dealNotVip()
          : this._dealJoinCharge();
      } else this._dealJoinCharge();
    },
    _dealVip: function () {
      var t = this.data.activity._infos,
        i = s.globalData.selfInfo.gender;
      if (t.feeManVip || t.feeWomanVip)
        if (t.feeManVip == t.feeWomanVip || i) {
          var a = this.data.activity.me;
          t.feeManVip === t.feeWomanVip
            ? this._dealClubfeePay(a.memfee, t.feeManVip, "vip")
            : 2 === i
            ? t.feeWomanVip
              ? this._dealClubfeePay(a.memfee, t.feeWomanVip, "vip")
              : this._dealNotVip()
            : t.feeManVip
            ? this._dealClubfeePay(a.memfee, t.feeManVip, "vip")
            : this._dealNotVip();
        } else
          wx.hideLoading({ success: function (e) {} }),
            wx.showModal({
              content: "本次活动男女VIP收费不同，请完善性别后再报名",
              cancelText: "暂不",
              confirmText: "去完善",
              success: function (t) {
                t.cancel ||
                  (0, e.navTo)({
                    url: "/packageA/pages/mine/setting/setting?action=namegender",
                  });
              },
            });
      else this._dealNotVip();
    },
    _dealClubfeePay: function (e, t, i) {
      e >= 100 * t ? this._clubfeePay(i, t) : this._dealFeeNotEnough();
    },
    _dealFeeNotEnough: function () {
      var t = this;
      "before" === this.data.activity._infos.feeMode
        ? wx.showModal({
            content: "您在该俱乐部的会费余额已不足",
            cancelText: "直接报名",
            confirmText: "去充值",
            success: function (i) {
              i.cancel
                ? t._dealJoinComm()
                : i.confirm &&
                  (0, e.navTo)({
                    url:
                      "/packageD/pages/club/club?clubid=" +
                      t.data.activity._infos.clubid +
                      "&type=me",
                  });
            },
          })
        : wx.showModal({
            content: "您在该俱乐部的会费余额已不足",
            cancelText: "直接付款",
            confirmText: "去充值",
            success: function (i) {
              i.cancel
                ? t._dealJoinCharge()
                : i.confirm &&
                  (0, e.navTo)({
                    url:
                      "/packageD/pages/club/club?clubid=" +
                      t.data.activity._infos.clubid +
                      "&type=me",
                  });
            },
          });
    },
    _dealNotVip: function () {
      var e = this.data.activity._infos,
        t = s.globalData.selfInfo.gender,
        i = this.data.activity.me,
        a = e.feeMan;
      2 === t && (a = e.feeWoman), this._dealClubfeePay(i.memfee, a, "normal");
    },
    _clubfeePay: function (e, t) {
      (0, i.mylog)("_clubfeePay, memRole: ", e);
      var a = this.selectComponent("#clubfeePay");
      a.setPayforActivity({
        clubid: this.data.activity._infos.clubid,
        type: "activity",
        subtype: "self",
        costKind: e,
        costFee: t,
        activityid: this.data.activity._id,
        selectGroupNo: this.data.selectGroupNo,
      }),
        a.showPop();
    },
    _dealJoinCharge: function () {
      var e = this.data.activity._infos;
      if ("before" === e.feeMode) this._dealJoinComm();
      else {
        var t = s.globalData.selfInfo.gender,
          i = e.feeMan;
        2 === t && (i = e.feeWoman);
        var a = this.selectComponent("#payPop");
        a.setPayforActivity({
          type: "activity",
          subtype: "self",
          fee: i,
          activityid: this.data.activity._id,
          selectGroupNo: this.data.selectGroupNo,
        }),
          a.showPop();
      }
    },
    onPaySuccess: function (e) {
      this._dealJoinComm(e.detail.tradeDetailid);
    },
    _dealJoinComm: function (t) {
      var a = this;
      this.data.activity._nos.length - 1 < this.data.activity._infos.figures
        ? wx.showLoading({ title: "报名中", mask: !0 })
        : wx.showLoading({ title: "候补中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "join_2",
            activityid: this.data.activity._id,
            selectGroupNo: this.data.selectGroupNo,
            tradeDetailid: t,
            checkUnreceived: !0,
            isDebug: s.globalData.isDebug,
            version: s.globalData.frontVersion,
          },
          success: function (n) {
            if (((0, i.mylog)("join_2: ", n), "fail" === n.result.type))
              if (
                (wx.hideLoading(),
                a.triggerEvent("refresh", {}, {}),
                n.result.listUnrceived)
              ) {
                var o = "请先完成未付款账单，否则不能报名该";
                "alone" != a.data.activity._infos.clubid
                  ? (o += "俱乐部")
                  : (o += "组织者"),
                  (o += "的新活动哦"),
                  t && (o += "（已退款，请注意查收）"),
                  wx.showModal({
                    content: o,
                    showCancel: !1,
                    confirmText: "账单详情",
                    complete: function (t) {
                      if (t.confirm) {
                        var i = a.data.activity._creatorid,
                          n = a.data.activity._infos.clubid;
                        (0, e.navTo)({
                          url:
                            "/packageA/pages/mine/myBill/unReceived?creatorid=" +
                            i +
                            "&clubid=" +
                            n,
                        });
                      }
                    },
                  });
              } else {
                var s = n.result.msg;
                t && (s += "（已退款，请注意查收）"),
                  wx.showModal({
                    content: s,
                    showCancel: !1,
                    confirmText: "好的",
                  });
              }
            else a._signSelfSuccess(n.result.activityPlayerid);
          },
          fail: function (t) {
            (0, i.mylog)("join_2 err: ", t),
              (0, e.networkFail)(!1, t, "activity.join_2");
          },
          complete: function (e) {
            a.setData({ selectGroupNo: "" });
          },
        });
    },
    _signSelfSuccess: function (e) {
      wx.hideLoading({ success: function (e) {} }),
        this.data.activity._nos.length - 1 < this.data.activity._infos.figures
          ? this.selectComponent("#postscript").setMode("signup")
          : this.selectComponent("#postscript").setMode("alternate"),
        this.selectComponent("#postscript").setKind("self"),
        this.selectComponent("#postscript").setPlayerGender(
          s.globalData.selfInfo.gender
        ),
        this.selectComponent("#postscript").setActivityPlayerid(e),
        this.selectComponent("#postscript").setSelfAnonymous(),
        this.selectComponent("#postscript").showPop(),
        this.triggerEvent("refresh", {}, {});
    },
    onClubfeePayJoined: function (e) {
      this._signSelfSuccess(e.detail.activityPlayerid);
    },
    onSignOther: function () {
      if (this.data.activity._isSuspend)
        wx.showModal({
          content: "来晚一点点，报名已经截止了哦",
          showCancel: !1,
          confirmText: "好的",
        });
      else if ("onlySelf" === this.data.activity._infos.signOther)
        wx.showModal({
          content: "本次活动只能本人报名哦",
          showCancel: !1,
          confirmText: "好的",
        });
      else {
        var e = this.data.activity;
        if (e._infos.hasOwnProperty("signOtherLimit")) {
          var t = e._infos.signOtherLimit;
          t && e.selfSignTotal - 1 >= t
            ? wx.showModal({
                content: "本次活动您可带" + t + "人，已经满员啦",
                showCancel: !1,
                confirmText: "好的",
              })
            : this._dealSignOther();
        } else this._dealSignOther();
      }
    },
    _dealSignOther: function () {
      var e = this;
      if (this.data.isPlayer) {
        if (
          "alone" != this.data.activity._infos.clubid &&
          this.data.activity.me.status.length > 0 &&
          "sealed" === this.data.activity.me.status[0]
        )
          return void wx.showModal({
            content: "您已被拉黑，请联系俱乐部会长解除拉黑后再报名",
            showCancel: !1,
            confirmText: "好的",
          });
        this.selectComponent("#signOther").showPop();
      } else
        wx.showModal({
          content: "带人之前，请先为自己报名",
          cancelText: "暂不",
          confirmText: "报名",
          success: function (t) {
            t.cancel || (t.confirm && e._doEnlist());
          },
        });
    },
    onHome: function () {
      wx.reLaunch({ url: "/pages/index/index" });
    },
    onLevels: function () {
      (0, e.navTo)({ url: "/packageE/pages/levels/levels" });
    },
    onHelp: function () {
      (0, e.navTo)({ url: "/packageE/pages/guider/guider?type=activity" });
    },
    onAcode: function () {
      this.selectComponent("#acode").getAcode(
        "activity",
        this.data.activity._id
      ),
        this.selectComponent("#acode").showPop();
    },
    onManage: function () {
      (0, e.navTo)({ url: "/pages/activity/main/manager/manager?from=main" });
    },
    onMore: function () {
      var e = this,
        t = this.data.activity,
        i = [
          t._isSuspend ? "恢复可报名" : "报名截止(可恢复)",
          t._subRaceOpened ? "关闭子比赛" : "开启子比赛",
          "导出名单",
          "复制新活动",
        ];
      "before" === t._infos.feeMode &&
        this.data.selfid === t._creatorid &&
        (t._receiptBeforeid ? i.push("活动前对账单") : i.push("活动前收款")),
        wx.showActionSheet({
          itemList: i,
          success: function (i) {
            switch (i.tapIndex) {
              case 0:
                t._isSuspend
                  ? e._dealActivitySuspend(!1)
                  : e._dealActivitySuspend(!0);
                break;
              case 1:
                e._openSubraces();
                break;
              case 2:
                e._dealCopyNamelist();
                break;
              case 3:
                e.selectComponent("#activityEnlist").onCopyActivity();
                break;
              case 4:
                e._dealReceiptBefore();
            }
          },
        });
    },
    _dealCopyNamelist: function () {
      var e = this.selectComponent("#copyMode");
      e && (e.init(), e.showPop());
    },
    _dealActivitySuspend: function (t) {
      var a = this;
      wx.showLoading({ title: "修改中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifySuspend",
            activityid: this.data.activity._id,
            isSuspend: t,
            isDebug: s.globalData.isDebug,
            version: s.globalData.frontVersion,
          },
          success: function (e) {
            (0, i.mylog)("modifySuspend, res: ", e),
              a.triggerEvent("refresh", {}, {});
          },
          fail: function (t) {
            (0, i.mylog)("modifySuspend, err: ", t),
              (0, e.networkFail)(!1, t, "activity.modifySuspend");
          },
        });
    },
    _openSubraces: function () {
      var t = this,
        a = this.data.activity;
      wx.showLoading({
        title: a._subRaceOpened ? "关闭中" : "开启中",
        mask: !0,
      }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifySubRaceOpened",
            activityid: this.data.activity._id,
            opened: !a._subRaceOpened,
            isDebug: s.globalData.isDebug,
            version: s.globalData.frontVersion,
          },
          success: function (e) {
            (0, i.mylog)("modifySubRaceOpened, res: ", e),
              t.triggerEvent("refresh", {}, {}),
              t._toSubRace(a._subRaceOpened);
          },
          fail: function (t) {
            (0, i.mylog)("modifySubRaceOpened, err: ", t),
              (0, e.networkFail)(!1, t, "activity.modifySubRaceOpened");
          },
        });
    },
    _toSubRace: function (e) {
      var t = this;
      if (e) this.setData({ crtType: "main", crtTypeIdx: 0 });
      else
        var i = setTimeout(function () {
          t.setData({ crtType: "subrace", crtTypeIdx: 1 }),
            t.selectComponent("#subRace").getActivitySubRaces(),
            clearTimeout(i);
        }, 1500);
    },
    _dealReceiptBefore: function () {
      var t = this,
        a = this.data.activity;
      a._receiptBeforeid
        ? (0, e.navTo)({
            url:
              "/packageA/pages/receiptBefore/receiptBefore?receiptid=" +
              a._receiptBeforeid,
          })
        : ((0, i.mylog)("players: ", this.data.players),
          (0, i.mylog)("uniPlayers: ", this.data.uniPlayers),
          new Date().getTime() <
          a._startTimeMil - 3600 * a._infos.retreatTime * 1e3
            ? wx.showModal({
                content: "过了退坑期限，发起收款会更好，是否现在发起？",
                cancelText: "暂不",
                confirmText: "发起",
                success: function (e) {
                  e.cancel || (e.confirm && t._todoReceiptBefore());
                },
              })
            : this._todoReceiptBefore());
    },
    _todoReceiptBefore: function () {
      var t = this.data.activity;
      (s.globalData.receiptInfo = {
        crtReceipt: {
          type: "activity",
          mainid: t._id,
          clubid: t._infos.clubid,
          isRealname: t._infos.isRealname,
          feeMode: t._infos.feeMode,
          feeMan: Math.round(100 * t._infos.feeMan),
          feeWoman: Math.round(100 * t._infos.feeWoman),
          creatorid: t._creatorid,
          players: this.data.smart,
        },
      }),
        (0, e.navTo)({
          url: "/packageA/pages/receiptBefore/receiptBefore?action=create&type=activity",
        });
    },
    onEditFigures: function () {
      this.selectComponent("#figuresPop").showPop();
    },
    onReceiptActivity: function () {
      this.data.activity._receiptid
        ? "new" === this.data.activity._receiptType
          ? (0, e.navTo)({
              url:
                "/packageA/pages/receipt_2/receipt_2?receiptid=" +
                this.data.activity._receiptid,
            })
          : (0, e.navTo)({
              url:
                "/packageA/pages/receipt/receipt?receiptid=" +
                this.data.activity._receiptid,
            })
        : ((s.globalData.receiptInfo = {
            crtReceipt: {
              type: "activity",
              mainid: this.data.activity._id,
              clubid: this.data.activity._infos.clubid,
              isRealname: this.data.activity._infos.isRealname,
              feeMode: this.data.activity._infos.feeMode,
              feeMan: Math.round(100 * this.data.activity._infos.feeMan),
              feeWoman: Math.round(100 * this.data.activity._infos.feeWoman),
              creatorid: this.data.activity._creatorid,
              payers: this.data.uniPlayers,
            },
          }),
          (0, e.navTo)({
            url: "/packageA/pages/receipt_2/receipt_2?action=create&type=activity",
          }));
    },
    onSignOtherSuccess: function (e) {
      "signup" === e.detail.mode
        ? this.selectComponent("#postscript").setMode("signup")
        : this.selectComponent("#postscript").setMode("alternate"),
        this.selectComponent("#postscript").setKind("other"),
        this.selectComponent("#postscript").setPlayerGender(e.detail.gender),
        this.selectComponent("#postscript").setActivityPlayerid(
          e.detail.activityPlayerid
        ),
        this.selectComponent("#postscript").setOtherHeadInfo(),
        this.selectComponent("#postscript").showPop();
    },
    onTitleEdit: function () {
      this.selectComponent("#titlePop").showPop();
    },
    onRemarkEdit: function () {
      this.selectComponent("#remarkPop").showPop();
    },
    _dealSwitchType: function () {
      switch (this.data.crtType) {
        case "subrace":
          this.selectComponent("#subRace").getActivitySubRaces();
          break;
        case "totalrank":
          this.selectComponent("#totalRank").getTotalRank();
      }
    },
    onLoading: function (e) {
      this.triggerEvent("loading", { isLoading: e.detail.isLoading }, {});
    },
    onMorelessActivity: function () {
      var e = this;
      wx.showActionSheet({
        itemList: ["多退，批量退款", "少补，快速收款"],
        success: function (t) {
          switch (t.tapIndex) {
            case 0:
              e.onCreditActivity();
              break;
            case 1:
              e.onReceiptActivity();
          }
        },
      });
    },
    onCreditActivity: function () {
      this.data.activity._creditid
        ? (0, e.navTo)({
            url:
              "/packageA/pages/credit/credit?creditid=" +
              this.data.activity._creditid,
          })
        : ((s.globalData.creditInfo = {
            crtCredit: {
              type: "activity",
              mainid: this.data.activity._id,
              clubid: this.data.activity._infos.clubid,
              isRealname: this.data.activity._infos.isRealname,
              feeMode: "credit",
              creatorid: this.data.activity._creatorid,
              payers: this.data.uniPlayers,
              mainMode: "moreless",
              creditMode: "AA",
            },
          }),
          (0, e.navTo)({
            url: "/packageA/pages/credit/credit?action=create&type=activity",
          }));
    },
    onManageBeing: function () {
      var e = this,
        t = this.data.activity;
      wx.showActionSheet({
        itemList: [
          "管理报名",
          t._subRaceOpened ? "关闭子比赛" : "开启子比赛",
          "导出名单",
          "复制新活动",
        ],
        success: function (t) {
          switch (t.tapIndex) {
            case 0:
              e.onManage();
              break;
            case 1:
              e._openSubraces();
              break;
            case 2:
              e._dealCopyNamelist();
              break;
            case 3:
              e._copyActivity();
          }
        },
      });
    },
    onManageEnd: function () {
      var e = this;
      wx.showActionSheet({
        itemList: ["管理报名", "导出名单", "复制新活动"],
        success: function (t) {
          switch (t.tapIndex) {
            case 0:
              e.onManage();
              break;
            case 1:
              e._dealCopyNamelist();
              break;
            case 2:
              e._copyActivity();
          }
        },
      });
    },
    _copyActivity: function () {
      var t = this;
      wx.showModal({
        content: "是否复制发布新的活动？",
        cancelText: "暂不",
        confirmText: "复制",
        complete: function (i) {
          if (i.cancel);
          else if (i.confirm) {
            wx.showLoading({ title: "复制中" });
            var a = setTimeout(function () {
              (s.globalData.activityInfo.copyActivity = t.data.activity),
                wx.hideLoading(),
                (0, e.navTo)({ url: "/pages/activity/activity?from=copy" }),
                clearTimeout(a);
            }, 1e3);
          }
        },
      });
    },
    onBanShareTip: function () {
      wx.showModal({
        content: "本次活动报名，组织者已设置不可分享哦",
        showCancel: !1,
        confirmText: "好的",
      });
    },
    onVisitDetails: function () {
      if (this._checkVipfun("visit")) {
        s.globalData.activityInfo.crtActivity = this.data.activity;
        var t = this.data.activity._infos.clubid;
        (0, e.navTo)({
          url:
            "/packageA/pages/visit/visit?type=activity&mainid=" +
            this.data.activity._id +
            "&clubid=" +
            t,
        });
      }
    },
    onShareDetails: function () {
      if (this._checkVipfun("share")) {
        s.globalData.activityInfo.crtActivity = this.data.activity;
        var t = this.data.activity._infos.clubid;
        (0, e.navTo)({
          url:
            "/packageA/pages/share/share?type=activity&mainid=" +
            this.data.activity._id +
            "&clubid=" +
            t,
        });
      }
    },
    _checkVipfun: function (e) {
      var i = s.globalData.selfInfo,
        a = this.data.activity.crtMil;
      if (i && i.trustLevel >= 4 && i.trustDueMil > a) return !0;
      var n = this.data.activity;
      n.isPlayer = this.data.isPlayer;
      var o = (0, t.raceRole)(this.data.selfid, n);
      s.globalData.payVipfunInfo.payAt = {
        from: "activity",
        actid: this.data.activity._id,
        mode: e,
        role: o,
      };
      var c = this.selectComponent("#payVisit");
      return c && (c.setMode(e), c.setRole(o), c.showPop()), !1;
    },
    onGroups: function () {
      this.selectComponent("#groupsControl").showPop(),
        (s.globalData.activityInfo.showGroupControl = !0);
    },
    onCloseGroupControl: function () {
      s.globalData.activityInfo.showGroupControl = !1;
    },
    addViewCnt: function () {
      var e = this.data.activity._visitor.view;
      this.setData({ "activity._visitor.view": e + 1 });
    },
  },
});
