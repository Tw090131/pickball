var t,
  e,
  a = require("../../../../@babel/runtime/helpers/regeneratorRuntime"),
  i = require("../../../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  n = require("../../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  s = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  o = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  u = getApp();
Component({
  behaviors: [o],
  properties: {
    activity: { type: Object, value: "" },
    selfid: { type: String, value: "" },
  },
  data: {
    retreatList: [],
    hasChargePayed: !1,
    hasClubfeePayed: !1,
    isRefund: !0,
    reason: "",
    inputFocus: !1,
  },
  methods: {
    setRetreatList: function (t) {
      for (var e = !1, a = !1, i = 0; i < t.list.length; i++) {
        var r = t.list[i];
        r._isPayed &&
          (r._tradeDetailid ? (e = !0) : r._clubFeeDetailid && (a = !0));
      }
      this.setData({
        retreatList: t.list,
        hasChargePayed: e,
        hasClubfeePayed: a,
      });
    },
    onRefund: function () {
      this.setData({ isRefund: !0 });
    },
    onNotRefund: function () {
      this.setData({ isRefund: !1 });
    },
    onReasonInput: function (t) {
      this.setData({ reason: t.detail.value });
    },
    onRetreatConfirm:
      ((e = i(
        a().mark(function t() {
          var e,
            i,
            n,
            o,
            l,
            c = this;
          return a().wrap(
            function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    if (this._checkVipfun()) {
                      t.next = 2;
                      break;
                    }
                    return t.abrupt("return");
                  case 2:
                    this.setData({ inputFocus: !1 }),
                      (e = this.data.retreatList),
                      (i = 0);
                  case 5:
                    if (!(i < e.length)) {
                      t.next = 47;
                      break;
                    }
                    return (
                      (n = "退坑中" + (i + 1) + "/" + e.length),
                      wx.showLoading({ title: n, mask: !0 }),
                      (o = e[i]),
                      (t.next = 11),
                      wx.cloud
                        .callFunction({
                          name: "activity",
                          data: {
                            fun: "retreatNO",
                            activityid: o._activityid,
                            activityPlayerid: o._id,
                            reason: this.data.reason,
                            isAlternate: !0,
                            isManage: !0,
                            isDebug: u.globalData.isDebug,
                            version: u.globalData.frontVersion,
                          },
                        })
                        .catch(function (t) {
                          (0, s.mylog)("activity.retreatNO, err: ", t),
                            (0, r.networkFail)(!1, t, "activity.retreatNO"),
                            c.triggerEvent("batchEnd", {}, {}),
                            c.closeAnimate();
                        })
                    );
                  case 11:
                    if (
                      ((l = t.sent),
                      (0, s.mylog)("activity.retreatNO, res: ", l),
                      !l.result || !l.result.type)
                    ) {
                      t.next = 39;
                      break;
                    }
                    if ("fail" !== l.result.type) {
                      t.next = 22;
                      break;
                    }
                    return (
                      wx.hideLoading(),
                      wx.showModal({
                        content: l.result.msg,
                        showCancel: !1,
                        confirmText: "好的",
                      }),
                      this.triggerEvent("batchEnd", {}, {}),
                      this.closeAnimate(),
                      t.abrupt("return")
                    );
                  case 22:
                    if (
                      !o._isPayed ||
                      !this.data.isRefund ||
                      (!o._tradeDetailid && !o._clubFeeDetailid)
                    ) {
                      t.next = 37;
                      break;
                    }
                    return (
                      (n = "退坑" + (i + 1) + "/" + e.length),
                      o._tradeDetailid
                        ? (n += "退款中")
                        : o._clubFeeDetailid && (n += "退会费"),
                      wx.showLoading({ title: n, mask: !0 }),
                      (t.next = 28),
                      this._dealRefund(o)
                    );
                  case 28:
                    if (t.sent) {
                      t.next = 35;
                      break;
                    }
                    return (
                      this.triggerEvent("batchEnd", {}, {}),
                      this.closeAnimate(),
                      t.abrupt("return")
                    );
                  case 35:
                    t.next = 37;
                    break;
                  case 37:
                    t.next = 44;
                    break;
                  case 39:
                    return (
                      (0, s.mylog)("activity.retreatNO, not normal: ", l),
                      (0, r.networkFail)(!1, l, "activity.retreatNO"),
                      this.triggerEvent("batchEnd", {}, {}),
                      this.closeAnimate(),
                      t.abrupt("return")
                    );
                  case 44:
                    i++, (t.next = 5);
                    break;
                  case 47:
                    wx.showToast({ title: "退坑完成" }),
                      this.triggerEvent("batchEnd", {}, {}),
                      this.closeAnimate();
                  case 50:
                  case "end":
                    return t.stop();
                }
            },
            t,
            this
          );
        })
      )),
      function () {
        return e.apply(this, arguments);
      }),
    _dealRefund:
      ((t = i(
        a().mark(function t(e) {
          var i;
          return a().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (t.next = 2),
                    wx.cloud
                      .callFunction({
                        name: "tradeActivity",
                        data: {
                          fun: "refund",
                          tradeDetailid: e._tradeDetailid,
                          clubFeeDetailid: e._clubFeeDetailid,
                          isManage: !0,
                          isDebug: u.globalData.isDebug,
                          version: u.globalData.frontVersion,
                        },
                      })
                      .catch(function (t) {
                        return (
                          (0, s.mylog)("tradeActivity.refund, err: ", t),
                          (0, r.networkFail)(!1, t, "tradeActivity.refund"),
                          !1
                        );
                      })
                  );
                case 2:
                  if (
                    ((i = t.sent),
                    (0, s.mylog)("tradeActivity.refund, res: ", i),
                    !i.result || !i.result.type)
                  ) {
                    t.next = 9;
                    break;
                  }
                  if ("fail" !== i.result.type) {
                    t.next = 9;
                    break;
                  }
                  return (
                    wx.hideLoading(),
                    wx.showModal({
                      content: i.result.msg,
                      showCancel: !1,
                      confirmText: "好的",
                    }),
                    t.abrupt("return", !1)
                  );
                case 9:
                  return t.abrupt("return", !0);
                case 10:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )),
      function (e) {
        return t.apply(this, arguments);
      }),
    _checkVipfun: function () {
      var t = u.globalData.selfInfo,
        e = this.data.activity.crtMil;
      if (t && t.trustLevel >= 4 && t.trustDueMil > e) return !0;
      var a = this.data.activity,
        i = (0, n.raceRole)(this.data.selfid, a);
      u.globalData.payVipfunInfo.payAt = {
        from: "activity",
        actid: this.data.activity._id,
        mode: "batchRetreat",
        role: i,
      };
      var r = this.selectComponent("#payVisit");
      return r && (r.setMode("batchRetreat"), r.setRole(i), r.showPop()), !1;
    },
  },
});
