var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = getApp(),
  n = require("../../../../051A88476B9DF5DF637CE0402F9455F2.js"),
  i = require("../../../../12CAB7436B9DF5DF74ACDF443EC455F2.js"),
  o = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  s = require("../../../../DEAB3BE36B9DF5DFB8CD53E452D155F2.js"),
  r = require("../../../../F9FD82F46B9DF5DF9F9BEAF3FFB455F2.js");
Page({
  behaviors: [n, i, o, s, r],
  data: {
    navInfo: (0, t.getNavInfo)(),
    listType: "all",
    pageType: "manager",
    showAlternates: [],
    isRanking: !1,
  },
  onLoad: function (t) {
    var a = this;
    if ((this._dealOptions(t), t.type && "alternate" === t.type))
      var e = setTimeout(function () {
        a.setData({ crtTypeIdx: 1, crtType: "alternates" }), clearTimeout(e);
      }, 1300);
  },
  onReady: function () {},
  onShow: function () {
    var t = this,
      a = setTimeout(function () {
        e.globalData.activityInfo.showGroupControl &&
          t.selectComponent("#groupsControl").setShow(),
          clearTimeout(a);
      }, 1e3),
      n = e.globalData.activityInfo;
    n.groupChanged &&
      ((n.groupChanged = !1),
      this._hasGroupedPlayer(n.crtPlayers)
        ? this.setData({
            activity: n.crtActivity,
            players: n.crtPlayers,
            crtOrder: "group",
          })
        : this.setData({
            activity: n.crtActivity,
            players: n.crtPlayers,
            crtOrder: "smart",
          }),
      this.setData({ roles: this._dealRoles(this.data.players) })),
      n.groupManaged &&
        ((n.groupManaged = !1), this.setData({ activity: n.crtActivity })),
      n.autoGrouped &&
        (this.setData({ activity: n.crtActivity, crtOrder: "group" }),
        this._getActivityPlayers()),
      this.data.activity || this._getActivity(),
      (!this.data.players || this.data.players.length <= 0) &&
        this._getActivityPlayers();
  },
  _hasGroupedPlayer: function (t) {
    for (var a = 0; a < t.length; a++) if (t[a]._groupNo >= 0) return !0;
    return !1;
  },
  onHide: function () {},
  onUnload: function () {
    var t = e.globalData.activityInfo;
    (t.autoGrouped = !1),
      (t.groupChanged = !1),
      (t.groupManaged = !1),
      (t.showGroupControl = !1);
  },
  onRemove: function (t) {
    var a = this;
    wx.showModal({
      content: "移除后将无记录，是否移除？",
      cancelText: "暂不",
      confirmText: "移除",
      success: function (e) {
        e.cancel || (e.confirm && a._dealRemove(t));
      },
    });
  },
  _dealRemove: function (n) {
    var i = this;
    wx.showLoading({ title: "移除中", mask: !0 });
    var o = n.currentTarget.dataset.role,
      s = {
        fun: "remove",
        activityid: this.data.activity._id,
        activityPlayerid: o._id,
        isDebug: e.globalData.isDebug,
        verson: e.globalData.frontVersion,
      };
    e.globalData.userOpenId &&
      (s.userInfo = { openId: e.globalData.userOpenId }),
      wx.cloud.callFunction({
        name: "activity",
        data: s,
        success: function (t) {
          (0, a.mylog)("onRemove, res: ", t),
            i._getActivity(),
            i._getActivityPlayers(),
            "fail" === t.result.type &&
              wx.showModal({
                content: t.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
        },
        fail: function (e) {
          (0, a.mylog)("onRemove, err: ", e),
            (0, t.networkFail)(!1, e, "activity.remove");
        },
      });
  },
  _dealArrived: function (n, i) {
    var o = this;
    i
      ? wx.showLoading({ title: "签到中", mask: !0 })
      : wx.showLoading({ title: "取消签到中", mask: !0 }),
      wx.cloud.callFunction({
        name: "activity",
        data: {
          fun: "setArrived",
          activityPlayerid: n._id,
          arrived: i,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, a.mylog)("setArrived, res: ", t),
            o._getActivity(),
            o._getActivityPlayers();
        },
        fail: function (e) {
          (0, a.mylog)("setArrived, err: ", e),
            (0, t.networkFail)(!1, e, "activity.setArrived");
        },
      });
  },
  onRanking: function (t) {
    !this.data.alternates || this.data.alternates.length < 2
      ? wx.showToast({ title: "候补至少2人哦", icon: "none" })
      : this.setData({ isRanking: !0 });
  },
  onCancelRanking: function (t) {
    this._dealShowAlternates(), this.setData({ isRanking: !1 });
  },
  onReduct: function () {
    this._dealShowAlternates();
  },
  _dealShowAlternates: function () {
    var t = [];
    if (this.data.alternates)
      for (var a = 0; a < this.data.alternates.length; a++) {
        var e = this.data.alternates[a],
          n = JSON.parse(JSON.stringify(e));
        (n._srcNO = n._no), t.push(n);
      }
    this.setData({ showAlternates: t, changed: !1 }),
      this.data.isBatchRetreating && this._initBatchRetreat(!0);
  },
  onUp: function (t) {
    (0, a.mylog)("onUp, e: ", t);
    var e = t.currentTarget.dataset.index,
      n = this.data.showAlternates;
    if (n[e] && n[e - 1]) {
      var i = n[e]._no;
      (n[e]._no = n[e - 1]._no),
        (n[e].changeNO = !0),
        (n[e - 1]._no = i),
        (n[e - 1].changeNO = !0);
    }
    var o = n[e];
    (n[e] = n[e - 1]),
      (n[e - 1] = o),
      (0, a.mylog)("onUp, roles: ", n),
      this.setData({ showAlternates: n, changed: this._judgeChanged(n) }),
      (0, a.mylog)(
        "onUp, this.data.showAlternates: ",
        this.data.showAlternates
      );
  },
  onDown: function (t) {
    (0, a.mylog)("onUp, e: ", t);
    var e = t.currentTarget.dataset.index,
      n = this.data.showAlternates;
    if (n[e + 1] && n[e]) {
      var i = n[e + 1]._no;
      (n[e + 1]._no = n[e]._no),
        (n[e + 1].changeNO = !0),
        (n[e]._no = i),
        (n[e].changeNO = !0);
    }
    var o = n[e];
    (n[e] = n[e + 1]),
      (n[e + 1] = o),
      (0, a.mylog)("onDown, roles: ", n),
      this.setData({ showAlternates: n, changed: this._judgeChanged(n) }),
      (0, a.mylog)(
        "onDown, this.data.showAlternates: ",
        this.data.showAlternates
      );
  },
  _judgeChanged: function (t) {
    for (var a = !1, e = 0; e < t.length; e++) {
      var n = t[e];
      if (n && n.changeNO && n._no != n._srcNO) {
        a = !0;
        break;
      }
    }
    return a;
  },
  onConfirm: function () {
    if (this.data.changed) {
      for (var t = [], a = 0; a < this.data.showAlternates.length; a++) {
        var e = this.data.showAlternates[a];
        e &&
          e.changeNO &&
          e._no != e._srcNO &&
          t.push({ _id: e._id, _no: e._no, _srcNO: e._srcNO });
      }
      t.length <= 0 ? this.setData({ isRanking: !1 }) : this._dealRevise(t);
    } else this.setData({ isRanking: !1 });
  },
  _dealRevise: function (t) {
    var n = this;
    wx.showLoading({ title: "修改中", mask: !0 }),
      wx.cloud.callFunction({
        name: "activity",
        data: {
          fun: "revisePlayers",
          activityid: this.data.activity._id,
          changes: t,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, a.mylog)("revisePlayers, res: ", t),
            wx.showToast({ title: "排序完成" }),
            n.setData({ changed: !1, isRanking: !1 }),
            n._getActivity(),
            n._getActivityPlayers();
        },
        fail: function (t) {
          (0, a.mylog)("revisePlayers, err: ", t);
        },
      });
  },
  onSealed: function (t) {
    var a = this;
    wx.showModal({
      content: "拉黑后对方不能再报名俱乐部活动，是否确定将其拉黑？",
      cancelText: "暂不",
      complete: function (e) {
        e.cancel || (e.confirm && a._dealSealed(t));
      },
    });
  },
  _dealSealed: function (n) {
    var i = this;
    wx.showLoading({ title: "拉黑中", mask: !0 });
    var o = n.currentTarget.dataset.role;
    wx.cloud.callFunction({
      name: "club",
      data: {
        fun: "sealMember",
        clubid: this.data.activity._infos.clubid,
        memid: o._playerid,
        isDebug: e.globalData.isDebug,
        verson: e.globalData.frontVersion,
      },
      success: function (t) {
        (0, a.mylog)("_dealSealed, res: ", t),
          i._getActivity(),
          i._getActivityPlayers(),
          "fail" === t.result.type &&
            wx.showModal({
              content: t.result.msg,
              showCancel: !1,
              confirmText: "好的",
            });
      },
      fail: function (e) {
        (0, a.mylog)("_dealSealed, err: ", e),
          (0, t.networkFail)(!1, e, "club.sealMember");
      },
    });
  },
  onNotSealed: function () {
    wx.showModal({
      content: "可在俱乐部主页→更多→黑名单中取消拉黑，仅会长有此权限",
      showCancel: !1,
      confirmText: "好的",
    });
  },
  onGroupControl: function () {
    this.selectComponent("#groupsControl").showPop(),
      (e.globalData.activityInfo.showGroupControl = !0);
  },
  onCloseGroupControl: function () {
    e.globalData.activityInfo.showGroupControl = !1;
  },
  onGroupManage: function (t) {
    var a = t.currentTarget.dataset.index,
      e = this.selectComponent("#changeName");
    e && e.init(a) && e.showPop();
  },
  onGroupModified: function () {
    this.setData({ activity: e.globalData.activityInfo.crtActivity }),
      this.onRefresh();
  },
  onGroupByhand: function () {
    (0, t.navTo)({ url: "/pages/activity/groups/byHand/byHand" });
  },
  onManageGroup: function () {
    (0, t.navTo)({ url: "/pages/activity/groups/manage/manage" });
  },
});
