var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  e = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp();
Component({
  properties: {
    activity: { type: Object, value: "" },
    configs: { type: Object, value: "" },
    players: { type: Array, value: "" },
    selfid: { type: String, value: "" },
    selfInfo: { type: Object, value: "" },
    retreats: { type: Array, value: "" },
    isSharing: { type: Boolean, value: !1 },
    navInfo: { type: Object, value: "" },
  },
  data: {
    crtTimeMil: new Date().getTime(),
    isConsoleLog: i.globalData.isConsoleLog,
  },
  observers: {
    activity: function () {
      this.setData({ crtTimeMil: new Date().getTime() }),
        (0, e.mylog)("enlist observers selfInfo: ", this.data.selfInfo);
    },
  },
  methods: {
    onLocation: function () {
      wx.showLoading();
      var t = setTimeout(function () {
          wx.hideLoading(), clearTimeout(t);
        }, 1200),
        e = this.data.activity._infos.location;
      wx.openLocation({
        latitude: e.latitude,
        longitude: e.longitude,
        name: e.name,
        address: e.address,
      });
    },
    onClub: function () {
      (0, t.navTo)({
        url:
          "/packageD/pages/club/club?clubid=" + this.data.activity.club._id[0],
      });
    },
    onPlayers: function () {
      if (i.globalData.selfInfo)
        (i.globalData.activityInfo.isFromPlayers = !0),
          (0, t.navTo)({
            url: "/pages/activity/main/players/players?from=enlist",
          });
      else {
        wx.showToast({ title: "请先微信登录", duration: 1e3, icon: "none" });
        var e = setTimeout(function () {
          (0, t.navTo)({ url: "/pages/login/login" }), clearTimeout(e);
        }, 1e3);
      }
    },
    onCreator: function () {
      i.globalData.activityInfo.isBackFromUser = !0;
      var e = this.data.activity,
        a = this.data.activity.creator;
      (a._playerid = this.data.activity._creatorid),
        (0, t.multiRacePlayer)(e, a);
    },
    onVenueModal: function () {
      wx.showModal({
        content: this.data.activity._infos.venue,
        showCancel: !1,
        confirmText: "好的",
      });
    },
    onFiguresEdit: function () {
      this.triggerEvent("editFigures", {}, {});
    },
    onTitleEdit: function () {
      this.triggerEvent("titleEdit", {}, {});
    },
    onRemarkEdit: function () {
      this.triggerEvent("remarkEdit", {}, {});
    },
    onReceiptIntro: function () {
      var e = this.data.activity,
        i = this.data.activity._infos.feeMode;
      "before" === i
        ? e._receiptBeforeid
          ? (0, t.navTo)({
              url:
                "/packageA/pages/receiptBefore/receiptBefore?receiptid=" +
                e._receiptBeforeid,
            })
          : (0, t.navTo)({ url: "/packageA/pages/receiptBefore/intro/intro" })
        : "moreless" === i
        ? (0, t.navTo)({
            url: "/packageE/pages/guider/guider?type=activity&id=act_14",
          })
        : (0, t.navTo)({
            url: "/packageE/pages/guider/guider?type=activity&id=act_12",
          });
    },
    onClubVipIntro: function () {
      (0, t.navTo)({
        url: "/packageE/pages/guider/guider?type=club&id=club_11",
      });
    },
    onCopyRemark: function () {
      wx.setClipboardData({
        data: this.data.activity._infos.remarks,
        success: function (t) {},
        fail: function (a) {
          if (
            ((0, e.mylog)("setClipboardData, fail err: ", a),
            wx.getPrivacySetting)
          ) {
            var o = i.globalData.selfInfo;
            wx.getPrivacySetting({
              success: function (i) {
                if (
                  ((0, e.mylog)("getPrivacySetting, res: ", i),
                  i.needAuthorization)
                ) {
                  var a = "复制需要剪切板权限，请先微信登录",
                    n = "去登录",
                    r = "/pages/login/login";
                  o &&
                    ((a = "复制需要剪切板权限，请先到个人信息页授权"),
                    (n = "去授权"),
                    (r = "/packageA/pages/mine/setting/setting")),
                    wx.showModal({
                      content: a,
                      cancelText: "暂不",
                      confirmText: n,
                      complete: function (e) {
                        e.cancel, e.confirm && (0, t.navTo)({ url: r });
                      },
                    });
                }
              },
            });
          }
        },
      });
    },
    onAcode: function () {
      this._canShare()
        ? this.triggerEvent("acode", {}, {})
        : wx.showModal({
            content: "本次活动仅组织方可分享哦",
            showCancel: !1,
            confirmText: "好的",
          });
    },
    _canShare: function () {
      var t = this.data.activity,
        e = t._infos,
        i = new Date().getTime();
      return (
        !e.banShare ||
        i > t._startTimeMil ||
        !!(
          this.data.selfid === t._creatorid ||
          (t.me &&
            t.me.role.length > 0 &&
            ("president" === t.me.role[0] || "manager" === t.me.role[0]))
        )
      );
    },
    onCopyActivity: function () {
      var e = this;
      wx.showModal({
        content: "是否复制发布新的活动？",
        cancelText: "暂不",
        confirmText: "复制",
        complete: function (a) {
          if (a.cancel);
          else if (a.confirm) {
            wx.showLoading({ title: "复制中" });
            var o = setTimeout(function () {
              (i.globalData.activityInfo.copyActivity = e.data.activity),
                wx.hideLoading(),
                (0, t.navTo)({ url: "/pages/activity/activity?from=copy" }),
                clearTimeout(o);
            }, 1e3);
          }
        },
      });
    },
    onVisit: function () {
      this.triggerEvent("visitDetails", {}, {});
    },
    onShareDetails: function () {
      this.triggerEvent("shareDetails", {}, {});
    },
    onShareTips: function () {
      var t = this;
      wx.showModal({
        content: "小程序内的转发人数、转发量统计，仅组织者自己可见哦",
        cancelText: "详情",
        confirmText: "好的",
        success: function (e) {
          e.cancel && t.onShareDetails();
        },
      });
    },
  },
});
