var t = require("../../../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  i = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [e],
  properties: {
    activity: { type: Object, value: "" },
    groupList: { type: Array, value: [] },
  },
  data: { status: "mainFuns", crtIndex: 0, toView: "" },
  methods: {
    show: function () {
      this.setData({ status: "mainFuns" }), this._initIndex();
    },
    _initIndex: function () {
      var t = this,
        e = this.data.activity._infos.groups,
        n = e.length,
        s = this.data.groupList;
      if (
        ((0, i.mylog)("_initIndex, groups: ", e, "groupList: ", s),
        !s || s.length <= 0)
      )
        n = 0;
      else
        for (var a = 0; a < s.length; a++) {
          if (a >= s.length - 1) {
            n = a;
            break;
          }
          if (!(e[a].limitMax && s[a].players.length >= e[a].limitMax)) {
            n = a;
            break;
          }
        }
      this.setData({ crtIndex: n, toView: "" });
      var o = setTimeout(function () {
        var i = "group_" + (n - 3);
        t.setData({ toView: i }), clearTimeout(o);
      }, 1e3);
    },
    onFunsIntro: function () {
      this.setData({ status: "funsIntro" });
    },
    onMainFuns: function () {
      this.setData({ status: "mainFuns" });
    },
    onGroupChoosed: function (t) {
      var i = t.currentTarget.dataset.index;
      this.setData({ crtIndex: parseInt(i) });
    },
    onGroupSelectConfirm: function () {
      var i = this,
        e = "",
        n = this.data.activity._infos.groups,
        s = this.data.crtIndex;
      s <= n.length - 1 && (e = n[s].no);
      var a = this.data.groupList;
      if (
        s < a.length - 1 &&
        n[s].limitMax &&
        a[s].players.length >= n[s].limitMax
      ) {
        wx.showToast({
          title: (0, t.numToAZ)(s + 1) + "组人已满哦",
          icon: "none",
        });
        var o = setTimeout(function () {
          i._initIndex(), clearTimeout(o);
        }, 500);
      } else {
        this.triggerEvent("groupSelected", { groupNo: e }, {});
        o = setTimeout(function () {
          i.closeAnimate(), clearTimeout(o);
        }, 200);
      }
    },
  },
});
