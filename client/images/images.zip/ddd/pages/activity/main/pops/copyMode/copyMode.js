var e = require("../../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  o = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = getApp(),
  s = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [s],
  properties: {
    activity: { type: Object, value: "" },
    smart: { type: Array, value: [] },
    alternates: { type: Array, value: [] },
    groupList: { type: Array, value: [] },
  },
  data: {
    copyMode: {
      listType: "smart",
      needLevel: !1,
      showAnonymous: !0,
      needAlternates: !0,
      needRemarks: !1,
    },
  },
  methods: {
    init: function () {
      var e = this;
      wx.getStorage({
        key: "activity_copymode",
        success: function (t) {
          var o = t.data.copyMode;
          void 0 === o.needAlternates && (o.needAlternates = !0),
            void 0 === o.needRemarks && (o.needRemarks = !1),
            e.setData({ copyMode: o });
        },
      });
    },
    onNoLevel: function () {
      this.setData({ "copyMode.needLevel": !1 });
    },
    onNeedLevel: function () {
      this.setData({ "copyMode.needLevel": !0 });
    },
    onListTypeSmart: function () {
      this.setData({ "copyMode.listType": "smart" });
    },
    onListTypeGroup: function () {
      this.setData({ "copyMode.listType": "group" });
    },
    onShowAnonymous: function () {
      this.setData({ "copyMode.showAnonymous": !0 });
    },
    onNotShowAnonymous: function () {
      this.setData({ "copyMode.showAnonymous": !1 });
    },
    onNeedAlternates: function () {
      this.setData({ "copyMode.needAlternates": !0 });
    },
    onNoAlternates: function () {
      this.setData({ "copyMode.needAlternates": !1 });
    },
    onNeedRemarks: function () {
      this.setData({ "copyMode.needRemarks": !0 });
    },
    onNoRemarks: function () {
      this.setData({ "copyMode.needRemarks": !1 });
    },
    onConfirm: function () {
      var s = this;
      wx.showLoading({ title: "复制中", mask: !0 });
      var n = this.data.activity._infos;
      (n.copyMode = this.data.copyMode),
        wx.cloud.callFunction({
          name: "comm",
          data: {
            fun: "getPathUrl",
            path: "/pages/activity/activity",
            query: "activityid=" + this.data.activity._id,
            envType: a.globalData.isDebug ? "develop" : "release",
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (e) {
            if (
              ((0, o.mylog)("getPathUrl, res: ", e), "fail" === e.result.type)
            )
              return (
                wx.hideLoading(),
                void wx.showModal({
                  content: "系统繁忙，请稍后再尝试",
                  showCancel: !1,
                  confirmText: "好的",
                })
              );
            var a = (0, t.copyNameList)({
              infos: n,
              signs: s.data.smart,
              alternates: s.data.alternates,
              groups: s.data.groupList,
              url: e.result.urlLink,
              typeName: "活动",
            });
            s._dealCopyList(a);
          },
          fail: function (t) {
            (0, o.mylog)("getPathUrl, err: ", t),
              wx.showModal({
                content: "系统繁忙，请稍后再尝试",
                showCancel: !1,
                confirmText: "好的",
              }),
              (0, e.networkFail)(!1, t, "comm.getPathUrl");
          },
        });
    },
    _dealCopyList: function (e) {
      var t = this;
      wx.setClipboardData({
        data: e,
        success: function (e) {
          wx.showToast({ title: "名单已复制" }),
            wx.setStorage({
              key: "activity_copymode",
              data: { copyMode: t.data.copyMode },
            }),
            t.closeAnimate();
        },
        fail: function (e) {
          (0, o.mylog)("setClipboardData, fail err: ", e), wx.hideLoading();
        },
      });
    },
  },
});
