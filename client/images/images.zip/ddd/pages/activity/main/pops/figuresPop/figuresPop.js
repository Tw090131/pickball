var i = require("../../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  s = getApp();
Component({
  behaviors: [e],
  properties: {
    activity: { type: Object, value: "" },
    configs: { type: Object, value: "" },
  },
  data: { crtFigures: "" },
  observers: {
    activity: function () {
      this.data.activity &&
        this.setData({ crtFigures: this.data.activity._infos.figures });
    },
  },
  methods: {
    onFiguresPickerChange: function (i) {
      var t = parseInt(i.detail.value);
      this.setData({ crtFigures: t + 2 });
    },
    onConfirm: function (e) {
      var a = this;
      this.data.crtFigures !== this.data.activity._infos.figures
        ? (wx.showLoading({ title: "修改中", mask: !0 }),
          wx.cloud.callFunction({
            name: "activity",
            data: {
              fun: "modifyFigures",
              activityid: this.data.activity._id,
              figures: this.data.crtFigures,
              isDebug: s.globalData.isDebug,
              version: s.globalData.frontVersion,
            },
            success: function (i) {
              (0, t.mylog)("modifyFigures, res: ", i),
                a.closeAnimate(),
                a.triggerEvent("refresh", {}, {});
            },
            fail: function (e) {
              (0, t.mylog)("modifyFigures, err: ", e),
                (0, i.networkFail)(!1, e, "activity.modifyFigures");
            },
          }))
        : this.closeAnimate();
    },
  },
});
