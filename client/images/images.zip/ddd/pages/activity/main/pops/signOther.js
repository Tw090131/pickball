var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  a = getApp();
Component({
  behaviors: [i],
  properties: {
    mode: { type: String, value: "add" },
    activity: { type: Object, value: "" },
    type: { type: String, value: "sign" },
    groupList: { type: Array, value: [] },
  },
  data: {
    gender: 1,
    nickname: "",
    level: -1,
    levelvice: 2,
    activityPlayerid: "",
    spacing: 140,
    focus: !0,
    holdKeyboard: !0,
    selectGroupNo: "",
  },
  methods: {
    show: function () {
      this.setData({ selectGroupNo: "" });
    },
    onMan: function () {
      this.setData({ gender: 1 });
    },
    onWoman: function () {
      this.setData({ gender: 2 });
    },
    onNickInput: function (e) {
      this.setData({ nickname: e.detail.value });
    },
    onOtherAssess: function () {
      this._initStatus(), this.selectComponent("#selfAssess").showPop();
    },
    _initStatus: function () {
      this.setData({ spacing: 0, focus: !1, holdKeyboard: !1 });
    },
    onLevelAssessed: function (e) {
      this.setData({
        level: e.detail.level,
        levelvice: e.detail.vice,
        spacing: 140,
        focus: !0,
        holdKeyboard: !0,
      });
    },
    onCloseAssess: function () {
      this.setData({ spacing: 140, focus: !0, holdKeyboard: !0 });
    },
    onConfirm: function () {
      var e = this;
      this.data.activity._nos.length - 1 >= this.data.activity._infos.figures
        ? this._dealJudgeRealname()
        : new Date().getTime() >
          this.data.activity._startTimeMil -
            3600 * this.data.activity._infos.retreatTime * 1e3
        ? wx.showModal({
            content: "现在报名不可退坑，是否报名？",
            cancelText: "暂不",
            confirmText: "报名",
            success: function (t) {
              t.cancel
                ? e.onCloseAssess()
                : t.confirm && e._dealJudgeRealname();
            },
          })
        : this._dealJudgeRealname();
    },
    _dealJudgeRealname: function () {
      var e = this;
      this.data.activity._infos.isRealname && !this.data.nickname
        ? wx.showModal({
            content: "本次活动要求填写真实姓名，请填写朋友姓名",
            showCancel: !1,
            confirmText: "好的",
            success: function (t) {
              t.confirm && e.onCloseAssess();
            },
          })
        : this._dealJudgeLevel();
    },
    _dealJudgeLevel: function () {
      var i = this.data.activity._infos,
        s = this.data.gender;
      if (
        ((0, t.mylog)("_dealJudgeLevel, selfInfo: ", a.globalData.selfInfo),
        (0, t.mylog)("_dealJudgeLevel, infos: ", i),
        i.manLevel && i.womanLevel)
      )
        if (i.manLevel.islimit || i.womanLevel.islimit)
          if (0 !== s && s)
            if (
              (1 === s && i.manLevel.islimit) ||
              (2 === s && i.womanLevel.islimit)
            ) {
              var n = (0, e.calcLevel)(this.data.level, this.data.levelvice);
              0 == n || n || (n = -1),
                (0, t.mylog)("friendLevel: ", n),
                i.clubid &&
                "alone" != i.clubid &&
                ((1 === s && i.manLevel.justCertified) ||
                  (2 === s && i.womanLevel.justCertified))
                  ? this._judgeLevelJustCertified(s)
                  : n <= -1
                  ? this._judgeLevelNolevel(s)
                  : 1 === s
                  ? this._judgeLevelRange(n, i.manLevel, s)
                  : this._judgeLevelRange(n, i.womanLevel, s);
            } else this._dealConfirm();
          else this._judgeLevelNogender();
        else this._dealConfirm();
      else this._dealConfirm();
    },
    _judgeLevelNogender: function () {
      var e = this;
      wx.hideLoading({ success: function (e) {} }),
        wx.showModal({
          content: "本次活动对男女等级有要求，请完善朋友性别、羽毛球等级",
          showCancel: !1,
          confirmText: "好的",
          success: function (t) {
            t.confirm && e.onCloseAssess();
          },
        });
    },
    _judgeLevelJustCertified: function (e) {
      wx.hideLoading();
      var t =
        "本次活动要求" +
        (1 === e ? "男" : "女") +
        "认证等级，请您朋友本人报名哦";
      wx.showModal({ content: t, showCancel: !1, confirmText: "好的" });
    },
    _judgeLevelNolevel: function (e) {
      var t = this;
      wx.hideLoading({ success: function (e) {} }),
        wx.showModal({
          content:
            "本次活动对" +
            (1 === e ? "男" : "女") +
            "等级有要求，请完善朋友羽毛球等级",
          showCancel: !1,
          confirmText: "好的",
          success: function (e) {
            e.confirm && t.onCloseAssess();
          },
        });
    },
    _judgeLevelRange: function (t, i, a) {
      var s = this;
      t >= 0 && (t < i.min || t > i.max)
        ? (wx.hideLoading({ success: function (e) {} }),
          wx.showModal({
            content:
              "本次活动要求" +
              (1 === a ? "男" : "女") +
              (0, e.getLevelText)(i.min, i.max) +
              "，您朋友等级不符合要求，无法报名哦",
            showCancel: !1,
            confirmText: "好的",
            success: function (e) {
              e.confirm && s.onCloseAssess();
            },
          }))
        : this._dealConfirm();
    },
    _dealConfirm: function () {
      var e = this.data.activity,
        t = this.data.activity._infos;
      t.groupCanPlayer && e._nos.length - 1 < t.figures
        ? (this._initStatus(), this.selectComponent("#groupSelect").showPop())
        : this._dealConfirmSec();
    },
    onGroupSelected: function (e) {
      var i = void 0;
      this.data.activity._infos.groupCanPlayer && (i = e.detail.groupNo),
        (0, t.mylog)("onGroupSelected, e: ", e, "groupNo: ", i),
        this.setData({ selectGroupNo: i }),
        this._dealConfirmSec();
    },
    _dealConfirmSec: function () {
      var e = this.data.activity._infos;
      (0, t.mylog)("_dealJoin, feeMode: ", e.feeMode),
        "charge" === e.feeMode || "before" === e.feeMode
          ? (this._initStatus(), this._dealJoinPay())
          : "moreless" === e.feeMode
          ? (this.setData({ spacing: 0, focus: !1, holdKeyboard: !1 }),
            this._dealJoinCharge())
          : this._dealConfirmComm();
    },
    _dealJoinPay: function () {
      var e = this.data.activity;
      if (
        e &&
        e.club &&
        e.club._creatorid &&
        e.club._creatorid.length > 0 &&
        e.me &&
        e.me.status &&
        e.me.status.length > 0 &&
        "normal" === e.me.status[0]
      ) {
        var t = e.club;
        t._vipfee &&
        t._vipfee.length > 0 &&
        t._vipfee[0].opened &&
        e.me &&
        e.me.memfee &&
        e.me.memfee.length > 0 &&
        e.me.memfee[0] > 0
          ? this._dealNotVip()
          : this._dealJoinCharge();
      } else this._dealJoinCharge();
    },
    _dealNotVip: function () {
      var e = this.data.activity._infos,
        t = this.data.gender,
        i = e.feeMan;
      2 === t && (i = e.feeWoman);
      var a = this.data.activity.me;
      this._dealClubfeePay(a.memfee, i, "normal");
    },
    _dealClubfeePay: function (e, t, i) {
      e >= 100 * t ? this._clubfeePay(i, t) : this._dealFeeNotEnough();
    },
    _dealFeeNotEnough: function () {
      var t = this;
      "before" === this.data.activity._infos.feeMode
        ? wx.showModal({
            content: "您在该俱乐部的会费余额已不足",
            cancelText: "直接报名",
            confirmText: "去充值",
            success: function (i) {
              i.cancel
                ? t._dealConfirmComm()
                : i.confirm &&
                  (0, e.navTo)({
                    url:
                      "/packageD/pages/club/club?clubid=" +
                      t.data.activity._infos.clubid +
                      "&type=me",
                  });
            },
          })
        : wx.showModal({
            content: "您在该俱乐部的会费余额已不足",
            cancelText: "直接付款",
            confirmText: "去充值",
            success: function (i) {
              i.cancel
                ? t._dealJoinCharge()
                : i.confirm &&
                  (0, e.navTo)({
                    url:
                      "/packageD/pages/club/club?clubid=" +
                      t.data.activity._infos.clubid +
                      "&type=me",
                  });
            },
          });
    },
    _clubfeePay: function (e, i) {
      (0, t.mylog)("_clubfeePay, memRole: ", e);
      var a = this.selectComponent("#clubfeePay");
      a.setPayforActivity({
        clubid: this.data.activity._infos.clubid,
        type: "activity",
        subtype: "signOther",
        costKind: e,
        costFee: i,
        activityid: this.data.activity._id,
        gender: this.data.gender,
        nickname: this.data.nickname,
        level: this.data.level,
        levelvice: this.data.levelvice,
        anonymous: this.data.activity.selfPlayer
          ? this.data.activity.selfPlayer._anonymous
          : void 0,
        selectGroupNo: this.data.selectGroupNo,
      }),
        a.showPop();
    },
    _dealJoinCharge: function () {
      var e = this.data.activity._infos;
      if ("before" === e.feeMode) this._dealConfirmComm();
      else {
        var t = this.data.gender,
          i = e.feeMan;
        2 === t && (i = e.feeWoman);
        var a = this.selectComponent("#payPop");
        a.setPayforActivity({
          type: "activity",
          subtype: "signOther",
          gender: t,
          fee: i,
          activityid: this.data.activity._id,
          nickname: this.data.nickname,
          level: this.data.level,
          levelvice: this.data.levelvice,
          anonymous: this.data.activity.selfPlayer
            ? this.data.activity.selfPlayer._anonymous
            : void 0,
          selectGroupNo: this.data.selectGroupNo,
        }),
          a.showPop();
      }
    },
    onPaySuccess: function (e) {
      this._dealConfirmComm(e.detail.tradeDetailid);
    },
    _dealConfirmComm: function (i) {
      var s = this;
      "sign" === this.data.type
        ? wx.showLoading({ title: "报名中", mask: !0 })
        : wx.showLoading({ title: "候补中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "signOther_2",
            activityid: this.data.activity._id,
            nickName: this.data.nickname,
            gender: this.data.gender,
            level: this.data.level,
            levelvice: this.data.levelvice,
            tradeDetailid: i,
            selectGroupNo: this.data.selectGroupNo,
            checkUnreceived: !0,
            anonymous: this.data.activity.selfPlayer
              ? this.data.activity.selfPlayer._anonymous
              : void 0,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (a) {
            if (
              ((0, t.mylog)("signOther_2, success: ", a),
              wx.hideLoading({ success: function (e) {} }),
              "fail" === a.result.type)
            )
              if (
                (wx.hideLoading(),
                s.triggerEvent("refresh", {}, {}),
                a.result.listUnrceived)
              ) {
                var n = "请先完成未付款账单，否则不能报名该";
                "alone" != s.data.activity._infos.clubid
                  ? (n += "俱乐部")
                  : (n += "组织者"),
                  (n += "的新活动哦"),
                  i && (n += "（已退款，请注意查收）"),
                  wx.showModal({
                    content: n,
                    showCancel: !1,
                    confirmText: "账单详情",
                    complete: function (t) {
                      if (t.confirm) {
                        var i = s.data.activity._creatorid,
                          a = s.data.activity._infos.clubid;
                        (0, e.navTo)({
                          url:
                            "/packageA/pages/mine/myBill/unReceived?creatorid=" +
                            i +
                            "&clubid=" +
                            a,
                        });
                      }
                    },
                  });
              } else {
                var o = a.result.msg;
                i && (o += "（已退款，请注意查收）"),
                  wx.showModal({
                    content: o,
                    showCancel: !1,
                    confirmText: "好的",
                    success: function (e) {
                      e.confirm && s.onCloseAssess();
                    },
                  });
              }
            else s._signOtherSuccess(a.result.activityPlayerid);
          },
          fail: function (i) {
            (0, t.mylog)("signOther_2, err: ", i),
              (0, e.networkFail)(!1, i, "activity.signOther_2");
          },
        });
    },
    _signOtherSuccess: function (e) {
      var t = this;
      "sign" === this.data.type
        ? this.triggerEvent(
            "signOtherSuccess",
            { mode: "signup", activityPlayerid: e, gender: this.data.gender },
            {}
          )
        : this.triggerEvent(
            "signOtherSuccess",
            {
              mode: "alternate",
              activityPlayerid: e,
              gender: this.data.gender,
            },
            {}
          ),
        this.closeAnimate(),
        this.setData({ nickname: "" }),
        this.triggerEvent("refresh", {}, {});
      var i = setTimeout(function () {
        t.onCloseAssess(), clearTimeout(i);
      }, 1e3);
    },
    onClubfeePayJoined: function (e) {
      this._signOtherSuccess(e.detail.activityPlayerid);
    },
    set: function (e) {
      this.setData({
        gender: e.gender,
        nickname: e.nickname,
        level: e.level,
        levelvice: e.levelvice,
        activityPlayerid: e.activityPlayerid,
      });
    },
    onModify: function (i) {
      var s = this;
      wx.showLoading({ title: "修改中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifyOther",
            activityPlayerid: this.data.activityPlayerid,
            nickName: this.data.nickname,
            gender: this.data.gender,
            level: this.data.level,
            levelvice: this.data.levelvice,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (e) {
            (0, t.mylog)("modifyOther, success: ", e),
              "fail" === e.result.type
                ? (wx.hideLoading(),
                  wx.showModal({
                    content: e.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }))
                : (s.triggerEvent("refresh", {}, {}),
                  s.setData({ nickname: "" }),
                  s.closeAnimate());
          },
          fail: function (i) {
            (0, t.mylog)("modifyOther, err: ", i),
              (0, e.networkFail)(!1, i, "activity.modifyOther");
          },
        });
    },
  },
});
