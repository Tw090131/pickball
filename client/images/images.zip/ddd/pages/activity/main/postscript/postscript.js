var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  s = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  e = getApp();
Component({
  behaviors: [i],
  properties: {
    type: { type: String, value: "add" },
    classify: { type: String, value: "activity" },
    activity: { type: Object, value: "" },
  },
  data: {
    mode: "signup",
    kind: "self",
    postscript: "",
    activityPlayerid: "",
    multiRacePlayerid: "",
    gender: 1,
    showAnonymous: !0,
    showSettedTips: !1,
    crtFocus: !1,
    lastFocus: !1,
    isDebug: e.globalData.isDebug,
    selfInfo: "",
    crtMil: "",
  },
  methods: {
    show: function () {
      this.setData({
        selfInfo: e.globalData.selfInfo,
        crtMil: new Date().getTime(),
      });
    },
    setMode: function (t) {
      this.setData({ mode: t, postscript: "" });
    },
    setKind: function (t) {
      this.setData({ kind: t });
    },
    setActivityPlayerid: function (t) {
      this.setData({ activityPlayerid: t });
    },
    setMultiRacePlayerid: function (t) {
      this.setData({ multiRacePlayerid: t });
    },
    setPlayerGender: function (t) {
      (0, s.mylog)("setPlayerGender, gender: ", t),
        t || (t = 1),
        this.setData({ gender: t });
    },
    setSelfAnonymous: function (t) {
      t && t.isAnonymous
        ? this.setData({ showAnonymous: !1, showSettedTips: !1 })
        : this.setData({ showAnonymous: !0, showSettedTips: !1 });
    },
    setOtherHeadInfo: function (t) {
      t && t.isSetted
        ? this.setData({ showAnonymous: !1, showSettedTips: !1 })
        : this.setData({ showAnonymous: !0, showSettedTips: !1 });
    },
    setPostscript: function (t) {
      this.setData({ postscript: t || "" }),
        (0, s.mylog)("postscript: ", this.data.postscript);
    },
    onPostscriptInput: function (t) {
      this.setData({ postscript: t.detail.value });
    },
    onInputFocus: function (t) {
      (0, s.mylog)("onCrtFocus, e: ", t),
        this.setData({ crtFocus: !0, lastFocus: !0 });
    },
    onInputBlur: function (t) {
      this.setData({ crtFocus: !1, lastFocus: !1 });
    },
    onPend: function () {
      this.setData({ postscript: "待定" });
    },
    onFerry: function () {
      this.setData({ postscript: "接送" });
    },
    onWaterBets: function () {
      this.setData({ postscript: "打水" });
    },
    onLater: function () {
      this.setData({ postscript: "晚点" });
    },
    onRace: function () {
      this.setData({ postscript: "比赛" });
    },
    onStudy: function () {
      this.setData({ postscript: "学球" });
    },
    onClear: function () {
      this.setData({ postscript: "" });
    },
    onAdd: function () {
      var s = "";
      if (
        (this.data.postscript && (s = this.data.postscript.trim()),
        !(s = (0, t.dealReg)(s)))
      )
        return (
          this.closeAnimate(),
          void this.triggerEvent(
            "closePostscript",
            { kind: this.data.kind },
            {}
          )
        );
      wx.showLoading({ title: "添加中", mask: !0 }),
        "activity" === this.data.classify
          ? this._dealAddByActivity(s)
          : this._dealAddByMultiRace(s);
    },
    _dealAddByActivity: function (i) {
      var o = this;
      wx.cloud.callFunction({
        name: "activity",
        data: {
          fun: "postscript",
          postscript: i,
          activityPlayerid: this.data.activityPlayerid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          if (
            ((0, s.mylog)("activity postscript, res: ", t),
            "fail" === t.result.type)
          )
            wx.hideLoading(),
              wx.showModal({
                content: t.result.msg,
                showCancel: !1,
                confirmText: "好的",
              });
          else {
            wx.showToast({ title: "备注成功", duration: 800 }),
              o.closeAnimate(),
              o.triggerEvent("refresh", {}, {});
            var i = setTimeout(function () {
              o.triggerEvent("closePostscript", { kind: o.data.kind }, {}),
                clearTimeout(i);
            }, 500);
          }
        },
        fail: function (i) {
          (0, s.mylog)("activity postscript, err: ", i),
            (0, t.networkFail)(!1, i, "activity.postscript, add");
        },
      });
    },
    _dealAddByMultiRace: function (i) {
      var o = this;
      wx.cloud.callFunction({
        name: "multiRace",
        data: {
          fun: "postscript",
          postscript: i,
          multiRacePlayerid: this.data.multiRacePlayerid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, s.mylog)("race postscript, res: ", t),
            "fail" === t.result.type
              ? (wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                }))
              : (wx.showToast({ title: "备注成功", duration: 800 }),
                o.closeAnimate(),
                o.triggerEvent("closePostscript", { kind: o.data.kind }, {}));
        },
        fail: function (i) {
          (0, s.mylog)("race postscript, err: ", i),
            (0, t.networkFail)(!1, i, "multiRace.postscript, add");
        },
      });
    },
    onModify: function () {
      var s = "";
      this.data.postscript && (s = this.data.postscript.trim()),
        (s = (0, t.dealReg)(s)),
        wx.showLoading({ title: "修改中", mask: !0 }),
        "activity" === this.data.classify
          ? this._dealModifyByActivity(s)
          : this._dealModifyByMultiRace(s);
    },
    _dealModifyByActivity: function (i) {
      var o = this;
      wx.cloud.callFunction({
        name: "activity",
        data: {
          fun: "postscript",
          postscript: i,
          activityPlayerid: this.data.activityPlayerid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, s.mylog)("postscript, res: ", t),
            "fail" === t.result.type
              ? (wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                }))
              : (wx.showToast({ title: "修改成功" }),
                o.closeAnimate(),
                o.triggerEvent("refresh", {}, {}),
                o.triggerEvent("closePostscript", { kind: o.data.kind }, {}));
        },
        fail: function (i) {
          (0, s.mylog)("postscript, err: ", i),
            (0, t.networkFail)(!1, i, "activity.postscript, modify");
        },
      });
    },
    _dealModifyByMultiRace: function (i) {
      var o = this;
      wx.cloud.callFunction({
        name: "multiRace",
        data: {
          fun: "postscript",
          postscript: i,
          multiRacePlayerid: this.data.multiRacePlayerid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, s.mylog)("postscript, res: ", t),
            "fail" === t.result.type
              ? (wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                }))
              : (wx.showToast({ title: "修改成功" }),
                o.closeAnimate(),
                o.triggerEvent("refresh", {}, {}),
                o.triggerEvent("closePostscript", { kind: o.data.kind }, {}));
        },
        fail: function (i) {
          (0, s.mylog)("postscript, err: ", i),
            (0, t.networkFail)(!1, i, "activity.postscript, modify");
        },
      });
    },
    close: function () {
      (0, s.mylog)("kind: ", this.data.kind),
        this.triggerEvent("closePostscript", { kind: this.data.kind }, {});
    },
    onOtherhead: function () {
      this.setData({ crtFocus: !1 }),
        this.selectComponent("#signOtherHead").setActPlayerid(
          this.data.activityPlayerid
        ),
        this.selectComponent("#signOtherHead").setGender(this.data.gender),
        this.selectComponent("#signOtherHead").showPop();
    },
    onAnonymous: function () {
      this.setData({ crtFocus: !1 }),
        this.selectComponent("#anonymousSelf").setActPlayerid(
          this.data.activityPlayerid
        ),
        this.selectComponent("#anonymousSelf").setGender(this.data.gender),
        this.selectComponent("#anonymousSelf").showPop();
    },
    onAnonyClose: function () {
      this.setData({ crtFocus: this.data.lastFocus });
    },
    onRefresh: function () {
      this.triggerEvent("refresh", {}, {});
    },
    onAnonySuccess: function () {
      this.setData({
        showAnonymous: !1,
        showSettedTips: !0,
        crtFocus: this.data.lastFocus,
      });
    },
  },
});
