var e = require("../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../9CD29CB36B9DF5DFFAB4F4B41AA455F2.js"),
  a = require("../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  n = getApp(),
  i = "";
Component({
  properties: {
    classify: { type: String, value: "common" },
    mode: { type: String, value: "alone" },
    from: { type: String, value: "creater" },
    status: { type: String, value: "create" },
    activityid: { type: String, value: "" },
    clubName: { type: String, value: "" },
    infos: {
      type: Object,
      value: {
        clubid: "alone",
        title: null,
        location: null,
        venue: null,
        date: null,
        time: null,
        figures: 16,
        feeMode: "offline",
        feeMan: null,
        feeWoman: null,
        feeManVip: null,
        feeWomanVip: null,
        retreatTime: 2,
        rangeType: "open",
        signOther: "canOther",
        signOtherLimit: 0,
        remarks: "",
        isRealname: !1,
        needPhone: !1,
        manLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
        womanLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
        canSignLater: !1,
        banShare: !1,
        groups: null,
        groupCanPlayer: !1,
        groupOnlyManager: !1,
      },
    },
  },
  data: {
    navInfo: (0, e.getNavInfo)(),
    configs: (0, t.getConfig)(),
    showStore: !0,
    showSenior: !1,
    clubloading: !1,
    isReleasing: !1,
  },
  lifetimes: {
    attached: function () {
      var e = this;
      (0, a.mylog)(
        "creater attached, infos: ",
        this.data.infos,
        "status: ",
        this.data.status
      ),
        "create" === this.data.status
          ? (this._initClubs(),
            wx.getStorage({
              key: "activity_options",
              success: function (t) {
                e._dealCopy(t.data, !1);
              },
              fail: function (e) {},
              complete: function (e) {
                wx.hideLoading();
              },
            }))
          : "copy" === this.data.status
          ? (this._initClubs(!0), this._dealCopy(this.data.infos, !1))
          : (this._initClubs(!0), this._dealCopy(this.data.infos, !0));
    },
  },
  methods: {
    setFrom: function (e) {
      this.setData({ from: e }), (0, a.mylog)("from: ", this.data.from);
    },
    setClubid: function (e) {
      this.setData({ "infos.clubid": e }),
        (0, a.mylog)("infos.clubid: ", this.data.infos.clubid);
    },
    _initClubs: function (t) {
      var a = this;
      this.setData({ clubloading: !0 });
      var o = {
        fun: "myManageClubs",
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      };
      n.globalData.userOpenId &&
        (o.userInfo = { openId: n.globalData.userOpenId }),
        wx.cloud.callFunction({
          name: "club",
          data: o,
          success: function (e) {
            n.globalData.isConsoleLog &&
              (console.log("configs: ", a.data.configs),
              console.log("myManageClubs, res: ", e),
              console.log(
                "myManageClubs: ",
                n.globalData.storageName.myManageClubs
              ));
            for (
              var o = {
                  names: ["无所属俱乐部"],
                  values: ["alone"],
                  roles: ["none"],
                  vipPrices: ["closed"],
                },
                s = { names: [], values: [], roles: [], vipPrices: [] },
                l = e.result.clubs,
                r = 0;
              r < l.length;
              r++
            ) {
              var f = l[r].club,
                u = f._name[0];
              f._nameSimple && f._nameSimple[0] && (u = f._nameSimple[0]);
              var d = f._id[0],
                h = "closed";
              f._vipfee &&
                f._vipfee.length > 0 &&
                f._vipfee[0].opened &&
                f._vipfee[0].vipPriceUsing &&
                (h = "opened"),
                o.names.push(u),
                o.values.push(d),
                o.roles.push(l[r]._role),
                o.vipPrices.push(h),
                s.names.push(u),
                s.values.push(d),
                s.roles.push(l[r]._role),
                s.vipPrices.push(h);
            }
            -1 != o.values.indexOf(a.data.infos.clubid) || t
              ? a.setData({ "configs.clubs": o })
              : a.setData({
                  "infos.clubid": "alone",
                  "infos.rangeType": "open",
                  "configs.clubs": o,
                }),
              (i = a.data.infos.clubid),
              a._storeOptions(),
              wx.setStorage({
                data: s,
                key: n.globalData.storageName.myManageClubs,
              });
          },
          fail: function (t) {
            n.globalData.isConsoleLog && console.log("myManageClubs, err: ", t),
              (0, e.networkFail)(!1, t, "club.myManageClubs");
          },
          complete: function (e) {
            a.setData({ clubloading: !1 });
          },
        });
    },
    _dealCopy: function (e, a) {
      var o = this.data.infos;
      (this.setData({ configs: (0, t.getConfig)() }),
      "creater" === this.data.from) &&
        (null != e.clubid && (o.clubid = e.clubid),
        a ||
          (-1 === this.data.configs.clubs.values.indexOf(e.clubid) &&
            ((o.clubid = "alone"), (e.rangeType = "open"))));
      (i = o.clubid),
        null != e.title && (o.title = e.title),
        null != e.location && (o.location = e.location),
        null != e.venue && (o.venue = e.venue),
        null != e.date && (o.date = e.date),
        null != e.time && (o.time = e.time),
        null != e.feeMode && (o.feeMode = e.feeMode),
        null != e.feeMan && (o.feeMan = e.feeMan),
        null != e.feeWoman && (o.feeWoman = e.feeWoman),
        null != e.feeManVip && (o.feeManVip = e.feeManVip),
        null != e.feeWomanVip && (o.feeWomanVip = e.feeWomanVip),
        null != e.retreatTime && (o.retreatTime = e.retreatTime),
        null != e.isRealname && (o.isRealname = e.isRealname),
        null != e.needPhone && (o.needPhone = e.needPhone),
        null != e.manLevel && (o.manLevel = e.manLevel),
        null != e.womanLevel && (o.womanLevel = e.womanLevel),
        null != e.figures && "" != e.figures
          ? (o.figures = e.figures)
          : (o.figures = 16),
        this._dealRange(o.clubid),
        null != e.rangeType && (o.rangeType = e.rangeType),
        null != e.signOther
          ? (o.signOther = e.signOther)
          : (o.signOther = "canOther"),
        null != e.signOtherLimit
          ? (o.signOtherLimit = e.signOtherLimit)
          : (o.signOtherLimit = 0),
        null != e.remarks && (o.remarks = e.remarks),
        null != e.canSignLater
          ? (o.canSignLater = e.canSignLater)
          : (o.canSignLater = !1),
        null != e.banShare ? (o.banShare = e.banShare) : (o.banShare = !1),
        null != e.groupCanPlayer
          ? (o.groupCanPlayer = e.groupCanPlayer)
          : (o.groupCanPlayer = !1),
        null != e.groupOnlyManager
          ? (o.groupOnlyManager = e.groupOnlyManager)
          : (o.groupOnlyManager = !1),
        null != e.groups && (o.groups = e.groups),
        this.setData({ infos: o }),
        n.globalData.isConsoleLog && console.log("infos: ", o);
    },
    _dealRange: function (e) {
      var t = this.data.configs;
      (t.rangeTypes =
        e && "alone" !== e
          ? {
              names: ["开放报名", "仅会员报名"],
              values: ["open", "clubMember"],
            }
          : { names: ["开放报名"], values: ["open"] }),
        this.setData({ configs: t });
    },
    onStore: function () {
      this._storeOptions(),
        wx.showToast({ title: "已保存本地，下次可复用", icon: "none" });
    },
    onClear: function () {
      var e = this;
      wx.showModal({
        content: "清空后，将无法复用这些活动信息，是否确定清空？",
        cancelText: "暂不",
        confirmText: "清空",
        success: function (t) {
          t.cancel || (t.confirm && (e._dealInit(), e._storeOptions()));
        },
      });
    },
    onBack: function () {
      this.triggerEvent("back", {}, {});
    },
    onSenior: function () {
      this.data.showSenior
        ? this.setData({ showSenior: !1 })
        : this.setData({ showSenior: !0 });
    },
    _dealInit: function () {
      this.setData({
        showStore: !1,
        infos: {
          clubid: "alone",
          title: null,
          location: null,
          venue: null,
          date: null,
          time: null,
          figures: 16,
          feeMode: "offline",
          feeMan: null,
          feeWoman: null,
          feeManVip: null,
          feeWomanVip: null,
          retreatTime: 2,
          rangeType: "open",
          signOther: "canOther",
          signOtherLimit: 0,
          remarks: "",
          isRealname: !1,
          needPhone: !1,
          manLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
          womanLevel: { islimit: !1, min: 0, max: 10, justCertified: !1 },
          canSignLater: !1,
          banShare: !1,
          groups: null,
          groupCanPlayer: !1,
          groupOnlyManager: !1,
        },
      }),
        (i = "alone");
    },
    onClubPickerChange: function (e) {
      var t = this.data.configs.clubs,
        a = parseInt(e.detail.value);
      this.setData({ "infos.clubid": t.values[a] }),
        (("alone" === i && "alone" != this.data.infos.clubid) ||
          ("alone" != i && "alone" === this.data.infos.clubid)) &&
          (this._dealRange(this.data.infos.clubid),
          this.setData({
            "infos.rangeType": this.data.configs.rangeTypes.values[0],
          }),
          (i = this.data.infos.clubid)),
        this._storeOptions();
    },
    onTitleInput: function (e) {
      this.setData({ "infos.title": e.detail.value }), this._storeOptions();
    },
    onLocation: function () {
      var t = this;
      wx.showLoading();
      var n = setTimeout(function () {
          wx.hideLoading(), clearTimeout(n);
        }, 1200),
        i = this.data.infos.location;
      i || (i = { latitude: void 0, longitude: void 0 }),
        wx.chooseLocation({
          latitude: i.latitude,
          longitude: i.longitude,
          success: function (n) {
            (0, a.mylog)("chooseLocation, res: ", n);
            var i = (0, e.addressAnalysis)(n.address);
            t.setData({
              "infos.location": {
                name: n.name,
                address: n.address,
                province: i.province,
                city: i.city,
                district: i.district,
                latitude: n.latitude,
                longitude: n.longitude,
              },
            }),
              t._storeOptions();
          },
          fail: function (e) {
            (0, a.mylog)("chooseLocation, err: ", e);
          },
        });
    },
    onVenueInput: function (e) {
      this.setData({ "infos.venue": e.detail.value }), this._storeOptions();
    },
    onDaterPop: function (e) {
      this.selectComponent("#dater").init(this.data.infos.date),
        this.selectComponent("#dater").showPop();
    },
    onSelectDate: function (e) {
      this.setData({ "infos.date": e.detail.date }), this._storeOptions();
    },
    onTimerPop: function (e) {
      this.selectComponent("#timer").init(this.data.infos.time),
        this.selectComponent("#timer").showPop();
    },
    onSelcetTimer: function (e) {
      this.setData({ "infos.time": e.detail.time }), this._storeOptions();
    },
    onFiguresPickerChange: function (e) {
      var t = parseInt(e.detail.value);
      this.setData({ "infos.figures": t + 2 }), this._storeOptions();
    },
    onForGroup: function () {
      var e = this.selectComponent("#forGroup");
      e && e.showPop();
    },
    onGroupEdited: function (e) {
      this.setData({ infos: e.detail.infos }), this._storeOptions();
    },
    onFeeModePickerChange: function (e) {
      var t = this.data.configs.feeModes,
        a = parseInt(e.detail.value);
      this.setData({ "infos.feeMode": t.values[a] }), this._storeOptions();
    },
    onReceiptBeforeIntro: function () {
      (0, e.navTo)({ url: "/packageA/pages/receiptBefore/intro/intro" });
    },
    onFeeManInput: function (e) {
      this.setData({ "infos.feeMan": e.detail.value }), this._storeOptions();
    },
    onFeeWomanInput: function (e) {
      this.setData({ "infos.feeWoman": e.detail.value }), this._storeOptions();
    },
    onFeeManVipInput: function (e) {
      this.setData({ "infos.feeManVip": e.detail.value }), this._storeOptions();
    },
    onFeeWomanVipInput: function (e) {
      this.setData({ "infos.feeWomanVip": e.detail.value }),
        this._storeOptions();
    },
    onRetreatPickerChange: function (e) {
      var t = parseInt(e.detail.value);
      this.setData({ "infos.retreatTime": t }), this._storeOptions();
    },
    onSignOtherSetup: function () {
      var e = this.selectComponent("#signOtherSetup");
      e && (e.setInfos(this.data.infos), e.showPop());
    },
    onSetSignOther: function (e) {
      var t = e.detail.infos;
      this.setData({ infos: t }), this._storeOptions();
    },
    onCanSignLaterPickerChange: function (e) {
      var t = parseInt(e.detail.value);
      this.setData({
        "infos.canSignLater": this.data.configs.canSignLater.values[t],
      }),
        this._storeOptions();
    },
    onRemarksInput: function (e) {
      this.setData({ "infos.remarks": e.detail.value }), this._storeOptions();
    },
    onFullRemark: function () {
      this.selectComponent("#fullRemark").showPop();
    },
    onLimits: function () {
      this.selectComponent("#limits").showPop();
    },
    onSetLimits: function (e) {
      (0, a.mylog)("onSetLimits, e: ", e);
      var t = e.detail.infos;
      this.setData({ infos: t }), this._storeOptions();
    },
    _storeOptions: function () {
      this.setData({ showStore: !0 }),
        wx.setStorage({
          key: "activity_options",
          data: {
            clubid: this.data.infos.clubid,
            title: this.data.infos.title,
            location: this.data.infos.location,
            venue: this.data.infos.venue,
            date: this.data.infos.date,
            time: this.data.infos.time,
            figures: this.data.infos.figures,
            feeMode: this.data.infos.feeMode,
            feeMan: this.data.infos.feeMan,
            feeWoman: this.data.infos.feeWoman,
            feeManVip: this.data.infos.feeManVip,
            feeWomanVip: this.data.infos.feeWomanVip,
            retreatTime: this.data.infos.retreatTime,
            rangeType: this.data.infos.rangeType,
            signOther: this.data.infos.signOther,
            signOtherLimit: this.data.infos.signOtherLimit,
            canSignLater: this.data.infos.canSignLater,
            remarks: this.data.infos.remarks,
            isRealname: this.data.infos.isRealname,
            needPhone: this.data.infos.needPhone,
            banShare: this.data.infos.banShare,
            manLevel: this.data.infos.manLevel,
            womanLevel: this.data.infos.womanLevel,
            groups: this.data.infos.groups,
            groupCanPlayer: this.data.infos.groupCanPlayer,
            groupOnlyManager: this.data.infos.groupOnlyManager,
          },
        });
    },
    doContinueFromLogin: function () {
      this._dealRelease();
    },
    onRelease: function () {
      this._judgeOK() &&
        (n.globalData.selfInfo
          ? this._dealRelease()
          : (0, e.navTo)({ url: "/pages/login/login?action=returnext" }));
    },
    onModify: function () {
      this._judgeOK() && this._dealModify();
    },
    _judgeOK: function () {
      if (null === this.data.infos.date)
        return (
          wx.showModal({
            content: "请选择活动日期",
            showCancel: !1,
            confirmText: "好的",
          }),
          !1
        );
      if (
        !this.data.infos.time ||
        (!this.data.infos.time.endhour && 0 != this.data.infos.time.endhour)
      )
        return (
          wx.showModal({
            content: "请选择活动时间",
            showCancel: !1,
            confirmText: "好的",
          }),
          !1
        );
      if ("create" === this.data.status || "copy" === this.data.status) {
        var t = this.data.infos.date,
          n = this.data.infos.time,
          i =
            t.year +
            "/" +
            t.month +
            "/" +
            t.day +
            " " +
            n.hour +
            ":" +
            n.minute,
          o = new Date(i),
          s = o.getTime();
        (0, a.mylog)("startDate: ", o, "startMil: ", s),
          (0, a.mylog)("startTimezone: ", o.getTimezoneOffset()),
          (0, a.mylog)(
            "startTime: ",
            o.getFullYear(),
            o.getMonth() + 1,
            o.getDate()
          );
        var l = new Date(),
          r = l.getTime();
        (0, a.mylog)("nowDate: ", l, "nowMil: ", r),
          (0, a.mylog)("nowTimezone: ", l.getTimezoneOffset()),
          (0, a.mylog)(
            "nowTime: ",
            l.getFullYear(),
            l.getMonth() + 1,
            l.getDate()
          );
        var f =
            l.getFullYear() +
            "/" +
            (l.getMonth() + 1) +
            "/" +
            l.getDate() +
            " 0:0:0",
          u = new Date(f),
          d = u.getTime();
        if (
          ((0, a.mylog)("zeroDate: ", u, "zeroMil: ", d),
          (0, a.mylog)("zeroTimezone: ", u.getTimezoneOffset()),
          (0, a.mylog)(
            "zeroTime: ",
            u.getFullYear(),
            u.getMonth() + 1,
            u.getDate()
          ),
          s < d)
        )
          return (
            wx.showModal({
              content: "活动日期，不能是过去哦",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (s < r)
          return (
            wx.showModal({
              content: "活动开始时间，不能是过去哦",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
      }
      if (null === this.data.infos.location)
        return (
          wx.showModal({
            content: "请选择活动地址",
            showCancel: !1,
            confirmText: "好的",
          }),
          !1
        );
      var h = this.data.infos;
      if (
        "moreless" === h.feeMode ||
        "charge" === h.feeMode ||
        "before" === h.feeMode ||
        "offline" === h.feeMode ||
        "byself" === h.feeMode
      ) {
        if (
          !(
            ("moreless" !== h.feeMode &&
              "charge" !== h.feeMode &&
              "before" !== h.feeMode) ||
            (null !== h.feeMan && "" !== h.feeMan)
          )
        )
          return (
            wx.showModal({
              content: "请输入男费用金额",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (
          null != this.data.infos.feeMan &&
          "" != this.data.infos.feeMan &&
          isNaN(parseFloat(this.data.infos.feeMan))
        )
          return (
            wx.showModal({
              content: "男费用金额，请填写数字",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (!isNaN(parseFloat(this.data.infos.feeMan))) {
          var c = parseFloat(this.data.infos.feeMan);
          if (c > 1e3)
            return (
              wx.showModal({
                content: "男费用金额，最多1000元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
          if (c < 0.1)
            return (
              wx.showModal({
                content: "男费用金额，不能低于0.1元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
        }
        if (
          !(
            ("moreless" !== h.feeMode &&
              "charge" !== h.feeMode &&
              "before" !== h.feeMode) ||
            (null !== h.feeWoman && "" !== h.feeWoman)
          )
        )
          return (
            wx.showModal({
              content: "请输入女费用金额",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (
          null != this.data.infos.feeWoman &&
          "" != this.data.infos.feeWoman &&
          isNaN(parseFloat(this.data.infos.feeWoman))
        )
          return (
            wx.showModal({
              content: "女费用金额，请填写数字",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (!isNaN(parseFloat(this.data.infos.feeWoman))) {
          var g = parseFloat(this.data.infos.feeWoman);
          if (g > 1e3)
            return (
              wx.showModal({
                content: "女费用金额，最多1000元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
          if (g < 0.1)
            return (
              wx.showModal({
                content: "女费用金额，不能低于0.1元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
        }
      }
      var m = this.data.configs.clubs;
      if (
        ("charge" === h.feeMode || "before" === h.feeMode) &&
        "opened" === (0, e.matchWith)(m.values, h.clubid, m.vipPrices)
      ) {
        if (
          null != this.data.infos.feeManVip &&
          "" != this.data.infos.feeManVip &&
          isNaN(parseFloat(this.data.infos.feeManVip))
        )
          return (
            wx.showModal({
              content: "男VIP金额，请填写数字",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (!isNaN(parseFloat(this.data.infos.feeManVip))) {
          var p = parseFloat(this.data.infos.feeManVip);
          if (p > 1e3)
            return (
              wx.showModal({
                content: "男VIP金额，最多1000元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
          if (p < 0.1)
            return (
              wx.showModal({
                content: "男VIP金额，不能低于0.1元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
        }
        if (
          null != this.data.infos.feeWomanVip &&
          "" != this.data.infos.feeWomanVip &&
          isNaN(parseFloat(this.data.infos.feeWomanVip))
        )
          return (
            wx.showModal({
              content: "女VIP金额，请填写数字",
              showCancel: !1,
              confirmText: "好的",
            }),
            !1
          );
        if (!isNaN(parseFloat(this.data.infos.feeWomanVip))) {
          var v = parseFloat(this.data.infos.feeWomanVip);
          if (v > 1e3)
            return (
              wx.showModal({
                content: "女VIP金额，最多1000元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
          if (v < 0.1)
            return (
              wx.showModal({
                content: "女VIP金额，不能低于0.1元",
                showCancel: !1,
                confirmText: "好的",
              }),
              !1
            );
        }
      }
      return !0;
    },
    _dealRelease: function () {
      var t = this;
      wx.showLoading({ title: "发布中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "create",
            activityInfo: {
              classify: this.data.classify,
              mode: this.data.mode,
              infos: this._getInfos(),
              timezone: (0, e.getTimezoneOff)(),
            },
            isDebug: n.globalData.isDebug,
            version: n.globalData.frontVersion,
          },
          success: function (e) {
            n.globalData.isConsoleLog && console.log("create activity: ", e),
              "fail" === e.result.type
                ? (wx.hideLoading(),
                  wx.showModal({
                    content: e.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }))
                : t.triggerEvent("create", { id: e.result._id }, {});
          },
          fail: function (t) {
            n.globalData.isConsoleLog &&
              console.log("create activity err: ", t),
              (0, e.networkFail)(!1, t, "activity.create");
          },
          complete: function (e) {
            t.setData({ isReleasing: !1 });
          },
        });
    },
    _getInfos: function () {
      var e = {
        clubid: this.data.infos.clubid,
        title: this.data.infos.title,
        location: this.data.infos.location,
        venue: this.data.infos.venue,
        date: this.data.infos.date,
        time: this.data.infos.time,
        figures: parseInt(this.data.infos.figures),
        feeMode: this.data.infos.feeMode,
        feeMan:
          "free" === this.data.infos.feeMode
            ? 0
            : parseFloat(parseFloat(this.data.infos.feeMan).toFixed(2)),
        feeWoman:
          "free" === this.data.infos.feeMode
            ? 0
            : parseFloat(parseFloat(this.data.infos.feeWoman).toFixed(2)),
        feeManVip:
          "free" === this.data.infos.feeMode
            ? 0
            : parseFloat(parseFloat(this.data.infos.feeManVip).toFixed(2)),
        feeWomanVip:
          "free" === this.data.infos.feeMode
            ? 0
            : parseFloat(parseFloat(this.data.infos.feeWomanVip).toFixed(2)),
        retreatTime: this.data.infos.retreatTime,
        rangeType: this.data.infos.rangeType,
        signOther: this.data.infos.signOther,
        signOtherLimit: this.data.infos.signOtherLimit,
        canSignLater: this.data.infos.canSignLater,
        remarks: this.data.infos.remarks.trim(),
        isRealname: this.data.infos.isRealname,
        needPhone: this.data.infos.needPhone,
        banShare: this.data.infos.banShare,
        manLevel: this.data.infos.manLevel,
        womanLevel: this.data.infos.womanLevel,
        groups: this.data.infos.groups,
        groupCanPlayer: this.data.infos.groupCanPlayer,
        groupOnlyManager: this.data.infos.groupOnlyManager,
      };
      if (
        ("create" === this.data.status || "copy" === this.data.status) &&
        e.groups
      )
        for (var t = 0; t < e.groups.length; t++) e.groups[t].crtPerson = 0;
      return n.globalData.isConsoleLog && console.log("infos: ", e), e;
    },
    _dealModify: function () {
      var t = this;
      wx.showLoading({ title: "修改中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modify",
            activityid: this.data.activityid,
            infos: this._getInfos(),
            timezone: (0, e.getTimezoneOff)(),
            isDebug: n.globalData.isDebug,
            version: n.globalData.frontVersion,
          },
          success: function (e) {
            n.globalData.isConsoleLog && console.log("modify activity: ", e),
              "fail" === e.result.type
                ? (wx.hideLoading(),
                  wx.showModal({
                    content: e.result.msg,
                    showCancel: !1,
                    confirmText: "好的",
                  }))
                : t.triggerEvent("modify", {}, {});
          },
          fail: function (t) {
            n.globalData.isConsoleLog &&
              console.log("modify activity err: ", t),
              (0, e.networkFail)(!1, t, "activity.modify");
          },
        });
    },
  },
});
