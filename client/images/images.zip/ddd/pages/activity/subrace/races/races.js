var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../4528E4C36B9DF5DF234E8CC44FF455F2.js"),
  a = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = getApp();
Component({
  properties: {
    activity: { type: Object, value: "" },
    selfid: { type: String, value: "" },
    crtType: { type: String, value: "" },
  },
  data: {
    navInfo: (0, e.getNavInfo)(),
    raceConfig: (0, t.getMultiConfig)(),
    subraces: [],
    isAlready: !1,
    crtTimeMil: new Date().getTime(),
  },
  observers: {
    activity: function () {
      this.setData({ crtTimeMil: new Date().getTime() });
    },
  },
  pageLifetimes: {
    show: function () {
      "subrace" === this.data.crtType && this.getActivitySubRaces();
    },
  },
  methods: {
    onAddSubRace: function () {
      (0, e.navTo)({
        url: "/pages/activity/subrace/addsub/addSubRace?from=activityMain",
      });
    },
    getActivitySubRaces: function () {
      var e = this;
      (!this.data.isAlready || this.data.subraces.length <= 0) &&
        this.triggerEvent("loading", { isLoading: !0 }, {});
      var t = {
        fun: "getActSubRaces",
        activityid: this.data.activity._id,
        isDebug: i.globalData.isDebug,
        version: i.globalData.frontVersion,
      };
      i.globalData.userOpenId &&
        (t.userInfo = { openId: i.globalData.userOpenId }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: t,
          success: function (t) {
            (0, a.mylog)("getActSubRaces: ", t),
              null === t.result.list
                ? e.setData({ subraces: [], isAlready: !0 })
                : e.setData({ subraces: t.result.list, isAlready: !0 }),
              wx.hideLoading();
          },
          fail: function (e) {
            (0, a.mylog)("getActSubRaces err: ", e);
          },
          complete: function (t) {
            e.setData({ triggered: !1 }),
              e.triggerEvent("loading", { isLoading: !1 }, {});
          },
        });
    },
    onRace: function (t) {
      (0, e.navTo)({
        url:
          "/packageC/pages/multiRace/multiRace?raceid=" +
          t.currentTarget.dataset.raceid,
      });
    },
    onRefresh: function () {
      this.getActivitySubRaces();
    },
  },
});
