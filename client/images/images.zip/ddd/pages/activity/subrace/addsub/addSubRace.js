var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  s = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  o = getApp();
Page({
  behaviors: [s],
  data: {
    pageType: "addSubRace",
    navInfo: (0, e.getNavInfo)(),
    activityid: "",
    activity: "",
    selfid: "",
    retreatPlayer: "",
    listType: "all",
    genderType: -1,
    otherChoosed: !1,
    hideJoined: !1,
    chooseList: [],
    choosedMan: 0,
    choosedWoman: 0,
    allChoosed: !1,
    toTop: !1,
    isDebug: o.globalData.isDebug,
  },
  onLoad: function (e) {
    e.from &&
      o.globalData.activityInfo.crtActivity &&
      (this.setData({
        activityid: o.globalData.activityInfo.crtActivity._id,
        activity: o.globalData.activityInfo.crtActivity,
        selfid: o.globalData.selfid,
        players: o.globalData.activityInfo.crtPlayers,
      }),
      this._dealRoles(this.data.players));
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {
    (0, t.mylog)("addSubRace onUnload"), this._dealRoles(this.data.players);
  },
  onRefresh: function () {
    this._getActivityPlayers(),
      this.setData({
        chooseList: [],
        choosedMan: 0,
        choosedWoman: 0,
        allChoosed: !1,
      });
  },
  onOrderPickerChange: function (e) {
    var t = this.data.orderConfig,
      s = parseInt(e.detail.value);
    this.setData({ crtOrder: t.values[s], toTop: !0 });
  },
  onGenderMan: function () {
    this.setData({ genderType: 1 }), this._calChooseList();
  },
  onGenderWoman: function () {
    this.setData({ genderType: 2 }), this._calChooseList();
  },
  onGenderUnknow: function () {
    this.setData({ genderType: 0 }), this._calChooseList();
  },
  onHideJoined: function () {
    this.data.hideJoined
      ? this.setData({ hideJoined: !1 })
      : this.setData({ hideJoined: !0 }),
      this._countGenders(),
      this._calChooseList();
  },
  onGenderRestore: function () {
    this.setData({ genderType: -1 }), this._calChooseList();
  },
  onReturnAll: function () {
    this.setData({ hideJoined: !1, genderType: -1 }),
      this._countGenders(),
      this._calChooseList();
  },
  _countGenders: function () {
    for (
      var e = this.data.signed,
        t = 0,
        s = 0,
        o = 0,
        a = this.data.hideJoined,
        i = 0;
      i < e.length;
      i++
    ) {
      var r = e[i];
      (!a || (a && !r._subRaceCnt)) &&
        (1 === r.gender ? t++ : 2 === r.gender ? s++ : o++);
    }
    this.setData({ manCnt: t, womanCnt: s, nogender: o });
  },
  onChoose: function (e) {
    var s = e.currentTarget.dataset.player._id;
    (0, t.mylog)("id: ", s);
    var o = this._setChoose(this.data.signed, s),
      a = this._setChoose(this.data.smart, s),
      i = this._setChoose(this.data.levels, s),
      r = this._setChoose(this.data.byremarks, s),
      h = this._setChooseForGroups(this.data.groupList, s);
    this.setData({
      signed: o,
      smart: a,
      levels: i,
      byremarks: r,
      groupList: h,
    }),
      this._judgeChoosedOther(),
      this._calChooseList();
  },
  _setChoose: function (e, t) {
    for (var s = [], o = 0; o < e.length; o++) {
      var a = e[o];
      (a._id !== t && t) ||
        ((a = JSON.parse(JSON.stringify(e[o]))).choosed
          ? (a.choosed = !1)
          : (a.choosed = !0)),
        s.push(a);
    }
    return s;
  },
  _setChooseForGroups: function (e, t) {
    if (!e) return null;
    for (var s = 0; s < e.length; s++)
      for (var o = e[s], a = 0; a < o.players.length; a++) {
        var i = o.players[a];
        if (i._id === t) {
          if (i.choosed) (i.choosed = !1), (o.choosed = !1);
          else {
            i.choosed = !0;
            for (var r = !0, h = 0; h < o.players.length; h++)
              if (!o.players[h].choosed) {
                r = !1;
                break;
              }
            o.choosed = r;
          }
          break;
        }
      }
    return e;
  },
  onGroupAll: function (e) {
    var s = e.currentTarget.dataset.index;
    (0, t.mylog)("onGroupAll, index", s);
    for (
      var o = this.data.signed,
        a = this.data.smart,
        i = this.data.levels,
        r = this.data.byremarks,
        h = this.data.groupList,
        n = 0;
      n < h.length;
      n++
    )
      if (n === s) {
        var d = h[n];
        d.choosed ? (d.choosed = !1) : (d.choosed = !0);
        for (var l = d.players, c = 0; c < l.length; c++) {
          var g = l[c];
          (g.choosed = d.choosed),
            (o = this._changeChoose(this.data.signed, g._id, d.choosed)),
            (a = this._changeChoose(this.data.smart, g._id, d.choosed)),
            (i = this._changeChoose(this.data.levels, g._id, d.choosed)),
            (r = this._changeChoose(this.data.byremarks, g._id, d.choosed));
        }
      }
    this.setData({
      signed: o,
      smart: a,
      levels: i,
      byremarks: r,
      groupList: h,
    }),
      this._judgeChoosedOther(),
      this._calChooseList();
  },
  _changeChoose: function (e, t, s) {
    for (var o = 0; o < e.length; o++) {
      var a = e[o];
      if (a._id === t) {
        a.choosed = s;
        break;
      }
    }
    return e;
  },
  onAllChoose: function () {
    var e = this.data.allChoosed;
    e = !e;
    var t = this._allChoose(this.data.signed, e),
      s = this._allChoose(this.data.smart, e),
      o = this._allChoose(this.data.levels, e),
      a = this._allChoose(this.data.byremarks, e),
      i = this._allChooseForGroups(this.data.groupList, e);
    this.setData({
      signed: t,
      smart: s,
      levels: o,
      byremarks: a,
      groupList: i,
      allChoosed: e,
    }),
      this._judgeChoosedOther(),
      this._calChooseList();
  },
  _allChoose: function (e, t) {
    for (var s = 0; s < e.length; s++) e[s].choosed = t;
    return e;
  },
  _allChooseForGroups: function (e, t) {
    if (!e) return null;
    for (var s = 0; s < e.length; s++) {
      var o = e[s];
      o.choosed = t;
      for (var a = o.players, i = 0; i < a.length; i++) a[i].choosed = t;
    }
    return e;
  },
  _judgeChoosedOther: function () {
    for (var e = !1, t = this.data.signed, s = 0; s < t.length; s++)
      if (t[s].choosed && "other" === t[s]._signType) {
        e = !0;
        break;
      }
    this.setData({ otherChoosed: e });
  },
  _calChooseList: function () {
    for (
      var e = [],
        t = this.data.signed,
        s = this.data.hideJoined,
        o = this.data.genderType,
        a = 0;
      a < t.length;
      a++
    ) {
      var i = t[a];
      i.choosed &&
        ((!s && -1 === o) ||
          (s && -1 === o && !i._subRaceCnt) ||
          (!s && -1 != o && o === i.gender) ||
          (s && -1 != o && o === i.gender && !i._subRaceCnt)) &&
        e.push(t[a]);
    }
    for (var r = 0, h = 0, n = 0; n < e.length; n++) {
      var d = e[n];
      1 === d.gender ? r++ : 2 === d.gender ? h++ : 0;
    }
    for (var l = !0, c = 0; c < t.length; c++)
      if (!t[c].choosed) {
        l = !1;
        break;
      }
    this.setData({
      chooseList: e,
      choosedMan: r,
      choosedWoman: h,
      allChoosed: l,
    });
  },
  onNext: function () {
    if ("group" === this.data.crtOrder) var e = this._dealChooseListByGroup();
    else e = this._dealChooseList();
    e.list.length <= 0
      ? wx.showToast({ title: "请选择子比赛选手", icon: "none", duration: 2e3 })
      : (this.selectComponent("#subPop").setChooseList(e),
        this.selectComponent("#subPop").showPop());
  },
  _dealChooseList: function () {
    var e = [],
      t = this.data.smart;
    switch (this.data.crtOrder) {
      case "smart":
        t = this.data.smart;
        break;
      case "bytime":
        t = this.data.signed;
        break;
      case "bylevel":
        t = this.data.levels;
        break;
      case "byremark":
        t = this.data.byremarks;
    }
    for (
      var s = this.data.hideJoined, o = this.data.genderType, a = 0;
      a < t.length;
      a++
    ) {
      var i = t[a];
      i.choosed &&
        ((!s && -1 === o) ||
          (s && -1 === o && !i._subRaceCnt) ||
          (!s && -1 != o && o === i.gender) ||
          (s && -1 != o && o === i.gender && !i._subRaceCnt)) &&
        e.push(t[a]);
    }
    return { orderType: this.data.crtOrder, list: e };
  },
  _dealChooseListByGroup: function () {
    for (
      var e = [],
        t = [],
        s = this.data.groupList,
        o = this.data.hideJoined,
        a = this.data.genderType,
        i = 0;
      i < s.length;
      i++
    ) {
      var r = s[i].players;
      if (r.length > 0) {
        for (var h = { groupNo: i, players: [] }, n = 0; n < r.length; n++) {
          var d = r[n];
          d.choosed &&
            ((!o && -1 === a) ||
              (o && -1 === a && !d._subRaceCnt) ||
              (!o && -1 != a && a === d.gender) ||
              (o && -1 != a && a === d.gender && !d._subRaceCnt)) &&
            (e.push(d), h.players.push(d));
        }
        h.players.length > 0 && t.push(h);
      }
    }
    return { orderType: this.data.crtOrder, groups: t, list: e };
  },
});
