var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  s = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  i = getApp();
Component({
  behaviors: [t],
  properties: { activity: { type: Object, value: "" } },
  data: {
    chooseList: [],
    groups: "",
    orderType: "",
    title: "",
    classify: "doubles",
    former: "bynow",
  },
  methods: {
    setChooseList: function (e) {
      (0, s.mylog)("paras: ", e),
        this.setData({
          orderType: e.orderType,
          chooseList: e.list,
          groups: e.groups,
        });
    },
    onClassifyDoubles: function () {
      this.setData({ classify: "doubles" });
    },
    onClassifySingles: function () {
      this.setData({ classify: "singles" });
    },
    onClassifyMatches: function () {
      this.setData({ classify: "matches" });
    },
    onTitleInput: function (e) {
      this.setData({ title: e.detail.value });
    },
    onFormerBynow: function () {
      this.setData({ former: "bynow" });
    },
    onFormerEnlist: function () {
      this.setData({ former: "enlist" });
    },
    onConfirm: function () {
      var t = this;
      if (this._judgeOK()) {
        var r = "";
        this.data.title && (r = this.data.title.trim());
        var o = this._dealOpenids(),
          n = this.data.chooseList,
          l = this.data.activity._infos,
          c = (0, a.chooseListNames)(l, n),
          d = o.raceOpenids.length,
          u = d < 4 ? 4 : d;
        switch (this.data.classify) {
          case "doubles":
            u = d < 4 ? 4 : d;
            break;
          case "singles":
            u = d < 2 ? 2 : d;
            break;
          case "matches":
            u = d < 4 ? 4 : d;
        }
        if ("matches" === this.data.classify) {
          u = Math.round(u / 2);
          var h = this._maxLen() / 2;
          if (u > h)
            return void wx.showModal({
              content:
                "对抗赛每队选手不超过" +
                h +
                "人哦，请重新勾选名单，或者切换为其他比赛类型",
              showCancel: !1,
              confirmText: "好的",
            });
        }
        var m = "nolimitDoubles";
        "singles" === this.data.classify && (m = "nolimitSingles");
        var p = "eight";
        switch (this.data.classify) {
          case "singles":
            p = "singlesRound";
            break;
          case "matches":
            p = "teamRound";
        }
        var f = this._dealTeamName(),
          g = {
            former: "bynow",
            clubid: l.clubid,
            title: r,
            mode: p,
            type: m,
            partnerMode: "random",
            groups: u,
            rounds: 1,
            balls: 21,
            venue: "",
            remarks: c,
            teamNames: f,
            playerCanbeReferee: !0,
            isRealname: l.isRealname,
          };
        "enlist" === this.data.former &&
          (g = {
            former: "enlist",
            clubid: l.clubid,
            title: r,
            mode: p,
            type: m,
            partnerMode: "random",
            groups: u,
            rounds: 1,
            balls: 21,
            location: l.location,
            venue: "",
            date: l.date,
            time: l.time,
            banShare: l.banShare,
            manLevel: l.manLevel,
            womanLevel: l.womanLevel,
            feeMode: "AAafter",
            remarks: c,
            teamNames: f,
            playerCanbeReferee: !0,
            isRealname: l.isRealname,
          }),
          wx.showLoading({ title: "添加中", mask: !0 }),
          wx.cloud.callFunction({
            name: "multiRace",
            data: {
              fun: "createActSubRace_2",
              activityid: this.data.activity._id,
              raceInfo: {
                classify: "actSub",
                infos: g,
                raceOpenids: o.raceOpenids,
                actPlayerids: o.actPlayerids,
              },
              isDebug: i.globalData.isDebug,
              version: i.globalData.frontVersion,
            },
            success: function (e) {
              (0, s.mylog)("createActSubRace_2: ", e),
                "fail" === e.result.type
                  ? (wx.hideLoading(),
                    wx.showModal({
                      content: e.result.msg,
                      showCancel: !1,
                      confirmText: "好的",
                    }))
                  : (wx.redirectTo({
                      url:
                        "/packageC/pages/multiRace/multiRace?raceid=" +
                        e.result._id,
                    }),
                    t.closeAnimate());
            },
            fail: function (a) {
              (0, s.mylog)("createActSubRace_2 err: ", a),
                (0, e.networkFail)(!1, a, "multiRace.createActSubRace_2");
            },
          });
      }
    },
    _judgeOK: function () {
      if (
        "matches" === this.data.classify &&
        "group" === this.data.orderType &&
        this.data.groups.length > 2
      )
        return (
          wx.showModal({
            content:
              "对抗赛只支持2个分组哦，请重新勾选名单，或者切换为其他比赛类型",
            showCancel: !1,
            confirmText: "好的",
          }),
          !1
        );
      var e = this.data.chooseList.length,
        a = this._maxLen();
      return (
        !(e > a) ||
        (wx.showModal({
          content:
            "选手人数不能超过" +
            a +
            "人哦，请重新勾选名单，或者切换为其他比赛类型",
          showCancel: !1,
          confirmText: "好的",
        }),
        !1)
      );
    },
    _maxLen: function () {
      switch (this.data.classify) {
        case "doubles":
          return 50;
        case "singles":
          return 20;
        case "matches":
          return 40;
      }
      return 50;
    },
    _dealOpenids: function () {
      var e = [],
        a = [],
        s = this.data.chooseList;
      if (
        "matches" === this.data.classify &&
        "group" === this.data.orderType &&
        2 === this.data.groups.length
      ) {
        var t = this.data.groups,
          i = this._dealOpenidsComm(t[0].players),
          r = this._dealOpenidsComm(t[1].players);
        a = (a = i.actPlayerids).concat(r.actPlayerids);
        var o = i.raceOpenids.length,
          n = r.raceOpenids.length;
        if (o < n) for (var l = 0; l < n - o; l++) i.raceOpenids.push(null);
        else for (var c = 0; c < o - n; c++) r.raceOpenids.push(null);
        e = (e = i.raceOpenids).concat(r.raceOpenids);
      } else {
        var d = this._dealOpenidsComm(s);
        (a = d.actPlayerids), (e = d.raceOpenids);
      }
      return { actPlayerids: a, raceOpenids: e };
    },
    _dealOpenidsComm: function (e) {
      for (var a = [], s = [], t = 0; t < e.length; t++) {
        var i = e[t];
        s.push(i._id),
          "self" === i._signType ? a.push(i._playerid) : a.push(null);
      }
      return { actPlayerids: s, raceOpenids: a };
    },
    _dealTeamName: function () {
      var e = ["A队", "B队"];
      if (
        "matches" === this.data.classify &&
        "group" === this.data.orderType &&
        2 === this.data.groups.length
      ) {
        var t = this.data.groups,
          i = this.data.activity._infos;
        if (i.groups) {
          var r = t[0].groupNo,
            o = t[1].groupNo;
          (0, s.mylog)(
            "noA: ",
            r,
            "noB: ",
            o,
            "infos.groups.length: ",
            i.groups.length
          ),
            i.groups.length > r
              ? i.groups[r].name
                ? (e[0] = i.groups[r].name)
                : (e[0] = (0, a.numToAZ)(r + 1) + "队")
              : (e[0] = "未命名队" + (r + 1)),
            i.groups.length > o
              ? i.groups[o].name
                ? (e[1] = i.groups[o].name)
                : (e[1] = (0, a.numToAZ)(o + 1) + "队")
              : (e[1] = "未命名队" + (o + 1));
        }
      }
      return e;
    },
  },
});
