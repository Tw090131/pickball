var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../53A84DB56B9DF5DF35CE25B2A0F455F2.js"),
  e = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  n = getApp();
Component({
  properties: {
    activity: { type: Object, value: "" },
    selfid: { type: String, value: "" },
    crtType: { type: String, value: "" },
  },
  data: {
    navInfo: (0, t.getNavInfo)(),
    srcOptions: (0, a.getBattleConfig)(),
    rank: [],
    isAlready: !1,
  },
  pageLifetimes: {
    show: function () {
      "totalrank" === this.data.crtType && this.getTotalRank();
    },
  },
  methods: {
    getTotalRank: function () {
      var a = this;
      (!this.data.isAlready || this.data.rank.length <= 0) &&
        this.triggerEvent("loading", { isLoading: !0 }, {});
      var i = {
        fun: "getActTotalRanks",
        activityid: this.data.activity._id,
        clubid: this.data.activity._infos.clubid,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      };
      n.globalData.userOpenId &&
        (i.userInfo = { openId: n.globalData.userOpenId }),
        wx.cloud.callFunction({
          name: "multiRace",
          data: i,
          success: function (t) {
            (0, e.mylog)("getActTotalRanks res: ", t);
            var n = t.result.ranks.sort(function (t, a) {
              return a._rate.netball - t._rate.netball;
            });
            (n = (n = (n = (n = (n = n.sort(function (t, a) {
              return a._rate.net - t._rate.net;
            })).sort(function (t, a) {
              return a._rate.alls - t._rate.alls;
            })).sort(function (t, a) {
              return a._netball - t._netball;
            })).sort(function (t, a) {
              return a._wins - t._wins;
            })).sort(function (t, a) {
              return a._point - t._point;
            })),
              a.setData({ rank: n, isAlready: !0 });
          },
          fail: function (a) {
            (0, e.mylog)("getActTotalRanks fail: ", a),
              (0, t.networkFail)(!1, a, "multiRace.getActTotalRanks");
          },
          complete: function (t) {
            a.setData({ triggered: !1 }),
              a.triggerEvent("loading", { isLoading: !1 }, {});
          },
        });
    },
    onRefresh: function () {
      this.getTotalRank();
    },
    onMember: function (a) {
      (0, e.mylog)("onMember, e: ", a);
      var n = this.data.activity,
        i = a.currentTarget.dataset.user;
      (i._playerid = i._openid), (0, t.multiRacePlayer)(n, i);
    },
  },
});
