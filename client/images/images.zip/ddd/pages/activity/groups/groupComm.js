var t = require("../../../88EDE3756B9DF5DFEE8B8B72923555F2.js"),
  a = getApp();
module.exports = Behavior({
  data: {},
  methods: {
    _checkVipfun: function () {
      var i = a.globalData.selfInfo,
        e = this.data.activity.crtMil;
      if (i && i.trustLevel >= 4 && i.trustDueMil > e) return !0;
      var s = this.data.activity;
      s.isPlayer = this.data.isActPlayer;
      var r = (0, t.raceRole)(this.data.selfid, s);
      a.globalData.payVipfunInfo.payAt = {
        kind: "activity",
        from: this.data.pageType,
        actid: this.data.activity._id,
        role: r,
      };
      var o = this.selectComponent("#payVisit");
      return o && (o.setRole(r), o.showPop()), !1;
    },
  },
});
