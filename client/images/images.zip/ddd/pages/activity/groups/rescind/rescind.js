var o = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  a = require("../groupComm.js"),
  i = getApp();
Page({
  behaviors: [e, a],
  data: {
    pageType: "groupsRescind",
    navInfo: (0, o.getNavInfo)(),
    activityid: "",
    activity: "",
    selfid: "",
    chooseList: [],
    choosedMan: 0,
    choosedWoman: 0,
    allChoosed: !1,
    isDebug: i.globalData.isDebug,
  },
  onLoad: function (t) {
    i.globalData.activityInfo.crtActivity &&
      (this.setData({
        activityid: i.globalData.activityInfo.crtActivity._id,
        activity: i.globalData.activityInfo.crtActivity,
        selfid: i.globalData.selfid,
        players: (0, o.copyArr)(i.globalData.activityInfo.crtPlayers),
      }),
      this._dealRoles(this.data.players),
      this._calChooseList());
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {},
  onRefresh: function () {
    this._getActivityPlayers(),
      this.setData({
        chooseList: [],
        choosedMan: 0,
        choosedWoman: 0,
        allChoosed: !1,
      });
  },
  onChoose: function (o) {
    if (this.data.chooseList.length >= 100)
      wx.showToast({ title: "一次操作不要超过100人哦", icon: "none" });
    else {
      var t = o.currentTarget.dataset.player._id,
        e = this._setChooseForGroups(this.data.groupList, t);
      this.setData({ groupList: e }), this._calChooseList();
    }
  },
  _setChooseForGroups: function (o, t) {
    if (!o) return null;
    for (var e = 0; e < o.length; e++)
      for (var a = o[e], i = 0; i < a.players.length; i++) {
        var s = a.players[i];
        if (s._id === t) {
          if (s.checked) (s.checked = !1), (a.choosed = !1);
          else {
            s.checked = !0;
            for (var n = !0, r = 0; r < a.players.length; r++)
              if (!a.players[r].checked) {
                n = !1;
                break;
              }
            a.choosed = n;
          }
          break;
        }
      }
    return o;
  },
  onGroupAll: function (o) {
    var e = o.currentTarget.dataset.index;
    (0, t.mylog)("onGroupAll, index", e);
    for (var a = this.data.groupList, i = 0; i < a.length; i++)
      if (i === e) {
        var s = a[i];
        s.choosed ? (s.choosed = !1) : (s.choosed = !0);
        for (var n = s.players, r = 0; r < n.length; r++)
          n[r]._groupNo > 0 ? (n[r].checked = s.choosed) : (n[r].checked = !1);
      }
    this.setData({ groupList: a }), this._calChooseList();
  },
  _calChooseList: function () {
    var o = [],
      t = this.data.groupList;
    if (t && !(t.length <= 0)) {
      for (var e = 0; e < t.length; e++)
        for (var a = t[e].players, i = 0; i < a.length; i++) {
          a[i].checked && o.push(a[i]);
        }
      for (var s = 0, n = 0, r = 0; r < o.length; r++) {
        var c = o[r];
        1 === c.gender ? s++ : 2 === c.gender ? n++ : 0;
      }
      for (var l = !0, h = 0; h < t.length; h++) {
        a = t[h].players;
        for (var d = 0; d < a.length; d++)
          if (a[d]._groupNo > 0 && !a[d].checked) {
            l = !1;
            break;
          }
        if (!l) break;
      }
      this.setData({
        chooseList: o,
        choosedMan: s,
        choosedWoman: n,
        allChoosed: l,
      });
    }
  },
  onAllChoosed: function () {
    var o = this.data.allChoosed;
    o = !o;
    for (var t = this.data.groupList, e = 0; e < t.length; e++) {
      var a = t[e];
      a.choosed = o;
      for (var i = a.players, s = 0; s < i.length; s++)
        i[s]._groupNo > 0 ? (i[s].checked = o) : (i[s].checked = !1);
    }
    this.setData({ allChoosed: o, groupList: t }), this._calChooseList();
  },
  onConfirm: function () {
    var o = this,
      e = this.data.chooseList;
    if (((0, t.mylog)("onConfirm, chooseList: ", e), e.length <= 0))
      wx.showToast({
        title: "请选择需取消分组的报名",
        icon: "none",
        duration: 3e3,
      });
    else if (e.length >= 100)
      wx.showModal({
        content: "一次操作人数不要超过100人哦",
        showCancel: !1,
        confirmText: "好的",
      });
    else if (this._checkVipfun()) {
      var a = this.data.choosedMan,
        i = this.data.choosedWoman;
      wx.showModal({
        content: "已选报名共" + (a + i) + "个，将取消它们的分组，是否继续？",
        cancelText: "暂不",
        confirmText: "确定",
        complete: function (t) {
          t.cancel || (t.confirm && o._dealGroupRescind());
        },
      });
    }
  },
  _dealGroupRescind: function () {
    var e = this,
      a = this.data.chooseList;
    wx.showLoading({ title: "取消分组中", mask: !0 }),
      wx.cloud.callFunction({
        name: "activity",
        data: {
          fun: "rescindGroup",
          activityid: this.data.activity._id,
          choosedList: a,
          isDebug: i.globalData.isDebug,
          version: i.globalData.frontVersion,
        },
        success: function (o) {
          (0, t.mylog)("rescindGroup, res: ", o),
            "fail" === o.result.type
              ? (wx.hideLoading(),
                wx.showModal({
                  content: o.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                }))
              : ((i.globalData.activityInfo.groupChanged = !0), e.onRefresh());
        },
        fail: function (e) {
          (0, t.mylog)("rescindGroup, err: ", e),
            (0, o.networkFail)(!1, e, "activity.rescindGroup");
        },
      });
  },
});
