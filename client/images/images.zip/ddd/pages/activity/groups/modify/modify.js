var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  o = require("../../../../051A88476B9DF5DF637CE0402F9455F2.js"),
  a = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  i = getApp();
Page({
  behaviors: [o, a],
  data: {
    pageType: "groupsModify",
    navInfo: (0, t.getNavInfo)(),
    activityid: "",
    activity: "",
    selfid: "",
    chooseList: [],
    choosedMan: 0,
    choosedWoman: 0,
    isDebug: i.globalData.isDebug,
  },
  onLoad: function (o) {
    i.globalData.activityInfo.crtActivity &&
      (this.setData({
        activityid: i.globalData.activityInfo.crtActivity._id,
        activity: i.globalData.activityInfo.crtActivity,
        selfid: i.globalData.selfid,
        players: (0, t.copyArr)(i.globalData.activityInfo.crtPlayers),
      }),
      this._dealRoles(this.data.players),
      this._calChooseList());
  },
  onReady: function () {},
  onShow: function () {
    i.globalData.activityInfo.groupManaged &&
      ((i.globalData.activityInfo.groupManaged = !1),
      this.setData({ activity: i.globalData.activityInfo.crtActivity }));
  },
  onHide: function () {},
  onUnload: function () {},
  onRefresh: function () {
    this._getActivity(),
      this._getActivityPlayers(),
      this.setData({ chooseList: [], choosedMan: 0, choosedWoman: 0 });
  },
  onChoose: function (t) {
    if (this.data.chooseList.length >= 20)
      wx.showToast({ title: "一次修改不超过20人哦", icon: "none" });
    else {
      var o = t.currentTarget.dataset.player._id,
        a = this._setChooseForGroups(this.data.groupList, o);
      this.setData({ groupList: a }), this._calChooseList();
    }
  },
  _setChooseForGroups: function (t, o) {
    if (!t) return null;
    for (var a = 0; a < t.length; a++)
      for (var i = t[a], e = 0; e < i.players.length; e++) {
        var s = i.players[e];
        if (s._id === o) {
          s.checked ? (s.checked = !1) : (s.checked = !0);
          break;
        }
      }
    return t;
  },
  _calChooseList: function () {
    var t = [],
      o = this.data.groupList;
    if (o && !(o.length <= 0)) {
      for (var a = 0; a < o.length; a++)
        for (var i = o[a].players, e = 0; e < i.length; e++) {
          i[e].checked && t.push(i[e]);
        }
      for (var s = 0, n = 0, c = 0; c < t.length; c++) {
        var r = t[c];
        1 === r.gender ? s++ : 2 === r.gender ? n++ : 0;
      }
      this.setData({ chooseList: t, choosedMan: s, choosedWoman: n });
    }
  },
  onGroupManage: function (t) {
    var o = t.currentTarget.dataset.index,
      a = this.selectComponent("#changeName");
    a && a.init(o) && a.showPop();
  },
  onConfirm: function () {
    var t = this.data.chooseList;
    if (t.length <= 0)
      wx.showToast({
        title: "请选择需修改分组的报名",
        icon: "none",
        duration: 3e3,
      });
    else if (t.length >= 20)
      wx.showModal({
        content: "一次修改不超过20人哦",
        showCancel: !1,
        confirmText: "好的",
      });
    else {
      var o = this.selectComponent("#forGroups");
      o && (o.init({ choosedList: t }), o.showPop());
    }
  },
  onGroupModified: function () {
    this.setData({ activity: i.globalData.activityInfo.crtActivity }),
      this.onRefresh();
  },
});
