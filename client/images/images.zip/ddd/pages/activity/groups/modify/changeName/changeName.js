var t = require("../../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = getApp(),
  o = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [o],
  properties: { activity: { type: Object, value: "" } },
  data: { groups: [], groupIndex: "", srcGroupName: "", crtGroupName: "" },
  methods: {
    init: function (a) {
      a = parseInt(a);
      var e = this.data.activity._infos.groups;
      if (a > e.length - 1)
        return (
          wx.showModal({
            content: "当前分组未知，请先添加足够数量的分组",
            cancelText: "暂不",
            confirmText: "+分组",
            complete: function (e) {
              e.cancel ||
                (e.confirm &&
                  (0, t.navTo)({
                    url: "/pages/activity/groups/manage/manage?index=" + a,
                  }));
            },
          }),
          !1
        );
      var o = e[a].name;
      return (
        this.setData({ srcGroupName: o, crtGroupName: o, groupIndex: a }), !0
      );
    },
    onGroupNameInput: function (t) {
      this.setData({ crtGroupName: t.detail.value });
    },
    onGroupNameRecover: function () {
      this.setData({ crtGroupName: this.data.srcGroupName });
    },
    onGroupNameClear: function () {
      this.setData({ crtGroupName: "" });
    },
    onGroupNameModify: function () {
      var o = this;
      wx.showLoading({ title: "修改中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifyGroupName",
            activityid: this.data.activity._id,
            groupIndex: this.data.groupIndex,
            groupName: this.data.crtGroupName.trim(),
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (t) {
            if (
              ((0, a.mylog)("modifyGroupName, res: ", t),
              "fail" === t.result.type)
            )
              wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              o.triggerEvent("groupNameModified", {}, {}), o.closeAnimate();
              var i = o.data.activity._infos.groups;
              (i[o.data.groupIndex].name = o.data.crtGroupName),
                (e.globalData.activityInfo.crtActivity._infos.groups = i);
            }
          },
          fail: function (e) {
            (0, a.mylog)("modifyGroupName, err: ", e),
              (0, t.networkFail)(!1, e, "activity.modifyGroupName");
          },
        });
    },
  },
});
