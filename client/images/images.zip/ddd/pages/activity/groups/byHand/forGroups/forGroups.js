var t = require("../../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  e = require("../../../../../402DB5626B9DF5DF264BDD6567B455F2.js"),
  i = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  o = require("../../groupComm.js"),
  r = getApp();
Component({
  behaviors: [i, o],
  properties: {
    activity: { type: Object, value: "" },
    groupList: { type: Array, value: [] },
    pageType: { type: String, value: "" },
    isActPlayer: { type: String, value: !1 },
    selfid: { type: String, value: "" },
  },
  data: { groups: "", crtIndex: 0, choosedList: "", toView: "" },
  pageLifetimes: {
    show: function () {
      if (
        ((0, a.mylog)("lifetimes, show"), r.globalData.activityInfo.crtActivity)
      ) {
        var t = r.globalData.activityInfo.crtActivity._infos.groups;
        if (t) {
          var e = this.data.crtIndex;
          e > t.length - 1 && (e = t.length - 1),
            this.setData({ groups: t, crtIndex: e });
        }
      }
    },
  },
  methods: {
    init: function (t) {
      var a = (0, e.getDefaultGroups)(),
        i = this.data.activity;
      i && i._infos.groups && (a = i._infos.groups);
      var o = 0;
      this.data.crtIndex > 0 &&
        (o = this.data.crtIndex) > a.length &&
        (o = a.length);
      var r = "group_" + (o - 3);
      this.setData({
        groups: a,
        crtIndex: o,
        choosedList: t.choosedList,
        toView: r,
      });
    },
    onGroupsManage: function (a) {
      var e = a.currentTarget.dataset.index;
      (0, t.navTo)({ url: "/pages/activity/groups/manage/manage?index=" + e });
    },
    onGroupsManage_2: function (a) {
      (0, t.navTo)({ url: "/pages/activity/groups/manage/manage" });
    },
    onGroupChoosed: function (t) {
      var a = t.currentTarget.dataset.index;
      this.setData({ crtIndex: parseInt(a) });
    },
    onGroupsConfirm: function () {
      var e = this;
      if (this._checkVipfun()) {
        var i = this.data.choosedList,
          o = "";
        this.data.crtIndex <= this.data.groups.length - 1 &&
          (o = this.data.groups[this.data.crtIndex].no),
          wx.showLoading({ title: "分组中", mask: !0 }),
          wx.cloud.callFunction({
            name: "activity",
            data: {
              fun: "dealGroup",
              activityid: this.data.activity._id,
              choosedList: i,
              groupNo: o,
              isDebug: r.globalData.isDebug,
              version: r.globalData.frontVersion,
            },
            success: function (t) {
              (0, a.mylog)("dealGroup, res: ", t),
                "fail" === t.result.type
                  ? (wx.hideLoading(),
                    wx.showModal({
                      content: t.result.msg,
                      showCancel: !1,
                      confirmText: "好的",
                    }))
                  : ((r.globalData.activityInfo.groupChanged = !0),
                    e.triggerEvent("groupDealed", {}, {}),
                    e.closeAnimate());
            },
            fail: function (e) {
              (0, a.mylog)("dealGroup, err: ", e),
                (0, t.networkFail)(!1, e, "activity.dealGroup");
            },
          });
      }
    },
  },
});
