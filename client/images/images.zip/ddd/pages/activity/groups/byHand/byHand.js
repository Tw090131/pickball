var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  e = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  o = getApp(),
  s = require("../../../../051A88476B9DF5DF637CE0402F9455F2.js"),
  i = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js");
Page({
  behaviors: [s, i],
  data: {
    pageType: "groupsByhand",
    navInfo: (0, t.getNavInfo)(),
    activityid: "",
    activity: "",
    selfid: "",
    genderType: -1,
    hideGrouped: !1,
    chooseList: [],
    choosedMan: 0,
    choosedWoman: 0,
    toTop: !1,
    isDebug: o.globalData.isDebug,
  },
  onLoad: function (e) {
    o.globalData.activityInfo.crtActivity &&
      (this.setData({
        activityid: o.globalData.activityInfo.crtActivity._id,
        activity: o.globalData.activityInfo.crtActivity,
        selfid: o.globalData.selfid,
        players: (0, t.copyArr)(o.globalData.activityInfo.crtPlayers),
      }),
      this._dealRoles(this.data.players),
      this._calChooseList());
  },
  onReady: function () {
    var t = this;
    if (this.data.signed.length > 0 && this.data.hasGrouped) {
      wx.showLoading({ title: "筛选待分组报名", mask: !0 });
      var e = setTimeout(function () {
        t.setData({ hideGrouped: !0 }),
          wx.hideLoading(),
          t._countGenders(),
          t._calChooseList(),
          clearTimeout(e);
      }, 1500);
    }
  },
  onShow: function () {
    this.setData({ activity: o.globalData.activityInfo.crtActivity });
  },
  onHide: function () {},
  onUnload: function () {},
  onRefresh: function () {
    this._getActivity(),
      this._getActivityPlayers(),
      this.setData({ chooseList: [], choosedMan: 0, choosedWoman: 0 });
  },
  onOrderPickerChange: function (t) {
    var e = this.data.orderConfig,
      o = parseInt(t.detail.value);
    this.setData({ crtOrder: e.values[o], toTop: !0 });
  },
  onGenderMan: function () {
    this.setData({ genderType: 1 }), this._calChooseList();
  },
  onGenderWoman: function () {
    this.setData({ genderType: 2 }), this._calChooseList();
  },
  onGenderUnknow: function () {
    this.setData({ genderType: 0 }), this._calChooseList();
  },
  onHideGrouped: function () {
    this.data.hideGrouped
      ? this.setData({ hideGrouped: !1 })
      : this.setData({ hideGrouped: !0 }),
      this._countGenders(),
      this._calChooseList();
  },
  onGenderRestore: function () {
    this.setData({ genderType: -1 }), this._calChooseList();
  },
  onReturnAll: function () {
    this.setData({ hideGrouped: !1, genderType: -1 }),
      this._countGenders(),
      this._calChooseList();
  },
  _countGenders: function () {
    for (
      var t = this.data.signed,
        e = 0,
        o = 0,
        s = 0,
        i = this.data.hideGrouped,
        a = 0;
      a < t.length;
      a++
    ) {
      var n = t[a];
      (!i || (i && !n._groupNo)) &&
        (1 === n.gender ? e++ : 2 === n.gender ? o++ : s++);
    }
    this.setData({ manCnt: e, womanCnt: o, nogender: s });
  },
  onChoose: function (t) {
    if (this.data.chooseList.length >= 50)
      wx.showToast({ title: "一次分组不超过50人哦", icon: "none" });
    else {
      var o = t.currentTarget.dataset.player._id;
      (0, e.mylog)("id: ", o);
      var s = this._setChoose(this.data.signed, o),
        i = this._setChoose(this.data.smart, o),
        a = this._setChoose(this.data.levels, o),
        n = this._setChoose(this.data.byremarks, o),
        r = this._setChooseForGroups(this.data.groupList, o);
      this.setData({
        signed: s,
        smart: i,
        levels: a,
        byremarks: n,
        groupList: r,
      }),
        this._calChooseList();
    }
  },
  _setChoose: function (t, e) {
    for (var o = [], s = 0; s < t.length; s++) {
      var i = t[s];
      (i._id !== e && e) ||
        ((i = JSON.parse(JSON.stringify(t[s]))).checked
          ? (i.checked = !1)
          : (i.checked = !0)),
        o.push(i);
    }
    return o;
  },
  _setChooseForGroups: function (t, e) {
    if (!t) return null;
    for (var o = 0; o < t.length; o++) {
      for (var s = t[o].players, i = [], a = 0; a < s.length; a++) {
        var n = s[a];
        (n._id !== e && e) ||
          ((n = JSON.parse(JSON.stringify(s[a]))).checked
            ? (n.checked = !1)
            : (n.checked = !0)),
          i.push(n);
      }
      t[o].players = i;
    }
    return t;
  },
  _calChooseList: function () {
    for (
      var t = [],
        e = this.data.signed,
        o = this.data.hideGrouped,
        s = this.data.genderType,
        i = 0;
      i < e.length;
      i++
    ) {
      var a = e[i];
      a.checked &&
        ((!o && -1 === s) ||
          (o && -1 === s && !a._groupNo) ||
          (!o && -1 != s && s === a.gender) ||
          (o && -1 != s && s === a.gender && !a._groupNo)) &&
        t.push(e[i]);
    }
    for (var n = 0, r = 0, h = 0; h < t.length; h++) {
      var d = t[h];
      1 === d.gender ? n++ : 2 === d.gender ? r++ : 0;
    }
    this.setData({ chooseList: t, choosedMan: n, choosedWoman: r });
  },
  onConfirm: function () {
    var t = this.data.chooseList;
    if (t.length <= 0)
      wx.showToast({
        title: "请选择需分组的报名",
        icon: "none",
        duration: 3e3,
      });
    else if (t.length >= 50)
      wx.showModal({
        content: "一次分组不超过50人哦",
        showCancel: !1,
        confirmText: "好的",
      });
    else {
      var e = this.selectComponent("#forGroups");
      e && (e.init({ choosedList: t }), e.showPop());
    }
  },
  onGroupDealed: function () {
    this.onRefresh(), this.setData({ hideGrouped: !0 });
  },
});
