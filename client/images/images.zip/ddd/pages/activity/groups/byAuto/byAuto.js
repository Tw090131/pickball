var e = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../../402DB5626B9DF5DF264BDD6567B455F2.js"),
  r = getApp(),
  o = require("../../../../051A88476B9DF5DF637CE0402F9455F2.js"),
  i = require("../../../../16478CB26B9DF5DF7021E4B560E455F2.js"),
  s = require("../groupComm.js");
Page({
  behaviors: [o, i, s],
  data: {
    pageType: "groupsByAuto",
    navInfo: (0, e.getNavInfo)(),
    status: "autoSelect",
    autoModes: [
      {
        value: "levelDesc",
        name: "等级从高到底",
        name_2: "按等级从高到低抽签",
      },
      { value: "levelAvg", name: "等级混合均分", name_2: "按等级混合均分抽签" },
      { value: "levelAsc", name: "等级从低到高", name_2: "按等级从低到高抽签" },
      { value: "random", name: "完全随机抽签", name_2: "完全随机抽签分组" },
    ],
    crtIndex: 1,
    activityid: "",
    activity: "",
    selfid: "",
    previewGroups: [],
    groupsCnt: "",
    isDebug: r.globalData.isDebug,
  },
  onLoad: function (a) {
    var o = r.globalData.activityInfo.crtActivity;
    o &&
      (o._infos.groups || (o._infos.groups = (0, t.getDefaultGroups)()),
      this.setData({
        activityid: o._id,
        activity: o,
        selfid: r.globalData.selfid,
        players: (0, e.copyArr)(r.globalData.activityInfo.crtPlayers),
        groupsCnt: o._infos.groups.length,
      }),
      this._dealRoles(this.data.players));
  },
  onReady: function () {},
  onShow: function () {
    var e = r.globalData.activityInfo;
    if (e.groupManaged) {
      e.groupManaged = !1;
      var a = this.data.groupsCnt,
        t = e.crtActivity._infos.groups.length;
      this.setData({ activity: e.crtActivity, groupsCnt: t }),
        "autoPreview" === this.data.status &&
          (e.limitChanged
            ? ((e.limitChanged = !1), this.onRetry())
            : t != a && this.onRetry());
    }
  },
  onHide: function () {},
  onUnload: function () {
    r.globalData.activityInfo.limitChanged = !1;
  },
  onAutoSelect: function (e) {
    var a = e.currentTarget.dataset.index;
    this.setData({ crtIndex: a });
  },
  onGroupManage: function () {
    (0, e.navTo)({ url: "/pages/activity/groups/manage/manage" });
  },
  onGroupPreview: function () {
    var e = this;
    if (this.data.smart.length <= 0)
      wx.showToast({ title: "至少需要1个报名哦", icon: "none" });
    else {
      wx.showLoading({ title: "抽签中", mask: !0 });
      var a = setTimeout(function () {
        e._dealGroupPreview(), wx.hideLoading(), clearTimeout(a);
      }, 1e3);
    }
  },
  _dealGroupPreview: function () {
    var e = this.data.crtIndex;
    switch (this.data.autoModes[e].value) {
      case "random":
        this._dealAutoRandom();
        break;
      case "levelDesc":
        this._dealAutoLevelDesc();
        break;
      case "levelAsc":
        this._dealAutoLevelAsc();
        break;
      case "levelAvg":
        this._dealAutoLevelAvg();
        break;
      case "genderSame":
        this._dealAutoGenderSame();
        break;
      case "genderMix":
        this._dealAutoGenderMix();
    }
  },
  _dealAutoRandom: function () {
    for (var t = [], r = this.data.smart, o = 0; o < r.length; o++) {
      var i = JSON.parse(JSON.stringify(r[o]));
      t.push(i);
    }
    var s = JSON.parse(JSON.stringify(this.data.activity._infos.groups));
    (0, a.mylog)(t, s);
    for (var l = 0, n = 0, u = 0; u < s.length; u++)
      s[u].limitMax && ((l += s[u].limitMax), n++);
    var g = s.length - n,
      h = 0;
    g > 0 && (h = Math.round((t.length - l) / g)),
      0 === h && (h = 1),
      (0, a.mylog)("avg: ", h);
    for (var p = [], v = 0; v < s.length; v++) {
      var c = h;
      s[v].limitMax && (c = s[v].limitMax);
      for (var d = { showPlayers: !0, players: [] }, f = 0; f < c; f++)
        if (t.length > 0) {
          var y = (0, e.makeRandom)(0, t.length),
            m = t[y];
          (m._groupNo = v + 1), d.players.push(m), t.splice(y, 1);
        }
      p.push(d);
    }
    (0, a.mylog)("players: ", t);
    d = { unGrouped: !0, showPlayers: !0, players: [] };
    if (t.length > 0) {
      for (var w = 0; w < t.length; w++)
        (t[w]._groupNo = ""), d.players.push(t[w]);
      t = [];
    }
    p.push(d),
      (0, a.mylog)("_dealAutoRandom rlt: ", p),
      this.setData({ previewGroups: p, status: "autoPreview" });
  },
  _dealAutoLevelDesc: function () {
    for (var t = [], r = this.data.smart, o = 0; o < r.length; o++) {
      var i = JSON.parse(JSON.stringify(r[o]));
      t.push(i);
    }
    var s = JSON.parse(JSON.stringify(this.data.activity._infos.groups));
    (0, a.mylog)(t, s);
    for (var l = []; t.length > 0; ) {
      var n = (0, e.makeRandom)(0, t.length),
        u = t[n];
      l.push(u), t.splice(n, 1);
    }
    l.sort(function (e, a) {
      return a.level - e.level;
    }),
      (t = l);
    for (var g = 0, h = 0, p = 0; p < s.length; p++)
      s[p].limitMax && ((g += s[p].limitMax), h++);
    var v = s.length - h,
      c = 0;
    v > 0 && (c = Math.round((t.length - g) / v)),
      0 === c && (c = 1),
      (0, a.mylog)("avg: ", c);
    for (var d = [], f = 0; f < s.length; f++) {
      var y = c;
      s[f].limitMax && (y = s[f].limitMax);
      for (var m = { showPlayers: !0, players: [] }, w = 0; w < y; w++)
        if (t.length > 0) {
          var x = t[0];
          (x._groupNo = f + 1), m.players.push(x), t.splice(0, 1);
        }
      d.push(m);
    }
    (0, a.mylog)("players: ", t);
    m = { unGrouped: !0, showPlayers: !0, players: [] };
    if (t.length > 0) {
      for (var _ = 0; _ < t.length; _++)
        (t[_]._groupNo = ""), m.players.push(t[_]);
      t = [];
    }
    d.push(m),
      (0, a.mylog)("_dealAutoLevelDesc rlt: ", d),
      this.setData({ previewGroups: d, status: "autoPreview" });
  },
  _dealAutoLevelAsc: function () {
    for (var t = [], r = this.data.smart, o = 0; o < r.length; o++) {
      var i = JSON.parse(JSON.stringify(r[o]));
      t.push(i);
    }
    var s = JSON.parse(JSON.stringify(this.data.activity._infos.groups));
    (0, a.mylog)(t, s);
    for (var l = []; t.length > 0; ) {
      var n = (0, e.makeRandom)(0, t.length),
        u = t[n];
      l.push(u), t.splice(n, 1);
    }
    l.sort(function (e, a) {
      return e.level - a.level;
    }),
      (t = l);
    for (var g = 0, h = 0, p = 0; p < s.length; p++)
      s[p].limitMax && ((g += s[p].limitMax), h++);
    var v = s.length - h,
      c = 0;
    v > 0 && (c = Math.round((t.length - g) / v)),
      0 === c && (c = 1),
      (0, a.mylog)("avg: ", c);
    for (var d = [], f = 0; f < s.length; f++) {
      var y = c;
      s[f].limitMax && (y = s[f].limitMax);
      for (var m = { showPlayers: !0, players: [] }, w = 0; w < y; w++)
        if (t.length > 0) {
          var x = t[0];
          (x._groupNo = f + 1), m.players.push(x), t.splice(0, 1);
        }
      d.push(m);
    }
    (0, a.mylog)("players: ", t);
    m = { unGrouped: !0, showPlayers: !0, players: [] };
    if (t.length > 0) {
      for (var _ = 0; _ < t.length; _++)
        (t[_]._groupNo = ""), m.players.push(t[_]);
      t = [];
    }
    d.push(m),
      (0, a.mylog)("_dealAutoLevelDesc rlt: ", d),
      this.setData({ previewGroups: d, status: "autoPreview" });
  },
  _dealAutoLevelAvg: function () {
    for (var t = [], r = this.data.smart, o = 0; o < r.length; o++) {
      var i = JSON.parse(JSON.stringify(r[o]));
      t.push(i);
    }
    var s = JSON.parse(JSON.stringify(this.data.activity._infos.groups));
    (0, a.mylog)(t, s);
    for (var l = []; t.length > 0; ) {
      var n = (0, e.makeRandom)(0, t.length),
        u = t[n];
      l.push(u), t.splice(n, 1);
    }
    l.sort(function (e, a) {
      return a.level - e.level;
    }),
      (t = l);
    var g = Math.ceil(t.length / s.length);
    l = [];
    for (var h = 0; h < g; h++) {
      for (var p = [], v = 0; v < s.length; v++) {
        var c = h * s.length + v;
        if (!(c < t.length)) break;
        p.push(t[c]);
      }
      l.push(p);
    }
    var d = l;
    (0, a.mylog)("levelCnts: ", g, "levelPlayers: ", d);
    for (var f = 0, y = 0, m = 0; m < s.length; m++)
      s[m].limitMax && ((f += s[m].limitMax), y++);
    var w = s.length - y,
      x = 0;
    w > 0 && (x = Math.round((t.length - f) / w)),
      0 === x && (x = 1),
      (0, a.mylog)("avg: ", x);
    for (var _ = [], G = 0; G < s.length; G++) {
      var M = x;
      s[G].limitMax && (M = s[G].limitMax);
      for (var A = { showPlayers: !0, players: [] }, D = 0; D < M; D++) {
        var N = d[D % g];
        if (N.length > 0) {
          var P = N[0];
          (P._groupNo = G + 1), A.players.push(P), N.splice(0, 1);
        } else
          for (var S = 0; S < d.length; S++) {
            var C = d[S];
            if (C.length > 0) {
              var b = C[0];
              (b._groupNo = G + 1), A.players.push(b), C.splice(0, 1);
              break;
            }
          }
      }
      _.push(A);
    }
    A = { unGrouped: !0, showPlayers: !0, players: [] };
    for (var O = 0; O < d.length; O++) {
      var T = d[O];
      if (T.length > 0) {
        for (var J = 0; J < T.length; J++) {
          var k = T[J];
          (k._groupNo = ""), A.players.push(k);
        }
        T = [];
      }
    }
    _.push(A), (0, a.mylog)("_dealAutoLevelDesc rlt: ", _);
    for (var L = 0; L < _.length; L++) {
      var R = _[L].players;
      R.length > 0 &&
        R.sort(function (e, a) {
          return a.level - e.level;
        });
    }
    this.setData({ previewGroups: _, status: "autoPreview" });
  },
  _dealAutoGenderSame: function () {},
  _dealAutoGenderMix: function () {
    for (var t = 0; t < l.length; t++)
      if (l[t].limitMax && l[t].limitMax < 4)
        return void wx.showModal({
          content: "每个分组人数至少需4人，或者请设置为系统均分",
          showCancel: !1,
          confirmText: "好的",
        });
    for (var r = [], o = this.data.smart, i = 0; i < o.length; i++) {
      var s = JSON.parse(JSON.stringify(o[i]));
      r.push(s);
    }
    var l = JSON.parse(JSON.stringify(this.data.activity._infos.groups));
    (0, a.mylog)(r, l);
    for (var n = [], u = [], g = 0; g < r.length; g++) {
      var h = r[g];
      2 === h.gender ? u.push(h) : n.push(h);
    }
    if (n.length < 2 || u.length < 2)
      wx.showModal({
        content: "男、女人数都至少需要2人哦",
        showCancel: !1,
        confirmText: "好的",
      });
    else {
      for (var p = 0, v = 0, c = 0; c < l.length; c++)
        l[c].limitMax && ((p += l[c].limitMax), v++);
      var d = l.length - v,
        f = 0;
      d > 0 && (f = Math.round((r.length - p) / d)),
        0 === f && (f = 1),
        (0, a.mylog)("avg: ", f);
      for (var y = [], m = 0; m < l.length; m++) {
        var w = f;
        l[m].limitMax && (w = l[m].limitMax);
        for (var x = { showPlayers: !0, players: [] }, _ = 0; _ < w; _++)
          if (r.length > 0) {
            var G = (0, e.makeRandom)(0, r.length),
              M = r[G];
            (M._groupNo = m + 1), x.players.push(M), r.splice(G, 1);
          }
        y.push(x);
      }
      (0, a.mylog)("players: ", r);
      x = { unGrouped: !0, showPlayers: !0, players: [] };
      if (r.length > 0) {
        for (var A = 0; A < r.length; A++)
          (r[A]._groupNo = ""), x.players.push(r[A]);
        r = [];
      }
      y.push(x),
        (0, a.mylog)("_dealAutoRandom rlt: ", y),
        this.setData({ previewGroups: y, status: "autoPreview" });
    }
  },
  _dealGroupsFoldOpen: function (e, a) {
    var t = e.currentTarget.dataset.index,
      r = this.data.previewGroups;
    (r[t].showPlayers = a), this.setData({ previewGroups: r });
  },
  onChangeGroupLimit: function (e) {
    (0, a.mylog)("onChangeGroupLimit, e: ", e);
    var t = e.currentTarget.dataset.index,
      r = this.selectComponent("#nameLimit");
    r &&
      (r.init({ groups: this.data.activity._infos.groups, groupIndex: t }),
      r.showPop());
  },
  onGroupChanged: function (e) {
    this.setData({ activity: r.globalData.activityInfo.crtActivity }),
      e.detail.limitChanged && this.onRetry();
  },
  onGroupChange: function (e) {
    (0, a.mylog)("onGroupChange, e: ", e);
    var t = e.currentTarget.dataset.groupIndex,
      r = e.currentTarget.dataset.index,
      o = e.currentTarget.dataset.player,
      i = this.selectComponent("#changeGroup");
    i && (i.init({ groupIndex: t, index: r, player: o }), i.showPop());
  },
  onPlayerGroupChanged: function (e) {
    var a = e.detail.previewGroups;
    this.setData({ previewGroups: a });
  },
  onRetry: function () {
    var e = this;
    wx.showLoading({ title: "重新抽签中", mask: !0 });
    var a = setTimeout(function () {
      e._dealGroupPreview(), wx.hideLoading(), clearTimeout(a);
    }, 1e3);
  },
  onAutoModeSelect: function () {
    var e = this;
    wx.showModal({
      content: "将返回抽签模式选择，当前抽签将清零，是否继续？",
      cancelText: "暂不",
      confirmText: "确定",
      complete: function (a) {
        a.cancel || (a.confirm && e.setData({ status: "autoSelect" }));
      },
    });
  },
  onPreviewConfirm: function () {
    if (this._checkVipfun()) {
      for (var t = [], o = 0; o < this.data.previewGroups.length; o++) {
        var i = this.data.previewGroups[o];
        if (i.players.length > 0) {
          var s = { groupNo: o + 1, ids: [] };
          i.unGrouped && (s.groupNo = "");
          for (var l = 0; l < i.players.length; l++)
            s.ids.push(i.players[l]._id);
          t.push(s);
        }
      }
      (0, a.mylog)("actPlayerids: ", t),
        wx.showLoading({ title: "分组中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "autoGroup",
            activityid: this.data.activityid,
            actPlayerids: t,
            isDebug: r.globalData.isDebug,
            version: r.globalData.frontVersion,
          },
          success: function (t) {
            if (((0, a.mylog)("autoGroup, res: ", t), "fail" === t.result.type))
              wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              (r.globalData.activityInfo.autoGrouped = !0),
                wx.showToast({ title: "分组成功", mask: !0 });
              var o = setTimeout(function () {
                (0, e.dealBack)(), clearTimeout(o);
              }, 1200);
            }
          },
          fail: function (t) {
            (0, a.mylog)("autoGroup, err: ", t),
              (0, e.networkFail)(!1, t, "activity.autoGroup");
          },
        });
    }
  },
});
