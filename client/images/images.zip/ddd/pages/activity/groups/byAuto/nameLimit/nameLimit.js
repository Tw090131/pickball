var t = require("../../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  i = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  a = getApp(),
  e = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
Component({
  behaviors: [e],
  properties: {
    activity: { type: Object, value: "" },
    pageAt: { type: String, value: "byAuto" },
    groupCanPlayer: { type: Boolean, value: !1 },
  },
  data: {
    groups: [],
    groupIndex: "",
    srcGroupName: "",
    crtGroupName: "",
    srcLimitMax: "",
    crtLimitMax: "",
    crtPickerValue: "",
  },
  methods: {
    init: function (t) {
      var a = JSON.parse(JSON.stringify(t.groups)),
        e = parseInt(t.groupIndex);
      (0, i.mylog)(a, e);
      var o = a[e].name,
        r = a[e].limitMax;
      r || (r = ""),
        this.setData({
          srcGroupName: o,
          crtGroupName: o,
          srcLimitMax: r,
          crtLimitMax: r,
          crtPickerValue: r ? r - 1 : 5,
          groupIndex: e,
          groups: a,
        });
    },
    onLimitSysAuto: function () {
      this.setData({ crtLimitMax: "" });
    },
    onLimitPickerChange: function (t) {
      (0, i.mylog)("onLimitPickerChange, e: ", t);
      var a = parseInt(t.detail.value);
      this.setData({ crtLimitMax: a + 1, crtPickerValue: a });
    },
    onGroupNameInput: function (t) {
      this.setData({ crtGroupName: t.detail.value });
    },
    onGroupNameLimitModify: function () {
      if (
        this.data.srcGroupName !== this.data.crtGroupName ||
        this.data.srcLimitMax !== this.data.crtLimitMax
      ) {
        var t = this.data.groups,
          a = this.data.groupIndex;
        (t[a].name = this.data.crtGroupName.trim()),
          (t[a].limitMax = this.data.crtLimitMax),
          (0, i.mylog)("groups: ", t);
        var e = !1;
        this.data.srcLimitMax != this.data.crtLimitMax && (e = !0),
          "byAuto" === this.data.pageAt
            ? this._dealGroupsModify(t, e)
            : (this.triggerEvent(
                "groupEdited",
                { groups: t, limitChanged: e },
                {}
              ),
              this.closeAnimate());
      } else wx.showToast({ title: "没有变化哦", icon: "none" });
    },
    _dealGroupsModify: function (e, o) {
      var r = this;
      wx.showLoading({ title: "修改中", mask: !0 }),
        wx.cloud.callFunction({
          name: "activity",
          data: {
            fun: "modifyGroups",
            activityid: this.data.activity._id,
            groups: e,
            isDebug: a.globalData.isDebug,
            version: a.globalData.frontVersion,
          },
          success: function (t) {
            if (
              ((0, i.mylog)("modifyGroups, res: ", t), "fail" === t.result.type)
            )
              wx.hideLoading(),
                wx.showModal({
                  content: t.result.msg,
                  showCancel: !1,
                  confirmText: "好的",
                });
            else {
              (a.globalData.activityInfo.crtActivity._infos.groups = e),
                wx.showToast({ title: "修改成功", duration: 1e3 }),
                r.closeAnimate();
              var s = setTimeout(function () {
                r.triggerEvent("groupChanged", { limitChanged: o }, {}),
                  clearTimeout(s);
              }, 1e3);
            }
          },
          fail: function (a) {
            (0, i.mylog)("modifyGroups, err: ", a),
              (0, t.networkFail)(!1, a, "activity.modifyGroups");
          },
        });
    },
  },
});
