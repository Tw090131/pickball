var e = require("../../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  t = require("../../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js");
getApp();
Component({
  behaviors: [t],
  properties: {
    activity: { type: Object, value: "" },
    previewGroups: { type: Array, value: [] },
  },
  data: {
    groupIndex: "",
    indexAtGroup: "",
    player: "",
    groups: "",
    crtIndex: 0,
    toView: "",
  },
  methods: {
    init: function (e) {
      var t = this.data.activity._infos.groups,
        r = e.groupIndex,
        o = "group_" + (r - 3);
      this.setData({
        groups: t,
        crtIndex: r,
        toView: o,
        groupIndex: e.groupIndex,
        indexAtGroup: e.index,
        player: e.player,
      });
    },
    onGroupChoosed: function (e) {
      var t = e.currentTarget.dataset.index;
      this.setData({ crtIndex: parseInt(t) });
    },
    onGroupsConfirm: function () {
      var t = this,
        r = this.data.previewGroups,
        o = this.data.groupIndex,
        i = this.data.indexAtGroup;
      if (((0, e.mylog)(r, o, i), o !== this.data.crtIndex)) {
        var a = r[o].players[i];
        r[o].players.splice(i, 1),
          r[this.data.crtIndex].players.push(a),
          this.closeAnimate(),
          wx.showLoading({ title: "调整中", mask: !0 });
        var s = setTimeout(function () {
          t.setData({ previewGroups: r }),
            t.triggerEvent("playerGroupChanged", { previewGroups: r }, {}),
            wx.hideLoading(),
            clearTimeout(s);
        }, 1e3);
      } else wx.showToast({ title: "分组没有变化哦", icon: "none" });
    },
  },
});
