var o = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  t = require("../../../../12A68CD36B9DF5DF74C0E4D4C3C155F2.js"),
  i = getApp();
Component({
  behaviors: [t],
  properties: {},
  data: { autoGrouped: !1 },
  pageLifetimes: {
    show: function () {
      var o = i.globalData.activityInfo;
      this.setData({ autoGrouped: o.autoGrouped });
    },
  },
  methods: {
    onGroupsByHand: function () {
      (0, o.navTo)({ url: "/pages/activity/groups/byHand/byHand" }),
        this._init();
    },
    onGroupsByAuto: function () {
      (0, o.navTo)({ url: "/pages/activity/groups/byAuto/byAuto" }),
        this._init();
    },
    onGroupsModify: function () {
      (0, o.navTo)({ url: "/pages/activity/groups/modify/modify" }),
        this._init();
    },
    onGroupsManage: function () {
      (0, o.navTo)({ url: "/pages/activity/groups/manage/manage" }),
        this._init();
    },
    onGroupsRescind: function () {
      (0, o.navTo)({ url: "/pages/activity/groups/rescind/rescind" }),
        this._init();
    },
    close: function () {
      this._init();
    },
    _init: function () {
      (i.globalData.activityInfo.autoGrouped = !1),
        this.setData({ autoGrouped: !1 });
    },
  },
});
