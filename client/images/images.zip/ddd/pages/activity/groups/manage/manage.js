var t = require("../../../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = require("../../../../402DB5626B9DF5DF264BDD6567B455F2.js"),
  o = require("../../../../F3C93A716B9DF5DF95AF527671F155F2.js"),
  n = getApp();
Page({
  behaviors: [o],
  data: { navInfo: (0, t.getNavInfo)(), activityid: "", activity: "" },
  onLoad: function (o) {
    var r = this;
    if (
      (n.globalData.activityInfo.crtActivity &&
        this.setData({
          activityid: n.globalData.activityInfo.crtActivity._id,
          activity: n.globalData.activityInfo.crtActivity,
        }),
      this.data.activity && this.data.activity._infos.groups
        ? this.setData({
            groups: (0, t.copyArr)(this.data.activity._infos.groups),
            groupCanPlayer: this.data.activity._infos.groupCanPlayer,
            groupOnlyManager: this.data.activity._infos.groupOnlyManager,
          })
        : this.setData({
            groups: (0, i.getDefaultGroups)(),
            groupCanPlayer: !1,
            groupOnlyManager: !1,
          }),
      o.index)
    ) {
      (0, a.mylog)(o.index);
      var e = parseInt(o.index);
      this.setData({ toView: "group_" + (e - 3) });
      var s = setTimeout(function () {
        r._nameLimitPop(e), clearTimeout(s);
      }, 1e3);
    }
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {},
  onUnModified: function () {
    wx.showToast({ title: "没有变化哦", icon: "none" });
  },
  onGroupConfirm: function () {
    var i = this;
    wx.showLoading({ title: "修改中", mask: !0 });
    for (var o = this.data.groups, r = 0; r < o.length; r++)
      (o[r].no = r + 1), (o[r].name = o[r].name.trim());
    wx.cloud.callFunction({
      name: "activity",
      data: {
        fun: "modifyGroups",
        activityid: this.data.activityid,
        groups: o,
        groupCanPlayer: this.data.groupCanPlayer,
        groupOnlyManager: this.data.groupOnlyManager,
        isDebug: n.globalData.isDebug,
        version: n.globalData.frontVersion,
      },
      success: function (r) {
        if (((0, a.mylog)("modifyGroups, res: ", r), "fail" === r.result.type))
          wx.hideLoading(),
            wx.showModal({
              content: r.result.msg,
              showCancel: !1,
              confirmText: "好的",
            });
        else {
          (n.globalData.activityInfo.crtActivity._infos.groups = o),
            (n.globalData.activityInfo.crtActivity._infos.groupOnlyManager =
              i.data.groupOnlyManager),
            (n.globalData.activityInfo.groupManaged = !0),
            (n.globalData.activityInfo.limitChanged = i.data.limitChanged),
            wx.showToast({ title: "修改成功", duration: 1e3 });
          var e = setTimeout(function () {
            (0, t.dealBack)(), clearTimeout(e);
          }, 1e3);
        }
      },
      fail: function (i) {
        (0, a.mylog)("modifyGroups, err: ", i),
          (0, t.networkFail)(!1, i, "activity.modifyGroups");
      },
    });
  },
});
