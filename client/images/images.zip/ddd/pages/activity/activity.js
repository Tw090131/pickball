var t = require("../../BC366FB06B9DF5DFDA5007B7852555F2.js"),
  a = require("../../981C1DB26B9DF5DFFE7A75B5964555F2.js"),
  i = require("../../9CD29CB36B9DF5DFFAB4F4B41AA455F2.js"),
  e = getApp(),
  o = require("../../051A88476B9DF5DF637CE0402F9455F2.js");
Page({
  behaviors: [o],
  data: {
    navInfo: (0, t.getNavInfo)(),
    configs: (0, i.getConfig)(),
    activityid: null,
    triggered: !1,
    referer: "",
    clubid: "",
    from: "",
    pageType: "activity",
    isLoading: !1,
    selfInfo: "",
    isSharing: !1,
  },
  onLoad: function (t) {
    t.from &&
      "creater" === t.from &&
      (this.setData({ status: "create", from: t.from }),
      this.selectComponent("#creater").setFrom("creater")),
      t.from &&
        "clubCreate" === t.from &&
        (this.setData({ status: "create", from: t.from, clubid: t.clubid }),
        this.selectComponent("#creater").setFrom("clubCreate"),
        this.selectComponent("#creater").setClubid(t.clubid)),
      t.from &&
        "copy" === t.from &&
        (this.setData({
          status: "copy",
          from: t.from,
          activity: e.globalData.activityInfo.copyActivity,
        }),
        this.selectComponent("#creater").setFrom("copy")),
      t.activityid && this.setData({ activityid: t.activityid }),
      t.scene && this.setData({ activityid: t.scene }),
      t.referer && this.setData({ referer: t.referer }),
      wx.hideShareMenu(),
      (e.globalData.activityInfo.isFromPlayers = !1),
      (e.globalData.activityInfo.isBackFromUser = !1);
  },
  onReady: function () {
    var t = this;
    e.globalData.selfInfo
      ? this.setData({ selfInfo: e.globalData.selfInfo })
      : wx.cloud.callFunction({
          name: "user",
          data: {
            fun: "selfInfo",
            isDebug: e.globalData.isDebug,
            version: e.globalData.frontVersion,
          },
          success: function (i) {
            (0, a.mylog)("selfInfo res: ", i),
              (e.globalData.selfInfo = i.result.userinfo),
              t.setData({ selfInfo: i.result.userinfo });
          },
          fail: function (t) {
            (0, a.mylog)("selfInfo err: ", t);
          },
        });
  },
  onShow: function () {
    var t = this;
    if (
      ("create" != this.data.status &&
        "copy" != this.data.status &&
        "modify" != this.data.status &&
        (e.globalData.activityInfo.isFromPlayers
          ? ((e.globalData.activityInfo.isFromPlayers = !1), this._upView())
          : e.globalData.activityInfo.isBackFromUser
          ? ((e.globalData.activityInfo.isBackFromUser = !1), this._upView())
          : this._getActivity()),
      this._addView(),
      e.globalData.isLoginedReturn)
    )
      switch (((e.globalData.isLoginedReturn = !1), this.data.status)) {
        case "create":
          var a = this.selectComponent("#creater");
          a && a.doContinueFromLogin();
          break;
        case "copy":
        case "modify":
          break;
        default:
          var i = this.selectComponent("#main");
          i && i.doContinueFromLogin();
      }
    var o = setTimeout(function () {
      if (e.globalData.activityInfo.showGroupControl) {
        var a = t.selectComponent("#main");
        a && a.showGroupsControlPop();
      }
      clearTimeout(o);
    }, 1e3);
  },
  _upView: function () {
    var t = this;
    if (this.data.activity)
      var a = setTimeout(function () {
        var i = t.selectComponent("#main");
        i && i.addViewCnt(), clearTimeout(a);
      }, 750);
  },
  _addView: function () {
    this.data.activityid &&
      wx.cloud.callFunction({
        name: "visitor",
        data: {
          fun: "addView",
          type: "activity",
          mainid: this.data.activityid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, a.mylog)("addView, res: ", t);
        },
        fail: function (t) {
          (0, a.mylog)("addView, err: ", t);
        },
      });
  },
  onCreateActivity: function (t) {
    this.setData({ activityid: t.detail.id }), this._getActivity();
  },
  onRefresh: function () {
    this._getActivity();
  },
  onModify: function () {
    this.setData({ status: "modify" });
  },
  onModifyComplete: function () {
    this._getActivity();
  },
  onBackFromModify: function () {
    this.setData({ status: this.data.activity._status });
  },
  onHide: function () {},
  onUnload: function () {
    var t = e.globalData.activityInfo;
    (t.autoGrouped = !1),
      (t.groupChanged = !1),
      (t.groupManaged = !1),
      (t.showGroupControl = !1);
  },
  onShareAppMessage: function (i) {
    var e = this;
    (0, a.mylog)("onShareAppMessage, e: ", i), this.setData({ isSharing: !0 });
    var o = setTimeout(function () {
      e.setData({ isSharing: !1 }), clearTimeout(o);
    }, 2e3);
    if ((this._addShare(), !this.data.activity))
      return { title: "羽毛球助手", path: "pages/index/index" };
    var s = this.data.activity,
      n = new Date().getTime();
    s._infos.banShare && n < s._startTimeMil
      ? wx.updateShareMenu({ withShareTicket: !0, isPrivateMessage: !0 })
      : wx.updateShareMenu({ withShareTicket: !1, isPrivateMessage: !1 });
    var r = this.data.activity._infos.date,
      c =
        r.month +
        "月" +
        r.day +
        "日(" +
        (0, t.getWeek)(r.weekDay) +
        ")活动报名";
    return (
      this.data.activity._infos.title && (c = this.data.activity._infos.title),
      "menu" === i.from ||
        ("button" === i.from && ("middle" === i.target.id || i.target.id)),
      {
        title: c,
        path:
          "pages/activity/activity?referer=group&activityid=" +
          this.data.activityid,
      }
    );
  },
  _addShare: function () {
    this.data.activityid &&
      wx.cloud.callFunction({
        name: "share",
        data: {
          fun: "addShare",
          type: "activity",
          mainid: this.data.activityid,
          isDebug: e.globalData.isDebug,
          version: e.globalData.frontVersion,
        },
        success: function (t) {
          (0, a.mylog)("addShare, res: ", t);
        },
        fail: function (t) {
          (0, a.mylog)("addShare, err: ", t);
        },
      });
  },
  onHome: function () {
    (0, t.dealBack)();
  },
  onLoading: function (t) {
    this.setData({ isLoading: t.detail.isLoading });
  },
});
